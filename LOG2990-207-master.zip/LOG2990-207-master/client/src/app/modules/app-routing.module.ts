import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminPageComponent } from '@app/pages/admin-page/admin-page.component';
import { CreateGamePageComponent } from '@app/pages/create-game-page/create-game-page.component';
import { GamePageComponent } from '@app/pages/game-page/game-page.component';
import { HomePageComponent } from '@app/pages/home-page/home-page.component';
import { OrganizerPageComponent } from '@app/pages/organizer-page/organizer-page.component';
import { ResultPageComponent } from '@app/pages/result-page/result-page.component';
import { WaitPageComponent } from '@app/pages/wait-page/wait-page.component';

const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'home', component: HomePageComponent },
    { path: 'create', component: CreateGamePageComponent },
    { path: 'game/:quizId', component: GamePageComponent },
    { path: 'wait', component: WaitPageComponent },
    { path: 'organizer', component: OrganizerPageComponent },
    { path: 'admin', component: AdminPageComponent },
    { path: 'result', component: ResultPageComponent },
    { path: '**', redirectTo: '/home' },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule],
})
export class AppRoutingModule {}
