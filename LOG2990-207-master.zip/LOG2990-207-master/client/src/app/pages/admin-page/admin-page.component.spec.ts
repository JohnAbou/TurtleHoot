// On doit mock les components enfants de AdminPageComponent
// eslint-disable-next-line max-classes-per-file
import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { AdminState } from '@app/interfaces/admin-page.state';
import { AdminPageComponent } from './admin-page.component';

@Component({
    selector: 'app-admin-connection-component',
    template: '',
})
class MockAdminConnectionComponent {}

@Component({
    selector: 'app-header-admin',
    template: '',
})
class MockHeaderAdminComponent {}

@Component({
    selector: 'app-game-list',
    template: '',
})
class MockGameListComponent {}

@Component({
    selector: 'app-question-bank-page',
    template: '',
})
class MockQuestionBankPageComponent {}

describe('AdminPageComponent', () => {
    let component: AdminPageComponent;
    let fixture: ComponentFixture<AdminPageComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [
                AdminPageComponent,
                MockAdminConnectionComponent,
                MockHeaderAdminComponent,
                MockGameListComponent,
                MockQuestionBankPageComponent,
            ],
            schemas: [NO_ERRORS_SCHEMA],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(AdminPageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should display admin connection component when pageState is Connection', () => {
        component['pageState'] = AdminState.Connection;
        fixture.detectChanges();

        const adminConnectionComponent = fixture.debugElement.query(By.css('app-admin-connection-component'));
        expect(adminConnectionComponent).toBeTruthy();
    });

    it('should display header admin component when pageState is not Connection', () => {
        component['pageState'] = AdminState.AdminHome;
        fixture.detectChanges();

        const headerAdminComponent = fixture.debugElement.query(By.css('app-header-admin'));
        expect(headerAdminComponent).toBeTruthy();
    });

    it('should display game list component when pageState is AdminHome', () => {
        component['pageState'] = AdminState.AdminHome;
        fixture.detectChanges();

        const gameListComponent = fixture.debugElement.query(By.css('app-game-list'));
        expect(gameListComponent).toBeTruthy();
    });

    it('should display question bank page component when pageState is QuestionsBank', () => {
        component['pageState'] = AdminState.QuestionsBank;
        fixture.detectChanges();

        const questionBankPageComponent = fixture.debugElement.query(By.css('app-question-bank-page'));
        expect(questionBankPageComponent).toBeTruthy();
    });

    it('should change page state to AdminHome when connection status changes to true', () => {
        component['handleConnectionStatusChange'](true);
        expect(component['pageState']).toBe(AdminState.AdminHome);
    });

    it('should change page state to specified state when changePage method is called', () => {
        component['changePage'](AdminState.CreationQuiz);
        expect(component['pageState']).toBe(AdminState.CreationQuiz);
    });
});
