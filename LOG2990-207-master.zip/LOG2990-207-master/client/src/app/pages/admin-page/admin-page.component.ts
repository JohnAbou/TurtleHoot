import { Component } from '@angular/core';
import { AdminState } from '@app/interfaces/admin-page.state';

@Component({
    selector: 'app-admin-page',
    templateUrl: './admin-page.component.html',
    styleUrls: ['./admin-page.component.scss'],
})
export class AdminPageComponent {
    protected adminState = AdminState;
    protected pageState = AdminState.Connection;

    protected handleConnectionStatusChange(newStatus: boolean): void {
        if (newStatus) {
            this.pageState = AdminState.AdminHome;
        }
    }
    protected changePage(newState: AdminState): void {
        this.pageState = newState;
    }
}
