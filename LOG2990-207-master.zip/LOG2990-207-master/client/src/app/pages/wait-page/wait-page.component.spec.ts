import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { ChatboxComponent } from '@app/components/chatbox/chatbox.component';
import { HeaderBarComponent } from '@app/components/header-bar/header-bar.component';
import { JoinGameComponent } from '@app/components/join-game/join-game.component';
import { PopUpComponent } from '@app/components/pop-up/pop-up.component';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { MOCK_QUIZ } from '@common/constants';
import { ConnectionEvent, GameEvent } from '@common/event-name';
import { Quiz } from '@common/quiz';
import { of, throwError } from 'rxjs';
import { Socket } from 'socket.io-client';
import { WaitPageComponent } from './wait-page.component';
import SpyObj = jasmine.SpyObj;

describe('WaitPageComponent', () => {
    let component: WaitPageComponent;
    let fixture: ComponentFixture<WaitPageComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let mockActivatedRoute;
    let socketHelper: SocketTestHelper;
    let routerSpy: SpyObj<Router>;
    let dialogSpy: SpyObj<MatDialog>;
    let mockDialogRef: jasmine.SpyObj<MatDialogRef<PopUpComponent>>;
    let mockQuizService: jasmine.SpyObj<QuizService>;
    let popUpService: SpyObj<PopUpService>;

    beforeEach(async () => {
        popUpService = jasmine.createSpyObj('PopUpService', ['openGameEnded']);

        mockQuizService = jasmine.createSpyObj('QuizService', ['getQuiz']);
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;

        routerSpy = jasmine.createSpyObj('Router', ['navigate']);
        dialogSpy = jasmine.createSpyObj('MatDialog', ['open']);
        mockDialogRef = jasmine.createSpyObj('MatDialogRef', ['afterClosed']);
        mockDialogRef.afterClosed.and.returnValue(of(undefined));

        dialogSpy.open.and.returnValue(mockDialogRef);

        mockActivatedRoute = {
            queryParamMap: of({ get: () => 'testGameId' }),
        };

        await TestBed.configureTestingModule({
            declarations: [WaitPageComponent, ChatboxComponent, JoinGameComponent, PopUpComponent, HeaderBarComponent],
            imports: [MatDialogModule, MatSnackBarModule, HttpClientTestingModule, BrowserAnimationsModule, FormsModule],
            providers: [
                { provide: Router, useValue: routerSpy },
                { provide: SocketClientService, useValue: socketServiceMock },
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                { provide: MatDialog, useValue: dialogSpy },
                { provide: QuizService, useValue: mockQuizService },
                { provide: PopUpService, useValue: popUpService },
            ],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(WaitPageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should get gameId from route parameters', () => {
        expect(component['gameId']).toEqual('testGameId');
    });

    it('should send verifyAccessToLobby message with gameId', () => {
        const spy = spyOn(component.socketClientService, 'send');
        component.ngOnInit();
        expect(spy).toHaveBeenCalledWith(ConnectionEvent.IS_ORGANIZER, 'testGameId');
    });

    it('should update isConnectedToLobby when playerAccess event is received', () => {
        component.ngOnInit();
        socketHelper.peerSideEmit(ConnectionEvent.PLAYER_ACCESS, { success: true, isOrganizer: true });
        expect(component['isConnectedToLobby']).toBeTrue();
    });

    it('should get the id of the socket', () => {
        socketServiceMock.socket.id = '123';
        const socketId = component.socketId;
        expect(socketId).toEqual('123');
    });

    it('should get an empty string if the id of the socket doesnt exist', () => {
        const socketId = component.socketId;
        expect(socketId).toEqual('');
    });

    it('should set #isConnectedToLobby to true when input is true', () => {
        component['letPlayerInLobby']('123');
        expect(component['isConnectedToLobby']).toBe(true);
    });

    it('should handle organizerLeft event correctly', () => {
        component['configurePage']();
        socketHelper.peerSideEmit(ConnectionEvent.ORGANIZER_LEFT);
        expect(popUpService.openGameEnded).toHaveBeenCalledWith('Partie terminée', "L'organisateur a quitté la partie", '/home');
    });

    it('should handle kicked event correctly', () => {
        component['configurePage']();
        socketHelper.peerSideEmit(ConnectionEvent.KICKED);
        expect(popUpService.openGameEnded).toHaveBeenCalledWith('Expulsé de la partie', "L'organisateur vous a retiré de la partie", '/home');
    });

    it('should navigate to play area on calling navigateToArea if quiz exists', () => {
        const quizId = '1';
        component['quizId'] = quizId;

        mockQuizService.getQuiz.and.returnValue(of(MOCK_QUIZ));
        component['navigateToArea']();
        expect(routerSpy.navigate).toHaveBeenCalledWith([`/game/${quizId}`], { queryParams: { gameId: 'testGameId' } });
    });

    it('should change organizer to player navigateToArea if random mode', () => {
        spyOn(component['gameService'], GameEvent.CHANGE_TO_PLAYER);
        const quizId = '1-random';
        component['isOrganizer'] = true;
        component['quizId'] = quizId;

        mockQuizService.getQuiz.and.returnValue(of(MOCK_QUIZ));
        component['navigateToArea']();
        expect(component['gameService'].changeToPlayer).toHaveBeenCalled();
        expect(routerSpy.navigate).toHaveBeenCalledWith([`/game/${quizId}`], { queryParams: { gameId: 'testGameId' } });
    });

    it('should navigate to organizer page on calling navigateToArea if isOrganizer', () => {
        component['isOrganizer'] = true;
        component['quizId'] = '1';
        mockQuizService.getQuiz.and.returnValue(of(MOCK_QUIZ));
        component['navigateToArea']();
        expect(routerSpy.navigate).toHaveBeenCalledWith(['/organizer'], { queryParams: { gameId: 'testGameId' } });
    });

    it('should toggle lock and send correct message to server', () => {
        spyOn(component.socketClientService, 'send');

        component[GameEvent.TOOGLE_LOCK]();

        expect(component['isLocked']).toBeTrue();
        expect(component.socketClientService.send).toHaveBeenCalledWith(GameEvent.TOOGLE_LOCK, { gameId: 'testGameId', isLocked: true });
    });

    it('should send correct message to server when start game button is pressed', () => {
        spyOn(component.socketClientService, 'send');

        component['startGame']();

        expect(component.socketClientService.send).toHaveBeenCalledWith(GameEvent.START_GAME, 'testGameId');
    });

    it('should start countdown on gameStarted event', () => {
        const startCountdownSpy = jasmine.createSpy('startCountdown');

        Object.defineProperty(component, 'startCountdown', { value: startCountdownSpy });
        component['configurePage']();
        socketHelper.peerSideEmit(GameEvent.START_GAME);
        expect(startCountdownSpy).toHaveBeenCalled();
    });

    it('should update quizId when quizId event is received', () => {
        component['configurePage']();
        socketHelper.peerSideEmit(GameEvent.GET_QUIZ, 'testQuizId');
        expect(component['quizId']).toBe('testQuizId');
    });

    it('should update isEmpty when updatePlayers is called', () => {
        component['updatePlayers'](false);
        expect(component['isEmpty']).toBeFalse();
    });

    describe('startGame()', () => {
        it('should set isStarted to true and fetch quiz data successfully', () => {
            const mockQuiz: Quiz = {
                id: '1',
                title: 'Mock Quiz',
                description: '',
                duration: 0,
                lastModification: '',
                questions: [],
            };
            mockQuizService.getQuiz.and.returnValue(of(mockQuiz));

            component['startCountdown']();

            expect(component['isStarted']).toBeTruthy();
            expect(component['quizTitle']).toEqual(mockQuiz.title);
        });
    });

    it('should display error message if quiz is deleted or not available', () => {
        component['quizId'] = '1';
        spyOn(component['snackBar'], 'open').and.callThrough();
        const errorResponse = new HttpErrorResponse({ status: 404 });
        mockQuizService.getQuiz.and.returnValue(throwError(() => errorResponse));
        component['startCountdown']();
        expect(component['snackBar'].open).toHaveBeenCalledWith(
            "Le quiz a été supprimé ou n'est plus disponible. Veuillez en sélectionner un autre.",
            'OK',
        );
    });
});
