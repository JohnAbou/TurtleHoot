import { HttpErrorResponse, HttpStatusCode } from '@angular/common/http';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { NameListComponent } from '@app/components/name-list/name-list.component';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { ConnectionEvent, GameEvent } from '@common/event-name';

@Component({
    selector: 'app-wait-page',
    templateUrl: './wait-page.component.html',
    styleUrls: ['./wait-page.component.scss'],
})
export class WaitPageComponent implements OnInit, OnDestroy {
    @ViewChild(NameListComponent) appNameListComponent: NameListComponent;
    protected gameId: string;
    protected quizTitle: string;
    protected isConnectedToLobby: boolean = false;
    protected isLocked: boolean = false;
    protected isOrganizer: boolean = false;
    protected isEmpty: boolean = true;
    protected isStarted: boolean = false;
    private quizId: string;
    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        private gameService: GameService,
        public socketClientService: SocketClientService,
        private route: ActivatedRoute,
        private router: Router,
        private snackBar: MatSnackBar,
        private quizService: QuizService,
        private popUpService: PopUpService,
    ) {}

    get socketId() {
        return this.socketClientService.socket.id ? this.socketClientService.socket.id : '';
    }

    ngOnInit(): void {
        this.route.queryParamMap.subscribe((params) => {
            const gameId = params.get('gameId');
            if (gameId) {
                this.gameId = gameId;
            }
        });
        this.socketClientService.send(ConnectionEvent.IS_ORGANIZER, this.gameId);
        this.socketClientService.on<boolean>(ConnectionEvent.PLAYER_ACCESS, (isOrganizer: boolean) => {
            this.isOrganizer = isOrganizer;
            this.configurePage();
        });
    }

    ngOnDestroy(): void {
        this.unsubscribeFromSocketFeatures();
    }

    protected updatePlayers(isEmpty: boolean) {
        this.isEmpty = isEmpty && !this.quizId.includes('-random');
    }

    protected letPlayerInLobby(accessCode: string) {
        this.gameId = accessCode;
        this.configurePage();
    }

    protected startGame() {
        this.socketClientService.send(GameEvent.START_GAME, this.gameId);
    }

    protected navigateToArea(): void {
        if (this.isOrganizer && this.quizId && !this.quizId.includes('-random')) {
            this.router.navigate(['/organizer'], { queryParams: { gameId: this.gameId } });
        } else {
            if (this.isOrganizer && this.quizId.includes('-random')) {
                this.gameService.changeToPlayer();
                this.socketClientService.send(GameEvent.CHANGE_TO_PLAYER);
            }
            this.router.navigate([`/game/${this.quizId}`], {
                queryParams: { gameId: this.gameId },
            });
        }
    }

    protected toggleLock(): void {
        this.isLocked = !this.isLocked;
        this.socketClientService.send(GameEvent.TOOGLE_LOCK, { gameId: this.gameId, isLocked: this.isLocked });
    }

    private configurePage() {
        this.isConnectedToLobby = true;
        this.gameService.configureBaseSocketFeatures();
        this.configureBaseSocketFeatures();
        this.socketClientService.send(GameEvent.GET_QUIZ, this.gameId);
        this.socketClientService.send(GameEvent.GET_ROOM_PLAYERS, this.gameId);
    }

    private configureBaseSocketFeatures() {
        this.socketClientService.on<string>(GameEvent.GET_QUIZ, (data: string) => {
            this.quizId = data;
        });
        this.socketClientService.on(ConnectionEvent.ORGANIZER_LEFT, () => {
            this.socketClientService.send(ConnectionEvent.LEAVE_ROOM);
            this.popUpService.openGameEnded('Partie terminée', "L'organisateur a quitté la partie", '/home');
        });
        this.socketClientService.on(ConnectionEvent.KICKED, () => {
            this.popUpService.openGameEnded('Expulsé de la partie', "L'organisateur vous a retiré de la partie", '/home');
        });
        this.socketClientService.on(GameEvent.START_GAME, () => {
            this.startCountdown();
        });
    }
    private unsubscribeFromSocketFeatures() {
        this.gameService.unsubscribeFromSocketFeatures();
        this.socketClientService.off(ConnectionEvent.ORGANIZER_LEFT);
        this.socketClientService.off(ConnectionEvent.PLAYER_ACCESS);
        this.socketClientService.off(GameEvent.GET_QUIZ);
        this.socketClientService.off(ConnectionEvent.KICKED);
        this.socketClientService.off(GameEvent.START_GAME);
    }

    private startCountdown(): void {
        this.quizService.getQuiz(this.quizId).subscribe({
            next: (data) => {
                if (data) {
                    this.gameService.gameQuiz = data;
                    this.quizTitle = data.title;
                    this.isStarted = true;
                }
            },
            error: (error: HttpErrorResponse) => {
                if (error.status === HttpStatusCode.NotFound) {
                    this.snackBar
                        .open("Le quiz a été supprimé ou n'est plus disponible. Veuillez en sélectionner un autre.", 'OK')
                        .onAction()
                        .subscribe(() => {
                            window.location.reload();
                        });
                }
            },
        });
    }
}
