import { HttpClientModule } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { ChatboxComponent } from '@app/components/chatbox/chatbox.component';
import { PopUpComponent } from '@app/components/pop-up/pop-up.component';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ConnectionEvent } from '@common/event-name';
import { of } from 'rxjs';
import { Socket } from 'socket.io-client';
import { GamePageComponent } from './game-page.component';

import SpyObj = jasmine.SpyObj;

describe('GamePageComponent', () => {
    let component: GamePageComponent;
    let fixture: ComponentFixture<GamePageComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;
    let popUpService: SpyObj<PopUpService>;

    beforeEach(waitForAsync(() => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;

        popUpService = jasmine.createSpyObj('PopUpService', ['openGameEnded']);
    }));

    describe('when gameId and testingState exist in queryParams', () => {
        beforeEach(waitForAsync(() => {
            TestBed.configureTestingModule({
                declarations: [GamePageComponent, ChatboxComponent, PopUpComponent],
                imports: [RouterTestingModule, MatDialogModule, HttpClientModule, FormsModule],
                providers: [
                    {
                        provide: ActivatedRoute,
                        useValue: {
                            params: of({}),
                            queryParams: of({ gameId: '123', testing: 'true' }),
                        },
                    },
                    { provide: SocketClientService, useValue: socketServiceMock },
                    { provide: PopUpService, useValue: popUpService },
                ],
                schemas: [NO_ERRORS_SCHEMA],
            }).compileComponents();
        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(GamePageComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });

        it('should create', () => {
            expect(component).toBeTruthy();
        });

        it('should set gameId from queryParams', () => {
            expect(component['gameId']).toBe('123');
        });

        it('should set testing from queryParams', () => {
            expect(component['testing']).toBe(true);
        });
        it('should handle organizerLeft event correctly', () => {
            component.ngOnInit();
            socketHelper.peerSideEmit(ConnectionEvent.ORGANIZER_LEFT);
            expect(popUpService.openGameEnded).toHaveBeenCalledWith('Partie terminée', "L'organisateur a quitté la partie", '/home');
        });
    });

    describe('when gameId and testingState do not exist in queryParams', () => {
        beforeEach(waitForAsync(() => {
            TestBed.configureTestingModule({
                declarations: [GamePageComponent, ChatboxComponent, PopUpComponent],
                imports: [RouterTestingModule, MatDialogModule, HttpClientModule],
                providers: [
                    {
                        provide: ActivatedRoute,
                        useValue: {
                            params: of({}),
                            queryParams: of({}),
                        },
                    },
                    { provide: SocketClientService, useValue: socketServiceMock },
                ],
                schemas: [NO_ERRORS_SCHEMA],
            }).compileComponents();
        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(GamePageComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });

        it('should create', () => {
            expect(component).toBeTruthy();
        });

        it('should not set gameId if it does not exist in queryParams', () => {
            expect(component['gameId']).toBeUndefined();
        });

        it('should not set testing if it does not exist in queryParams', () => {
            expect(component['testing']).toBeUndefined();
        });
    });
});
