import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ConnectionEvent } from '@common/event-name';

@Component({
    selector: 'app-game-page',
    templateUrl: './game-page.component.html',
    styleUrls: ['./game-page.component.scss'],
})
export class GamePageComponent implements OnInit, OnDestroy {
    protected quizId: string;
    protected testing: boolean;
    protected gameId: string;

    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        private route: ActivatedRoute,
        private socketService: SocketClientService,
        private popUpService: PopUpService,
    ) {}

    ngOnInit(): void {
        this.getQuizId();
        this.getGameId();
        this.getTestingState();
        this.configureOrganizerLeft();
    }

    ngOnDestroy(): void {
        this.socketService.off(ConnectionEvent.ORGANIZER_LEFT);
    }

    private getQuizId() {
        this.route.params.subscribe((params) => {
            this.quizId = params['quizId'];
        });
    }
    private getGameId() {
        this.route.queryParams.subscribe((params) => {
            const gameId = params['gameId'];
            if (gameId) {
                this.gameId = gameId;
            }
        });
    }
    private getTestingState() {
        this.route.queryParams.subscribe((params) => {
            const testingState = params['testing'];
            if (testingState) {
                this.testing = testingState === 'true';
            }
        });
    }
    private configureOrganizerLeft() {
        this.socketService.on(ConnectionEvent.ORGANIZER_LEFT, () => {
            this.socketService.send(ConnectionEvent.LEAVE_ROOM);
            this.popUpService.openGameEnded('Partie terminée', "L'organisateur a quitté la partie", '/home');
        });
    }
}
