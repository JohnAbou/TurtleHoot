import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateGamePageComponent } from './create-game-page.component';

describe('CreateGamePageComponent', () => {
    let component: CreateGamePageComponent;
    let fixture: ComponentFixture<CreateGamePageComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [CreateGamePageComponent],
            schemas: [NO_ERRORS_SCHEMA],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(CreateGamePageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should render app-header-bar', () => {
        const headerBarElement = fixture.nativeElement.querySelector('app-header-bar');
        expect(headerBarElement).toBeTruthy();
    });

    it('should render app-accordeon', () => {
        const accordionElement = fixture.nativeElement.querySelector('app-accordeon');
        expect(accordionElement).toBeTruthy();
    });
});
