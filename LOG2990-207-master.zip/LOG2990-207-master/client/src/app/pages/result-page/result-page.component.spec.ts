// On doit mock les components enfants de ResultPageComponent
// eslint-disable-next-line max-classes-per-file
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HeaderBarComponent } from '@app/components/header-bar/header-bar.component';
import { ResultPageComponent } from './result-page.component';

@Component({
    selector: 'app-results',
    template: '',
})
class MockChatboxComponent {}

@Component({
    selector: 'app-chatbox',
    template: '',
})
class MockResultsComponent {}

describe('ResultPageComponent', () => {
    let component: ResultPageComponent;
    let fixture: ComponentFixture<ResultPageComponent>;
    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [ResultPageComponent, HeaderBarComponent, MockChatboxComponent, MockResultsComponent],
            imports: [FormsModule],
        });
        fixture = TestBed.createComponent(ResultPageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
