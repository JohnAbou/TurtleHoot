import { Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormComponent } from '@app/components/form/form.component';
import { AdminState } from '@app/interfaces/admin-page.state';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { QuestionService } from '@app/services/http-services/question.service';
import { FilterField } from '@common/filter';
import { Question, QuestionType } from '@common/quiz';
import { nanoid } from 'nanoid';

@Component({
    selector: 'app-question-bank-page',
    templateUrl: './question-bank-page.component.html',
    styleUrls: ['./question-bank-page.component.scss'],
})
export class QuestionBankComponent implements OnInit {
    @Input() context: AdminState;
    @Input() questions: Question[];
    @Output() questionsChange = new EventEmitter<Question[]>();
    @Output() singleQuestionChange = new EventEmitter<Question>();
    @Output() isAddingQuestionFromDb = new EventEmitter<boolean>();
    filterFiled = FilterField;
    protected questionsBank = AdminState;
    protected filterType: FilterField = FilterField.All;
    protected filteredQuestions: Question[];

    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        @Inject(MatDialog) public dialog: MatDialog,
        private snackBar: MatSnackBar,
        public questionService: QuestionService,
        private popUpService: PopUpService,
    ) {}

    ngOnInit() {
        if (this.context === AdminState.QuestionsBank) {
            this.getAllQuestions();
        }
    }

    filterQuestions(filterType: FilterField) {
        this.filterType = filterType;
        switch (this.filterType) {
            case FilterField.All: {
                this.filteredQuestions = this.questions;
                break;
            }
            case FilterField.Qcm: {
                this.filteredQuestions = this.questions.filter((q) => q.type === QuestionType.QCM);
                break;
            }
            case FilterField.Qrl: {
                this.filteredQuestions = this.questions.filter((q) => q.type === QuestionType.QRL);
                break;
            }
        }
    }
    getAllQuestions() {
        this.questionService.getAllQuestions().subscribe((data) => {
            this.questions = data;
            this.questions.forEach((question) => {
                question.lastModification = new Date(question.lastModification).toDateString();
            });
            this.questions.reverse();
            this.filteredQuestions = this.questions;
        });
    }
    moveResponseUp(index: number) {
        if (index > 0) {
            const tempResponse = this.questions[index];
            this.questions[index] = this.questions[index - 1];
            this.questions[index - 1] = tempResponse;
        }
    }

    moveResponseDown(index: number) {
        if (index < this.questions.length - 1) {
            const tempResponse = this.questions[index];
            this.questions[index] = this.questions[index + 1];
            this.questions[index + 1] = tempResponse;
        }
    }
    openNewDialog() {
        const newQuestion: Question = {
            id: this.generateId(),
            type: QuestionType.QCM,
            text: '',
            points: 10,
            choices: [
                { text: '', isCorrect: false },
                { text: '', isCorrect: false },
            ],
            lastModification: new Date().toDateString(),
        };
        this.openFormDialog(newQuestion);
    }

    openFormDialog(question: Question) {
        const dialogRef = this.dialog.open(FormComponent, {
            data: {
                question,
            },
        });
        dialogRef.disableClose = true;
        dialogRef.afterClosed().subscribe((result) => {
            if (this.isQuestionFilled(result)) {
                this.addQuestion(result);
            }
            this.dialog.closeAll();
        });
    }

    isQuestionFilled(question: Question) {
        return question.choices !== undefined && question.text && question.choices.every((choice) => choice.text);
    }

    openDialog(question: Question) {
        const dialogRef = this.dialog.open(FormComponent, {
            data: {
                question,
            },
        });
        dialogRef.disableClose = true;

        dialogRef.afterClosed().subscribe((result) => {
            if (result) {
                this.modifyQuestion(result);
            }
        });
    }

    modifyQuestion(question: Question) {
        if (this.context === AdminState.QuestionsBank) {
            const NOT_FOUND = -1;
            this.questionService.modifyQuestion(question).subscribe((updatedQuestion) => {
                const index = this.questions.findIndex((q) => q.id === updatedQuestion.id);
                if (index !== NOT_FOUND) {
                    this.questions[index] = updatedQuestion;
                }
            });
        } else {
            const index = this.questions.findIndex((element) => {
                return element.id === question.id;
            });
            this.questions[index] = question;
            this.questionsChange.emit(this.questions);
        }
    }

    generateId() {
        return nanoid();
    }

    addQuestion(newQuestion: Question) {
        if (this.context === AdminState.QuestionsBank) {
            this.filterType = FilterField.All;

            this.saveQuestionToDatabase(newQuestion);
        } else {
            this.filterType = FilterField.All;

            this.questions.unshift(newQuestion);
            this.questionsChange.emit(this.questions);
        }
    }
    addQuestionFromDatabase() {
        this.filterType = FilterField.All;
        this.isAddingQuestionFromDb.emit();
    }

    saveQuestionToDatabase(newQuestion: Question) {
        this.questionService.addQuestion(newQuestion).subscribe((data) => {
            if (!this.questions.some((question) => question.id === data.id)) {
                this.questions.unshift(data);
            }
            this.snackBar.open('Votre question a été sauvegardée dans la banque de questions', 'OK');
        });
    }

    deleteQuestion(questionId: string) {
        this.popUpService.openCareful('Voulez vous vraiment supprimer cette question?', () => {
            if (this.context === AdminState.QuestionsBank) {
                this.questionService.deleteQuestion(questionId).subscribe(() => {
                    this.questions = this.questions.filter((question) => question.id !== questionId);
                });
            } else {
                this.questions = this.questions.filter((question) => question.id !== questionId);
                this.questionsChange.emit(this.questions);
            }
        });
    }
}
