import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIcon } from '@angular/material/icon';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormComponent } from '@app/components/form/form.component';
import { AdminState } from '@app/interfaces/admin-page.state';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { QuestionService } from '@app/services/http-services/question.service';
import { MOCK_QUESTIONS } from '@common/constants';
import { FilterField } from '@common/filter';
import { Question, QuestionType } from '@common/quiz';
import { of } from 'rxjs';
import { QuestionBankComponent } from './question-bank-page.component';

describe('QuestionBankComponent', () => {
    let component: QuestionBankComponent;
    let fixture: ComponentFixture<QuestionBankComponent>;
    let dialog: MatDialog;
    let mockQuestionService: jasmine.SpyObj<QuestionService>;
    let popUpService: jasmine.SpyObj<PopUpService>;
    beforeEach(async () => {
        popUpService = jasmine.createSpyObj('PopUpService', ['openCareful']);
        mockQuestionService = jasmine.createSpyObj('QuestionService', ['addQuestion', 'deleteQuestion', 'getAllQuestions', 'modifyQuestion']);
        await TestBed.configureTestingModule({
            declarations: [QuestionBankComponent, MatIcon],
            imports: [HttpClientTestingModule, MatDialogModule, BrowserAnimationsModule, MatSnackBarModule],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: QuestionService, useValue: mockQuestionService },
                { provide: PopUpService, useValue: popUpService },
            ],
        }).compileComponents();
        dialog = TestBed.inject(MatDialog);
        fixture = TestBed.createComponent(QuestionBankComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should open new dialog on add button click', () => {
        spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of(MOCK_QUESTIONS[0]) } as MatDialogRef<unknown, unknown>);
        const addButton = fixture.nativeElement.querySelector('.add');
        addButton.click();
        expect(dialog.open).toHaveBeenCalledWith(FormComponent, { data: { question: jasmine.any(Object) } });
    });
    it('should filter questions by "all"', () => {
        component.questions = [
            { id: '1', type: QuestionType.QCM, text: 'Question 1', points: 10, choices: [], lastModification: '2024-04-12' },
            { id: '2', type: QuestionType.QRL, text: 'Question 2', points: 10, choices: [], lastModification: '2024-04-12' },
        ];

        component.filterQuestions(FilterField.All);

        expect(component['filterType']).toBe(FilterField.All);
        expect(component['filteredQuestions'].length).toBe(2);
    });

    it('should filter questions by "qcm"', () => {
        component.questions = [
            { id: '1', type: QuestionType.QCM, text: 'Question 1', points: 10, choices: [], lastModification: '2024-04-12' },
            { id: '2', type: QuestionType.QRL, text: 'Question 2', points: 10, choices: [], lastModification: '2024-04-12' },
        ];

        component.filterQuestions(FilterField.Qcm);

        expect(component['filterType']).toBe(FilterField.Qcm);
        expect(component['filteredQuestions'].length).toBe(1);
        expect(component['filteredQuestions'][0].type).toBe(QuestionType.QCM);
    });

    it('should filter questions by "qrl"', () => {
        component.questions = [
            { id: '1', type: QuestionType.QCM, text: 'Question 1', points: 10, choices: [], lastModification: '2024-04-12' },
            { id: '2', type: QuestionType.QRL, text: 'Question 2', points: 10, choices: [], lastModification: '2024-04-12' },
        ];

        component.filterQuestions(FilterField.Qrl);

        expect(component['filterType']).toBe(FilterField.Qrl);
        expect(component['filteredQuestions'].length).toBe(1);
        expect(component['filteredQuestions'][0].type).toBe(QuestionType.QRL);
    });

    it('should modify question if found', () => {
        const updatedQuestion = MOCK_QUESTIONS[0];
        const index = 0;
        component['questions'] = MOCK_QUESTIONS;
        component.modifyQuestion(updatedQuestion);
        expect(component['questions'][index]).toEqual(updatedQuestion);
    });

    it('should fetch all questions and modify lastModification', () => {
        mockQuestionService.getAllQuestions.and.returnValue(of(MOCK_QUESTIONS));
        component.getAllQuestions();
        expect(component.questions.length).toBe(MOCK_QUESTIONS.length);
        component.questions.forEach((question) => {
            expect(question.lastModification).toBe(new Date(question.lastModification).toDateString());
        });
    });

    it('should add question when dialog is closed without canceling', fakeAsync(() => {
        const dialogspy = spyOn(dialog, 'open').and.returnValue({
            afterClosed: () => of(false),
        } as MatDialogRef<unknown, unknown>);
        spyOn(component, 'addQuestion');
        component.openNewDialog();
        tick();
        expect(dialogspy).toHaveBeenCalled();
    }));

    it('should open dialog with correct data when openDialog is called', () => {
        const question = {
            id: '1',
            type: QuestionType.QCM,
            text: 'Question text',
            points: 10,
            choices: [{ text: 'Choice 1', isCorrect: true }],
            lastModification: '2024-02-13',
        };

        spyOn(dialog, 'open').and.returnValue({
            afterClosed: () => of(null),
        } as MatDialogRef<unknown, unknown>);

        component.openDialog(question);
        expect(dialog.open).toHaveBeenCalledWith(FormComponent, {
            data: { question },
        });
    });

    it('should call modifyQuestion with result when dialog is closed with a result', fakeAsync(() => {
        const question = {
            id: '1',
            type: QuestionType.QCM,
            text: 'Question text',
            points: 10,
            choices: [{ text: 'Choice 1', isCorrect: true }],
            lastModification: '2024-02-13',
        };
        const updatedQuestion = {
            id: '1',
            type: QuestionType.QCM,
            text: 'Updated question text',
            points: 20,
            choices: [{ text: 'Choice 1', isCorrect: true }],
            lastModification: '2024-02-14',
        };
        spyOn(dialog, 'open').and.returnValue({
            afterClosed: () => of(updatedQuestion),
            disableClose: true,
        } as MatDialogRef<unknown, unknown>);
        spyOn(component, 'modifyQuestion');
        component.openDialog(question);
        tick();
        expect(component.modifyQuestion).toHaveBeenCalledWith(updatedQuestion);
    }));

    it('should call getAllQuestions when context is AdminState.QuestionsBank in ngOnInit', () => {
        spyOn(component, 'getAllQuestions');
        component.context = AdminState.QuestionsBank;
        component.ngOnInit();
        expect(component.getAllQuestions).toHaveBeenCalled();
    });

    it('should move response up when index is greater than 0', () => {
        component.questions = MOCK_QUESTIONS;
        const index = 1;
        const tempQuestion = component.questions[index];
        component.moveResponseUp(index);
        expect(component.questions[index - 1]).toEqual(tempQuestion);
    });

    it('should move response down when index is less than questions length - 1', () => {
        component.questions = MOCK_QUESTIONS;
        const index = 0;
        const tempQuestion = component.questions[index];
        component.moveResponseDown(index);
        expect(component.questions[index + 1]).toEqual(tempQuestion);
    });

    it('should modify question and update the array if context is AdminState.QuestionsBank', () => {
        const updatedQuestion = MOCK_QUESTIONS[0];
        const index = 0;
        component.context = AdminState.QuestionsBank;
        component.questions = MOCK_QUESTIONS;
        mockQuestionService.modifyQuestion.and.returnValue(of(updatedQuestion));
        component.modifyQuestion(updatedQuestion);
        expect(component.questions[index]).toEqual(updatedQuestion);
    });

    it('should call saveQuestionToDatabase when context is AdminState.QuestionsBank', () => {
        spyOn(component, 'saveQuestionToDatabase');
        component.context = AdminState.QuestionsBank;
        const newQuestion: Question = {
            id: '3',
            type: QuestionType.QCM,
            text: 'New Question',
            points: 15,
            choices: [{ text: 'Choice 1', isCorrect: true }],
            lastModification: '2024-02-13',
        };
        component.addQuestion(newQuestion);
        expect(component.saveQuestionToDatabase).toHaveBeenCalledWith(newQuestion);
    });

    it('should emit questionsChange event with updated questions array when adding a new question', () => {
        const newQuestion: Question = {
            id: '3',
            type: QuestionType.QCM,
            text: 'New Question',
            points: 15,
            choices: [{ text: 'Choice 1', isCorrect: true }],
            lastModification: '2024-02-13',
        };
        spyOn(component.questionsChange, 'emit');
        component.context = AdminState.Connection;
        component.questions = MOCK_QUESTIONS;
        component.addQuestion(newQuestion);
        expect(component.questionsChange.emit).toHaveBeenCalledWith(component.questions);
    });

    it('should toggle isAddingFromDatabase and emit isAddingQuestionFromDb event', () => {
        spyOn(component.isAddingQuestionFromDb, 'emit');
        component.addQuestionFromDatabase();
        expect(component.isAddingQuestionFromDb.emit).toHaveBeenCalled();
    });

    it('should save new question to database and update questions array', () => {
        const newQuestion: Question = {
            id: '3',
            type: QuestionType.QCM,
            text: 'New Question',
            points: 15,
            choices: [{ text: 'Choice 1', isCorrect: true }],
            lastModification: '2024-02-13',
        };
        const postData = { ...newQuestion, id: '4' };
        component.questions = MOCK_QUESTIONS.slice();
        mockQuestionService.addQuestion.and.returnValue(of(postData));
        component.saveQuestionToDatabase(newQuestion);
        expect(component.questions).toContain(postData);
    });

    it('should delete question from database and update questions array', () => {
        (popUpService.openCareful as jasmine.Spy).and.callFake((text: string, action?: () => void) => {
            if (action) {
                action();
            }
        });
        const questionIdToDelete = '2';
        component.questions = MOCK_QUESTIONS.slice();
        component.context = AdminState.CreationQuiz;
        mockQuestionService.deleteQuestion.and.returnValue(of());
        component.deleteQuestion(questionIdToDelete);
        expect(component.questions).not.toContain(jasmine.objectContaining({ id: questionIdToDelete }));
    });
});
