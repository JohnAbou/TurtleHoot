import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { GlowButtonImageComponent } from '@app/components/glow-button-image/glow-button-image.component';
import { HomePageComponent } from './home-page.component';

describe('HomePageComponent', () => {
    let component: HomePageComponent;
    let fixture: ComponentFixture<HomePageComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [RouterTestingModule.withRoutes([])],
            declarations: [HomePageComponent, GlowButtonImageComponent],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(HomePageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create the component', () => {
        expect(component).toBeTruthy();
    });

    it('should render three app-glow-button components', () => {
        const glowButtonElements = fixture.nativeElement.querySelectorAll('app-glow-button-image');
        expect(glowButtonElements.length).toBe(3);
    });

    it('should pass correct inputs to app-glow-button components', () => {
        const glowButtonElements = fixture.nativeElement.querySelectorAll('app-glow-button-image');

        expect(glowButtonElements[0].getAttribute('buttonText')).toEqual('Joindre une partie');
        expect(glowButtonElements[0].getAttribute('routerLink')).toEqual('/wait');

        expect(glowButtonElements[1].getAttribute('buttonText')).toEqual('Créer une partie');
        expect(glowButtonElements[1].getAttribute('routerLink')).toEqual('/create');

        expect(glowButtonElements[2].getAttribute('buttonText')).toEqual('Administrer les jeux');
        expect(glowButtonElements[2].getAttribute('routerLink')).toEqual('/admin');
    });
});
