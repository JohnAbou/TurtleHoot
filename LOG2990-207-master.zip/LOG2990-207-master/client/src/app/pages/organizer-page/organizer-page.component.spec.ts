import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { ChatboxComponent } from '@app/components/chatbox/chatbox.component';
import { HeaderBarComponent } from '@app/components/header-bar/header-bar.component';
import { PopUpComponent } from '@app/components/pop-up/pop-up.component';
import { TimerNumberComponent } from '@app/components/timer-number/timer-number.component';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { HistoryService } from '@app/services/http-services/history.service';
import { TimeService } from '@app/services/time.service';
import { MOCK_PLAYERS, MOCK_PLAYERS_STATUS, MOCK_QUIZ, QRL_DURATION } from '@common/constants';
import { AnswerEvent, ConnectionEvent, GameEvent, TimerEvent } from '@common/event-name';
import { AnswerState, PlayerState, PlayerWithStatus } from '@common/player';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { Subject, of } from 'rxjs';
import { Socket } from 'socket.io-client';
import { OrganizerPageComponent } from './organizer-page.component';
import SpyObj = jasmine.SpyObj;

describe('OrganizerPageComponent', () => {
    let component: OrganizerPageComponent;
    let fixture: ComponentFixture<OrganizerPageComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;
    let dialogSpy: SpyObj<MatDialog>;
    let mockDialogRef: jasmine.SpyObj<MatDialogRef<PopUpComponent>>;
    let mockActivatedRoute;
    let routerSpy: SpyObj<Router>;
    let gameServiceSpy: SpyObj<GameService>;
    let timeServiceSpy: SpyObj<TimeService>;
    let historyServiceSpy: SpyObj<HistoryService>;
    let popUpService: SpyObj<PopUpService>;

    beforeEach(() => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;

        routerSpy = jasmine.createSpyObj('Router', ['navigate']);
        dialogSpy = jasmine.createSpyObj('MatDialog', ['open']);
        mockDialogRef = jasmine.createSpyObj('MatDialogRef', ['afterClosed']);
        mockDialogRef.afterClosed.and.returnValue(of(undefined));

        const mockPlayers: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                role: PlayerState.Player,
                nBonus: 0,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                id: '2',
                username: 'Player 2',
                role: PlayerState.Player,
                nBonus: 0,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
        ];
        gameServiceSpy = jasmine.createSpyObj('GameService', [
            'getPlayers',
            'filterPlayers',
            'configureBaseSocketFeatures',
            'unsubscribeFromSocketFeatures',
        ]);
        gameServiceSpy.filterPlayers.and.returnValue(mockPlayers);

        dialogSpy.open.and.returnValue(mockDialogRef);
        mockActivatedRoute = {
            queryParams: of({ gameId: 'testGameId' }),
        };

        popUpService = jasmine.createSpyObj('PopUpService', ['openAbandon']);

        const mockTimerExpiredEvent = new Subject<void>();
        timeServiceSpy = jasmine.createSpyObj('TimeService', ['decrement', 'setTime']);
        timeServiceSpy.timerExpiredEvent = mockTimerExpiredEvent;

        historyServiceSpy = jasmine.createSpyObj('HistoryService', [
            'addStartTimestamp',
            'addEndTimestamp',
            'addQuizTitle',
            'addBestScore',
            'addPlayerCount',
            'addToHistory',
            'addPlayerCount',
        ]);

        TestBed.configureTestingModule({
            declarations: [OrganizerPageComponent, ChatboxComponent, PopUpComponent, HeaderBarComponent, TimerNumberComponent],
            imports: [
                HttpClientTestingModule,
                MatDialogModule,
                NgxChartsModule,
                BrowserAnimationsModule,
                MatListModule,
                MatDividerModule,
                FormsModule,
                MatDialogModule,
            ],
            providers: [
                { provide: TimeService, useValue: timeServiceSpy },
                { provide: HistoryService, useValue: historyServiceSpy },
                { provide: Router, useValue: routerSpy },
                { provide: MatDialog, useValue: dialogSpy },
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                { provide: SocketClientService, useValue: socketServiceMock },
                { provide: GameService, useValue: gameServiceSpy },
                { provide: PopUpService, useValue: popUpService },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(OrganizerPageComponent);
        component = fixture.componentInstance;
        component['gameService'].gameQuiz = MOCK_QUIZ;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should handle question ended', () => {
        component['handleQuestionEnded']();
        expect(component['isTransitioning']).toBeTrue();
    });

    it('should handle allPlayersAnswered correctly', fakeAsync(() => {
        const loadQuizSpy = jasmine.createSpy('loadQuiz');
        Object.defineProperty(component, 'loadQuiz', { value: loadQuizSpy });
        component['currentQuestion'] = MOCK_QUIZ.questions[0];
        component['letIntoPage']();
        socketHelper.peerSideEmit(AnswerEvent.ALL_PLAYERS_ANSWERED);

        expect(component['allPlayersAnswered']).toBeTrue();
    }));

    it('should handle allPlayersAnswered correctly', fakeAsync(() => {
        const loadQuizSpy = jasmine.createSpy('loadQuiz');
        Object.defineProperty(component, 'loadQuiz', { value: loadQuizSpy });
        component['currentQuestion'] = MOCK_QUIZ.questions[2];
        component['letIntoPage']();
        socketHelper.peerSideEmit(AnswerEvent.ALL_PLAYERS_ANSWERED);

        expect(component['isReviewing']).toBeTrue();
    }));

    it('should send endQuestion when nextQuestion button is clicked', () => {
        const spy = spyOn(component.socketClientService, 'send');

        component['nextQuestionClicked']();

        expect(spy).toHaveBeenCalledWith(AnswerEvent.END_QUESTION);
    });

    it('should set lastQuestion to true if quiz only has one question', () => {
        const mockQuiz = JSON.parse(JSON.stringify(MOCK_QUIZ));
        mockQuiz.questions = [MOCK_QUIZ.questions[0]];
        component['gameService'].gameQuiz = mockQuiz;
        component['loadQuiz']();
        expect(component['lastQuestion']).toBeTrue();
    });

    it('should route to home on access denied', () => {
        socketHelper.peerSideEmit(GameEvent.ACCESS_TO_GAME, false);
        expect(routerSpy.navigate).toHaveBeenCalledWith(['/home']);
    });

    it('should let into page on access', () => {
        const letIntoPageSpy = jasmine.createSpy('letIntoPage');
        Object.defineProperty(component, 'letIntoPage', { value: letIntoPageSpy });
        component.gameService.players = [];
        component.gameService.players.length = 3;
        component.gameService.players = MOCK_PLAYERS;
        socketHelper.peerSideEmit(GameEvent.ACCESS_TO_GAME, true);
        expect(letIntoPageSpy).toHaveBeenCalled();
    });

    it('should format yAxis ticks correctly', () => {
        const testCases = [
            { value: 0, expected: '0' },
            { value: 5, expected: '5' },
            { value: -3, expected: '-3' },
        ];

        testCases.forEach((testCase) => {
            const result = component['yAxisTickFormatting'](testCase.value);
            expect(result).toEqual(testCase.expected);
        });
    });

    it('should update choices correctly', () => {
        component['letIntoPage']();
        const newChoice = 5;
        component['single'] = [
            { name: 'Choice 1', value: 0 },
            { name: 'Choice 2', value: 0 },
            { name: 'Choice 3', value: 0 },
        ];
        socketHelper.peerSideEmit(AnswerEvent.INTEREACTIONS_CHANGED, { index: 1, newChoice });

        expect(component['single']).toEqual([
            { name: 'Choice 1', value: 0 },
            { name: 'Choice 2', value: 5 },
            { name: 'Choice 3', value: 0 },
        ]);
    });

    it('should return the correct value of time', () => {
        const testTime = 50;
        component.timeService.time = testTime;
        expect(component.time).toEqual(testTime);
    });

    it('should handle question ended and navigate last question', () => {
        const mockHistoryService = jasmine.createSpyObj('HistoryService', ['addEndTimestamp', 'addQuizTitle', 'addBestScore', 'addToHistory']);

        component.historyService = mockHistoryService;
        component['lastQuestion'] = true;
        component['currentQuiz'] = MOCK_QUIZ;
        component['gameService'].players = MOCK_PLAYERS_STATUS;

        component['handleQuestionEnded']();

        expect(mockHistoryService.addEndTimestamp).toHaveBeenCalled();
        expect(mockHistoryService.addQuizTitle).toHaveBeenCalled();
        expect(mockHistoryService.addBestScore).toHaveBeenCalled();
        expect(mockHistoryService.addToHistory).toHaveBeenCalled();
        expect(routerSpy.navigate).toHaveBeenCalledWith(['/result'], { queryParams: { gameId: 'testGameId' } });
    });

    it('should handle question ended but not navigate if not last question', () => {
        const mockRouter = jasmine.createSpyObj('Router', ['navigate']);

        component.router = mockRouter;
        component['lastQuestion'] = false;

        component['handleQuestionEnded']();

        expect(historyServiceSpy.addEndTimestamp).not.toHaveBeenCalled();
        expect(historyServiceSpy.addQuizTitle).not.toHaveBeenCalled();
        expect(historyServiceSpy.addBestScore).not.toHaveBeenCalled();
        expect(historyServiceSpy.addToHistory).not.toHaveBeenCalled();
        expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should handle next question correctly', () => {
        component['currentQuestionIndex'] = 0;
        component['currentQuiz'] = MOCK_QUIZ;
        component['nextQuestion']();
        expect(component['currentQuestionIndex']).toEqual(1);
        expect(component['currentQuestion']).toEqual(MOCK_QUIZ.questions[1]);
    });

    it('should handle evaluation finished event', () => {
        component[AnswerEvent.ALL_PLAYERS_ANSWERED] = false;
        component['onEvaluationFinished']();
        expect(component[AnswerEvent.ALL_PLAYERS_ANSWERED]).toBeTrue();
    });
    it('should handle countdown finished event', () => {
        const nextQuestionSpy = jasmine.createSpy('nextQuestion');
        Object.defineProperty(component, 'nextQuestion', { value: nextQuestionSpy });
        component['currentQuestionIndex'] = 0;
        component['currentQuiz'] = MOCK_QUIZ;
        component['currentQuestion'] = MOCK_QUIZ.questions[0];
        spyOn(component.socketClientService, 'send');

        component['onCountdownFinished']();

        expect(component['isTransitioning']).toBe(false);
        expect(component['nextQuestion']).toHaveBeenCalled();
        expect(component.socketClientService.send).toHaveBeenCalledWith(TimerEvent.START_TIMER, component['gameId']);
    });

    it('should set time correctly for QRL', () => {
        component['currentQuestion'] = MOCK_QUIZ.questions[2];
        component['setTime']();

        expect(timeServiceSpy.setTime).toHaveBeenCalledWith(QRL_DURATION);
    });
    it('should set choices correctly for QRL', () => {
        component['currentQuestion'] = MOCK_QUIZ.questions[2];
        component.gameService.players = MOCK_PLAYERS_STATUS;
        component['setChartData']();

        expect(component['single']).toEqual([
            { name: 'intéragi', value: 0 },
            { name: 'pas intéragi', value: component.gameService.players.length - 1 },
        ]);
    });

    it('should open abandon confirmation popup and navigate correctly', () => {
        (popUpService.openAbandon as jasmine.Spy).and.callFake((action?: () => void) => {
            if (action) {
                action();
            }
        });
        spyOn(component['socketClientService'], 'send');

        component['abandonButtonPressed']();

        expect(component['socketClientService'].send).toHaveBeenCalledWith(ConnectionEvent.LEAVE_ROOM);

        expect(routerSpy.navigate).toHaveBeenCalledWith(['/create']);
    });
});
