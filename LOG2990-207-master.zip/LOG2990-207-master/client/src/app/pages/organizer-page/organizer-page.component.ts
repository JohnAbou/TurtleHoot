import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TimerNumberComponent } from '@app/components/timer-number/timer-number.component';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { HistogramService } from '@app/services/histogram.service';
import { HistoryService } from '@app/services/http-services/history.service';
import { TimeService } from '@app/services/time.service';
import { ORG_HISTOGRAM_DIMENSIONS, QRL_DURATION } from '@common/constants';
import { AnswerEvent, ConnectionEvent, GameEvent, TimerEvent } from '@common/event-name';
import { AnswerChoice, Question, QuestionType, Quiz } from '@common/quiz';
import { SingleItem } from '@common/single';
import { Color, ScaleType } from '@swimlane/ngx-charts';

@Component({
    selector: 'app-organizer-page',
    templateUrl: './organizer-page.component.html',
    styleUrls: ['./organizer-page.component.scss'],
})
export class OrganizerPageComponent implements OnInit, OnDestroy {
    @ViewChild(TimerNumberComponent) timerNumberComponent: TimerNumberComponent;
    protected gameId: string;
    protected currentQuestion: Question;
    protected allPlayersAnswered = false;
    protected lastQuestion = false;
    protected isTransitioning = false;
    protected isReviewing = false;
    protected view: [number, number] = [ORG_HISTOGRAM_DIMENSIONS.width, ORG_HISTOGRAM_DIMENSIONS.height];
    protected single: SingleItem[] = [];
    protected xAxisLabel = 'reponses';
    protected yAxisLabel = 'nombre de joueur';
    protected yAxisTicks: number[] = [];

    protected colorScheme: Color = {
        domain: [],
        name: 'color',
        selectable: true,
        group: ScaleType.Ordinal,
    };
    protected currentQuestionIndex = 0;
    private quizDuration: number;
    private currentQuiz: Quiz;

    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        private route: ActivatedRoute,
        public timeService: TimeService,
        public socketClientService: SocketClientService,
        public router: Router,
        public gameService: GameService,
        private changeDetectorRef: ChangeDetectorRef,
        private histogramService: HistogramService,
        public historyService: HistoryService,
        public popUpService: PopUpService,
    ) {}

    get time(): number {
        return this.timeService.time;
    }

    ngOnInit() {
        this.getGameId();
        this.verifyAccessToGame();
    }

    ngOnDestroy() {
        this.gameService.unsubscribeFromSocketFeatures();
        this.socketClientService.off(GameEvent.ACCESS_TO_GAME);
        this.socketClientService.off(AnswerEvent.QUESTION_ENDED);
        this.socketClientService.off(AnswerEvent.ALL_PLAYERS_ANSWERED);
        this.socketClientService.off(AnswerEvent.INTEREACTIONS_CHANGED);
    }

    protected nextQuestionClicked() {
        this.isReviewing = false;
        this.socketClientService.send(AnswerEvent.END_QUESTION);
    }

    protected onCountdownFinished() {
        this.isTransitioning = false;
        if (this.currentQuestionIndex + 1 === this.currentQuiz.questions.length - 1) {
            this.lastQuestion = true;
        }

        this.nextQuestion();
        this.setTime();
        this.socketClientService.send(TimerEvent.START_TIMER, this.gameId);
    }

    protected onEvaluationFinished() {
        this.allPlayersAnswered = true;
    }

    protected abandonButtonPressed(): void {
        this.popUpService.openAbandon(() => {
            this.socketClientService.send(ConnectionEvent.LEAVE_ROOM);
            this.router.navigate(['/create']);
        });
    }

    protected yAxisTickFormatting(value: number): string {
        return value.toString();
    }

    private getGameId() {
        this.route.queryParams.subscribe((params) => {
            const gameId = params['gameId'];
            if (gameId) {
                this.gameId = gameId;
            }
        });
    }

    private verifyAccessToGame() {
        this.socketClientService.send(GameEvent.VERIFY_ACCESS_TO_GAME, this.gameId);
        this.configureAccessToGame();
    }

    private configureAccessToGame() {
        this.socketClientService.on<boolean>(GameEvent.ACCESS_TO_GAME, (access: boolean) => {
            if (access) {
                this.letIntoPage();
                this.historyService.addStartTimestamp();
                this.historyService.addPlayerCount(this.gameService.players.length - 1);
            } else {
                this.socketClientService.send(ConnectionEvent.LEAVE_ROOM);
                this.router.navigate(['/home']);
            }
        });
    }

    private letIntoPage() {
        this.gameService.players = this.gameService.filterPlayers(this.gameService.players);
        this.gameService.configureBaseSocketFeatures();
        this.setYAxisTicks();
        this.loadQuiz();
        this.configureBaseSocketFeatures();
    }

    private configureBaseSocketFeatures() {
        this.configureQuestionEnded();
        this.configureAllPlayersAnswered();
        this.configureInteractionsChanged();
    }

    private configureQuestionEnded() {
        this.socketClientService.on(AnswerEvent.QUESTION_ENDED, () => {
            this.handleQuestionEnded();
        });
    }
    private configureAllPlayersAnswered() {
        this.socketClientService.on(AnswerEvent.ALL_PLAYERS_ANSWERED, () => {
            if (this.timerNumberComponent) {
                this.timerNumberComponent.allPlayersAnswered();
            }
            if (this.currentQuestion.type === QuestionType.QCM) {
                this.allPlayersAnswered = true;
            } else {
                this.isReviewing = true;
            }
        });
    }
    private configureInteractionsChanged() {
        this.socketClientService.on<AnswerChoice>(AnswerEvent.INTEREACTIONS_CHANGED, (data: AnswerChoice) => {
            this.updateChoices(data.index, data.newChoice);
        });
    }

    private handleQuestionEnded(): void {
        this.allPlayersAnswered = false;
        if (this.lastQuestion) {
            this.router.navigate(['/result'], { queryParams: { gameId: this.gameId } });
            this.historyService.addEndTimestamp();
            this.historyService.addQuizTitle(this.currentQuiz);
            this.historyService.addBestScore(this.gameService.players[1].points);
            this.historyService.addToHistory();
        } else {
            this.socketClientService.off(TimerEvent.TIMER_TICK);
            this.isTransitioning = true;
        }
    }

    private nextQuestion() {
        this.currentQuestionIndex++;
        this.currentQuestion = this.currentQuiz.questions[this.currentQuestionIndex];
        this.setChartData();
    }

    private setYAxisTicks() {
        for (let i = 0; i < this.gameService.players.length; i++) {
            this.yAxisTicks.push(i);
        }
    }

    private loadQuiz() {
        this.currentQuiz = this.gameService.gameQuiz;
        this.currentQuestion = this.gameService.gameQuiz.questions[this.currentQuestionIndex];
        if (this.currentQuiz.questions.length <= 1) {
            this.lastQuestion = true;
        }
        this.quizDuration = this.gameService.gameQuiz.duration;
        this.setTime();
        this.setChartData();
    }

    private setChartData() {
        if (this.currentQuestion.type === QuestionType.QCM) {
            this.setChartQcm();
        } else if (this.currentQuestion.type === QuestionType.QRL) {
            this.setChartQrl();
        }
    }

    private setChartQcm() {
        if (this.currentQuestion.choices) {
            const chartData = this.histogramService.generateChartData(this.currentQuestion.choices);
            this.single = chartData.data;
            this.colorScheme.domain = chartData.colors;
            this.xAxisLabel = 'réponses';
        }
    }
    private setChartQrl() {
        this.single = [
            { name: 'intéragi', value: 0 },
            { name: 'pas intéragi', value: this.gameService.players.length - 1 },
        ];
        this.xAxisLabel = "Status d'intéraction du joueur durant les 5 dernières secondes";
        this.colorScheme.domain = ['blue', 'yellow'];
    }

    private updateChoices(choiceIndex: number, newValue: number) {
        const updatedSingle: SingleItem[] = [];
        this.single.forEach((choice, index) => {
            updatedSingle.push({ name: choice.name, value: index === choiceIndex ? newValue : choice.value });
        });

        this.single = [];
        this.changeDetectorRef.detectChanges();

        this.single = updatedSingle;
        this.changeDetectorRef.detectChanges();
    }
    private setTime() {
        if (this.currentQuestion.type === QuestionType.QCM) {
            this.timeService.setTime(this.quizDuration);
        } else {
            this.timeService.setTime(QRL_DURATION);
        }
    }
}
