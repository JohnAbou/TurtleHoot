export enum AdminState {
    Connection,
    AdminHome,
    CreationQuiz,
    QuestionsBank,
    History,
}
