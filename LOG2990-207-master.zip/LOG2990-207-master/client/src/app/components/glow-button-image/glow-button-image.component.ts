import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-glow-button-image',
    templateUrl: './glow-button-image.component.html',
    styleUrls: ['./glow-button-image.component.scss'],
})
export class GlowButtonImageComponent {
    @Input() buttonText: string = 'Button';
    @Input() imageUrl: string = '';
    @Input() height: string = 'auto';
    @Input() width: string = 'auto';
    @Input() backgroundColor: string = '#27282c';
    @Input() color: string = '#1e9bff';
    @Input() animationColor: string = '#27282c';
    @Input() imageHeight: string = 'auto';
    @Input() imageWidth: string = 'auto';
    @Input() fontSize: string = '1.05em';
}
