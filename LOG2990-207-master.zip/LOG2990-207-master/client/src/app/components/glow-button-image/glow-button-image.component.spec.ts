import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GlowButtonImageComponent } from './glow-button-image.component';

describe('GlowButtonComponent', () => {
    let component: GlowButtonImageComponent;
    let fixture: ComponentFixture<GlowButtonImageComponent>;
    let buttonElement: HTMLElement;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [GlowButtonImageComponent],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(GlowButtonImageComponent);
        component = fixture.componentInstance;
        buttonElement = fixture.nativeElement.querySelector('button');
        fixture.detectChanges();
    });

    it('should create the component', () => {
        expect(component).toBeTruthy();
    });

    it('should set default values if inputs are not provided', () => {
        expect(component.buttonText).toEqual('Button');
        expect(component.imageUrl).toEqual('');
        expect(component.height).toEqual('auto');
        expect(component.width).toEqual('auto');
        expect(component.backgroundColor).toEqual('#27282c');
        expect(component.color).toEqual('#1e9bff');
        expect(component.animationColor).toEqual('#27282c');
        expect(component.imageHeight).toEqual('auto');
        expect(component.imageWidth).toEqual('auto');
        expect(component.fontSize).toEqual('1.05em');
    });

    it('should display the button text correctly', () => {
        const buttonText = 'Click me!';
        component.buttonText = buttonText;
        fixture.detectChanges();
        expect(buttonElement?.textContent?.trim()).toEqual(buttonText);
    });

    it('should display the image if imageUrl is provided', () => {
        const imageUrl = 'example.com/image.png';
        component.imageUrl = imageUrl;
        fixture.detectChanges();
        const imgElement = buttonElement?.querySelector('img');
        expect(imgElement).toBeTruthy();
        expect(imgElement?.getAttribute('src')).toEqual(imageUrl);
    });
});
