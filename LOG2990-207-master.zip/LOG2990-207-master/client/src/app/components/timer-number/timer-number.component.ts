import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { TimeService } from '@app/services/time.service';
import { PANIC_MODE_QCM, PANIC_MODE_QRL } from '@common/constants';
import { PanicModeEvent, TimerEvent } from '@common/event-name';
import { QuestionType } from '@common/quiz';

@Component({
    selector: 'app-timer-number',
    templateUrl: './timer-number.component.html',
    styleUrls: ['./timer-number.component.scss'],
})
export class TimerNumberComponent implements OnInit, OnDestroy {
    @Input() currentQuestionType: QuestionType;
    @Input() gameId: string;
    protected questionEnded = false;
    protected showStartButton = true;
    protected isPaused: boolean = false;
    private panicSound = new Audio('./assets/purge_sound.mp3');
    private panicModeActive: boolean = false;
    private panicModePaused: boolean = false;
    private timerPaused = false;

    constructor(
        public socketClientService: SocketClientService,
        public timeService: TimeService,
    ) {}

    get time(): number {
        return this.timeService.time;
    }

    ngOnInit() {
        this.socketClientService.on(PanicModeEvent.PANIC_COUNTDOWN_UPDATED, () => {
            this.timeService.decrement();
            this.panicModeActive = true;
        });

        this.socketClientService.on(TimerEvent.TIMER_TICK, () => {
            this.timeService.decrement();
            this.checkTimeRemaining();
        });
    }

    ngOnDestroy() {
        this.stopPanicSound();
        this.deactivatePanicMode();
        this.socketClientService.off(TimerEvent.TIMER_TICK);
        this.socketClientService.off(PanicModeEvent.PANIC_COUNTDOWN_UPDATED);
    }

    allPlayersAnswered() {
        this.questionEnded = true;
        this.socketClientService.send(TimerEvent.STOP_TIMER, this.gameId);
        this.showStartButton = false;
        this.stopPanicSound();
    }

    protected toggleTimer() {
        this.timerPaused = !this.timerPaused;
        if (this.timerPaused) {
            this.socketClientService.send(TimerEvent.STOP_TIMER, this.gameId);
        } else {
            this.socketClientService.send(TimerEvent.START_TIMER, this.gameId);
            if (this.panicModeActive) {
                this.startPanicMode();
            }
        }
    }

    protected togglePause(): void {
        if (!this.isPaused) {
            this.isPaused = true;
            if (this.panicModeActive) {
                this.panicModePaused = true;
            }
        } else {
            this.isPaused = false;
            if (this.panicModePaused) {
                this.startPanicMode();
            }
        }
    }

    protected startPanicMode() {
        this.panicModeActive = true;
        if (this.isPaused) {
            this.togglePause();
            this.toggleTimer();
        }
        this.panicSound.play();
        this.socketClientService.send(PanicModeEvent.START_PANIC_MODE, this.gameId);
        this.showStartButton = false;
    }

    private stopPanicSound() {
        this.panicSound.pause();
        this.panicSound.currentTime = 0;
    }

    private deactivatePanicMode() {
        this.panicModeActive = false;
        this.stopPanicSound();
    }

    private checkTimeRemaining() {
        if (this.timeService.time <= PANIC_MODE_QCM && this.currentQuestionType === QuestionType.QCM) {
            this.showStartButton = false;
        }
        if (this.timeService.time <= PANIC_MODE_QRL && this.currentQuestionType === QuestionType.QRL) {
            this.showStartButton = false;
        }
    }
}
