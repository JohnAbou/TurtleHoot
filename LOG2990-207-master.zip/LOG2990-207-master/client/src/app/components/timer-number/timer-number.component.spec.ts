import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { TimeService } from '@app/services/time.service';
import { PANIC_MODE_QCM, PANIC_MODE_QRL } from '@common/constants';
import { PanicModeEvent, TimerEvent } from '@common/event-name';
import { QuestionType } from '@common/quiz';
import { Socket } from 'socket.io-client';
import { TimerNumberComponent } from './timer-number.component';

describe('TimerNumberComponent', () => {
    let component: TimerNumberComponent;
    let fixture: ComponentFixture<TimerNumberComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;
    let timeServiceStub: Partial<TimeService>;

    beforeEach(async () => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;

        timeServiceStub = {
            time: 0,
            decrement: jasmine.createSpy('decrement'),
            setTime: jasmine.createSpy('setTime'),
        };

        await TestBed.configureTestingModule({
            declarations: [TimerNumberComponent],
            providers: [
                { provide: SocketClientService, useValue: socketServiceMock },
                { provide: TimeService, useValue: timeServiceStub },
            ],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(TimerNumberComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should toggle pause', () => {
        component['togglePause']();
        expect(component['isPaused']).toBeTrue();
        component['togglePause']();
        expect(component['isPaused']).toBeFalse();
    });

    it('should unsubscribe from socket events on ngOnDestroy', () => {
        spyOn(component.socketClientService, 'off');
        component.ngOnDestroy();
        // Nombre de fois que la méthode off est appelée
        // eslint-disable-next-line @typescript-eslint/no-magic-numbers
        expect(component.socketClientService.off).toHaveBeenCalledTimes(2);
    });

    it('should toggle timer', () => {
        spyOn(component.socketClientService, 'send');
        component.gameId = 'testGameId';
        component['timerPaused'] = true;
        component['toggleTimer']();
        expect(component.socketClientService.send).toHaveBeenCalledWith(TimerEvent.START_TIMER, 'testGameId');
        expect(component['timerPaused']).toBeFalse();

        component['timerPaused'] = false;
        component['toggleTimer']();
        expect(component.socketClientService.send).toHaveBeenCalledWith(TimerEvent.STOP_TIMER, 'testGameId');
        expect(component['timerPaused']).toBeTrue();
    });

    it('should set panicModeActive to true on panicCountdownUpdated event', () => {
        socketHelper.peerSideEmit(PanicModeEvent.PANIC_COUNTDOWN_UPDATED);
        expect(component['panicModeActive']).toBeTrue();
    });

    it('should set isPaused to true and panicModePaused to true if not paused', () => {
        component['panicModeActive'] = true;

        component['togglePause']();

        expect(component['isPaused']).toBeTrue();
        expect(component['panicModePaused']).toBeTrue();
    });

    it('should update showStartButton based on time remaining and current question type', () => {
        component.currentQuestionType = QuestionType.QCM;
        component.timeService.time = PANIC_MODE_QCM + 1;
        component['checkTimeRemaining']();
        expect(component['showStartButton']).toBe(true);
        component.timeService.time = PANIC_MODE_QCM;
        component['checkTimeRemaining']();
        expect(component['showStartButton']).toBe(false);
    });

    it('should start panic mode', () => {
        spyOn(component['panicSound'], 'play');
        component[PanicModeEvent.START_PANIC_MODE]();
        expect(component['panicSound'].play).toHaveBeenCalled();
        expect(component['panicModeActive']).toBeTrue();
        expect(component['showStartButton']).toBeFalse();
    });

    it('should start panic mode when paused', () => {
        spyOn(component['panicSound'], 'play');
        component['isPaused'] = true;
        const togglePauseSpy = jasmine.createSpy('togglePause');

        Object.defineProperty(component, 'togglePause', { value: togglePauseSpy });
        const toggleTimerSpy = jasmine.createSpy('toggleTimer');

        Object.defineProperty(component, 'toggleTimer', { value: toggleTimerSpy });
        component[PanicModeEvent.START_PANIC_MODE]();
        expect(togglePauseSpy).toHaveBeenCalled();
        expect(toggleTimerSpy).toHaveBeenCalled();
    });

    it('should return the correct value of time', () => {
        const testTime = 50;
        component.timeService.time = testTime;
        expect(component.time).toEqual(testTime);
    });

    it('should stop panic sound', () => {
        spyOn(component['panicSound'], 'pause');
        spyOnProperty(component['panicSound'], 'currentTime', 'set');

        component['stopPanicSound']();

        expect(component['panicSound'].pause).toHaveBeenCalled();
        expect(component['panicSound'].currentTime).toBe(0);
    });

    it('should deactivate panic mode', () => {
        const stopPanicSoundSpy = jasmine.createSpy('stopPanicSound');

        Object.defineProperty(component, 'stopPanicSound', { value: stopPanicSoundSpy });

        component['deactivatePanicMode']();

        expect(component['panicModeActive']).toBeFalse();
        expect(stopPanicSoundSpy).toHaveBeenCalled();
    });

    it('should set showStartButton false if checkTimeRemaining is called with QRL question and time is less than or equal to PANIC_MODE_QRL', () => {
        component.currentQuestionType = QuestionType.QRL;
        component.timeService.time = PANIC_MODE_QRL;

        component['checkTimeRemaining']();
        expect(component['showStartButton']).toBeFalse();
    });

    it('should decrement time service on timerTick', () => {
        socketHelper.peerSideEmit(TimerEvent.TIMER_TICK);
        expect(timeServiceStub.decrement).toHaveBeenCalled();
    });

    it('should handle allPlayersAnswered correctly', () => {
        const stopPanicSoundSpy = jasmine.createSpy('stopPanicSound');

        Object.defineProperty(component, 'stopPanicSound', { value: stopPanicSoundSpy });
        component.allPlayersAnswered();
        expect(stopPanicSoundSpy).toHaveBeenCalled();
    });
});
