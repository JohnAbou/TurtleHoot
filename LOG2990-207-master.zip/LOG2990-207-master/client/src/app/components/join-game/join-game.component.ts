import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ConnectionEvent, ErrorSocketEvent } from '@common/event-name';

@Component({
    selector: 'app-join-game',
    templateUrl: './join-game.component.html',
    styleUrls: ['./join-game.component.scss'],
})
export class JoinGameComponent implements OnInit, OnDestroy {
    @Output() connectRoomEmitter: EventEmitter<string> = new EventEmitter<string>();
    @Output() accessCode: string = '';
    protected playerName: string = '';
    protected errorMessage: string = '';
    constructor(public socketClientService: SocketClientService) {}

    get socketId() {
        return this.socketClientService.socket.id ? this.socketClientService.socket.id : '';
    }

    ngOnInit() {
        this.configureBaseSocketFeatures();
    }

    ngOnDestroy() {
        this.socketClientService.off(ConnectionEvent.PLAYER_JOINED);
        this.socketClientService.off(ErrorSocketEvent.ERROR_CONNECTIONG_GAME);
    }

    protected joinGame() {
        const trimmedUsername = this.playerName.replace(/\s+/g, ' ').trim();
        const len = 4;
        if (!trimmedUsername) {
            this.errorMessage = 'Veuillez entrer un nom de joueur.';
            this.playerName = '';
        } else if (this.accessCode.length !== len) {
            this.errorMessage = "Le code d'accès doit être de 4 caractères.";
        } else {
            this.socketClientService.send(ConnectionEvent.JOIN_ROOM, { accessCode: this.accessCode, username: trimmedUsername });
        }
    }

    private configureBaseSocketFeatures() {
        this.socketClientService.on<string>(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, (errorMessage: string) => {
            this.errorMessage = errorMessage;
        });

        this.socketClientService.on(ConnectionEvent.PLAYER_JOINED, () => {
            this.connectRoomEmitter.emit(this.accessCode);
        });
    }
}
