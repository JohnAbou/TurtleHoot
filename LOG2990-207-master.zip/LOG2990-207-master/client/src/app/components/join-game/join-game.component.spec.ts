import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ConnectionEvent, ErrorSocketEvent } from '@common/event-name';
import { Socket } from 'socket.io-client';
import { JoinGameComponent } from './join-game.component';
describe('JoinGameComponent', () => {
    let component: JoinGameComponent;
    let fixture: ComponentFixture<JoinGameComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;

    beforeEach(async () => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;

        await TestBed.configureTestingModule({
            declarations: [JoinGameComponent],
            imports: [FormsModule],
            providers: [{ provide: SocketClientService, useValue: socketServiceMock }],
            schemas: [NO_ERRORS_SCHEMA],
        }).compileComponents();
        fixture = TestBed.createComponent(JoinGameComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(JoinGameComponent);
        component = fixture.componentInstance;
    });

    it('should set #errorMessage when access code length is not 4', () => {
        component.accessCode = '123';
        component['playerName'] = 'a';
        component['joinGame']();
        expect(component['errorMessage']).toBe("Le code d'accès doit être de 4 caractères.");
    });

    it('should set #errorMessage when no username is entered', () => {
        component.accessCode = '123';
        component['playerName'] = '';
        component['joinGame']();
        expect(component['errorMessage']).toBe('Veuillez entrer un nom de joueur.');
    });

    it('should get the id of the socket', () => {
        socketServiceMock.socket.id = '123';
        const socketId = component.socketId;
        expect(socketId).toEqual('123');
    });

    it('should get the id of the socket', () => {
        const socketId = component.socketId;
        expect(socketId).toEqual('');
    });

    it('should call #socketClientService.send() when access code length is 4', () => {
        spyOn(component.socketClientService, 'send');
        component.accessCode = '5678';
        component['playerName'] = 'Alice';
        component['joinGame']();
        expect(component.socketClientService.send).toHaveBeenCalledWith(ConnectionEvent.JOIN_ROOM, {
            accessCode: '5678',
            username: 'Alice',
        });
    });

    it('should emit #connectRoomEmitter when player joins', () => {
        component.accessCode = '123';
        spyOn(component.connectRoomEmitter, 'emit');
        const mockData = '123';
        component.ngOnInit();
        component['joinGame']();
        socketHelper.peerSideEmit(ConnectionEvent.PLAYER_JOINED, true);
        expect(component.connectRoomEmitter.emit).toHaveBeenCalledWith(mockData);
    });

    it('should change error message when it recevies a new one', () => {
        component['errorMessage'] = 'error message';
        spyOn(component.connectRoomEmitter, 'emit');
        const mockData = 'nom déjà utilisé!';
        component.ngOnInit();
        component['joinGame']();
        socketHelper.peerSideEmit(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, mockData);
        expect(component['errorMessage']).toEqual(mockData);
    });
});
