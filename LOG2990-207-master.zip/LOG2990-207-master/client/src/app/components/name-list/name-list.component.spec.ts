import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ConnectionEvent } from '@common/event-name';
import { AnswerState, PlayerState, PlayerWithStatus } from '@common/player';
import { Subject } from 'rxjs';
import { NameListComponent } from './name-list.component';

describe('NameListComponent', () => {
    let component: NameListComponent;
    let fixture: ComponentFixture<NameListComponent>;
    let mockMatDialog: jasmine.SpyObj<MatDialog>;
    let mockSocketClientService: jasmine.SpyObj<SocketClientService>;
    let gameServiceSpy: jasmine.SpyObj<GameService>;
    let popUpService: jasmine.SpyObj<PopUpService>;

    beforeEach(async () => {
        mockMatDialog = jasmine.createSpyObj('MatDialog', ['open']);
        popUpService = jasmine.createSpyObj('PopUpService', ['openCareful']);
        mockSocketClientService = jasmine.createSpyObj('SocketClientService', ['send']);
        gameServiceSpy = jasmine.createSpyObj('GameService', [
            'getPlayers',
            'filterPlayers',
            'configureBaseSocketFeatures',
            'unsubscribeFromSocketFeatures',
        ]);
        const mockPlayers: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                role: PlayerState.Player,
                nBonus: 0,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                id: '2',
                username: 'Player 2',
                role: PlayerState.Player,
                nBonus: 0,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
        ];
        gameServiceSpy.getPlayers.and.returnValue(mockPlayers);
        const mockPlayersChangedEvent = new Subject<PlayerWithStatus[]>();
        gameServiceSpy.playersChangedEvent = mockPlayersChangedEvent;

        await TestBed.configureTestingModule({
            declarations: [NameListComponent],
            providers: [
                { provide: MatDialog, useValue: mockMatDialog },
                { provide: SocketClientService, useValue: mockSocketClientService },
                { provide: GameService, useValue: gameServiceSpy },
                { provide: PopUpService, useValue: popUpService },
            ],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(NameListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should initialize correctly', () => {
        expect(component['players']).toBeUndefined();
    });

    it('should emit playersUpdated event when players change', () => {
        const newPlayers: PlayerWithStatus[] = [
            {
                id: '3',
                username: 'Player 3',
                role: PlayerState.Player,
                nBonus: 0,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
        ];
        gameServiceSpy.playersChangedEvent.next(newPlayers);

        component.ngOnInit();

        expect(component['players']).toEqual(newPlayers);
    });

    it('should send kickPlayer event to SocketClientService', () => {
        (popUpService.openCareful as jasmine.Spy).and.callFake((text: string, action?: () => void) => {
            if (action) {
                action();
            }
        });
        const playerToKick: PlayerWithStatus = {
            id: '1',
            username: 'Player 1',
            role: PlayerState.Player,
            nBonus: 0,
            points: 0,
            answerState: AnswerState.default,
            isPlaying: true,
            isMuted: false,
        };

        component['kickPlayer'](playerToKick);
        expect(mockSocketClientService.send).toHaveBeenCalledWith(ConnectionEvent.KICK_PLAYER, {
            username: playerToKick.username,
            socketId: playerToKick.id,
        });
    });
});
