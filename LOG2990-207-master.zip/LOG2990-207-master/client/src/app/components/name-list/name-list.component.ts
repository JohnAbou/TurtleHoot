import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { AdminState } from '@app/interfaces/admin-page.state';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ConnectionEvent } from '@common/event-name';
import { Player, PlayerWithStatus } from '@common/player';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-name-list',
    templateUrl: './name-list.component.html',
    styleUrls: ['./name-list.component.scss'],
})
export class NameListComponent implements OnInit, OnDestroy {
    @Output() playersUpdated: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output()
    pageState: EventEmitter<AdminState> = new EventEmitter<AdminState>();
    @Input() isOrganizer: boolean;
    protected players: Player[];
    private playersChangedSubscription: Subscription;

    constructor(
        private socketClientService: SocketClientService,
        private gameService: GameService,
        private popUpService: PopUpService,
    ) {}

    ngOnInit(): void {
        this.playersChangedSubscription = this.gameService.playersChangedEvent.subscribe((updatedPlayers: PlayerWithStatus[]) => {
            this.players = updatedPlayers.filter((player) => player.isPlaying);
            this.playersUpdated.emit(this.players.length <= 1);
        });
    }

    ngOnDestroy(): void {
        if (this.playersChangedSubscription) {
            this.playersChangedSubscription.unsubscribe();
        }
    }

    protected kickPlayer(player: Player) {
        this.popUpService.openCareful('Voulez vous vraiment expulser ce joueur?', () => {
            this.socketClientService.send(ConnectionEvent.KICK_PLAYER, { username: player.username, socketId: player.id });
        });
    }
}
