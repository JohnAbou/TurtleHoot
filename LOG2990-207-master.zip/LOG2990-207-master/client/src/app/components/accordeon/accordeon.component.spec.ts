import { CdkAccordionModule } from '@angular/cdk/accordion';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { QuizService } from '@app/services/http-services/quiz.service';
import { RandomModeService } from '@app/services/random-mode.service';
import { MOCK_QUESTIONS, MOCK_QUIZ, MOCK_QUIZZES } from '@common/constants';
import { of } from 'rxjs';
import { AccordeonComponent } from './accordeon.component';

describe('AccordeonComponent', () => {
    let component: AccordeonComponent;
    let fixture: ComponentFixture<AccordeonComponent>;
    let mockQuizService: jasmine.SpyObj<QuizService>;
    let mockRandomService: jasmine.SpyObj<RandomModeService>;
    let mockMatDialog: jasmine.SpyObj<MatDialog>;

    beforeEach(waitForAsync(() => {
        mockQuizService = jasmine.createSpyObj('QuizService', ['getAllQuiz', 'getQuizVisibility']);
        mockRandomService = jasmine.createSpyObj('RandomModeService', ['getQuestionsQcm', 'hasEnoughQuestionsQcm', 'getQuizRandom']);
        mockMatDialog = jasmine.createSpyObj('MatDialog', ['open']);
        TestBed.configureTestingModule({
            declarations: [AccordeonComponent],
            imports: [BrowserAnimationsModule, CdkAccordionModule],
            providers: [
                { provide: QuizService, useValue: mockQuizService },
                { provide: RandomModeService, useValue: mockRandomService },
                { provide: MatDialog, useValue: mockMatDialog },
            ],
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
        }).compileComponents();
    }));

    beforeEach(() => {
        mockQuizService.getAllQuiz.and.returnValue(of(MOCK_QUIZZES));
        mockQuizService.getQuizVisibility.and.returnValue(of(true));
        mockRandomService.getQuestionsQcm.and.returnValue(of(MOCK_QUESTIONS));
        mockRandomService.hasEnoughQuestionsQcm.and.returnValue(true);
        const mockQuizRandom = { ...MOCK_QUIZ };
        mockQuizRandom.id = '1-random';
        mockRandomService.getQuizRandom.and.returnValue(mockQuizRandom);
        fixture = TestBed.createComponent(AccordeonComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    afterEach(() => {
        fixture.destroy();
    });

    it('should animate the header when expanded', () => {
        expect(component.headerAnimation).toBe('collapsed');
        component['expandedIndex'] = 1;
        fixture.detectChanges();
        expect(component.headerAnimation).toBe('expanded');
    });

    it('should load quizzes on initialization', () => {
        mockRandomService.hasEnoughQuestionsQcm.and.returnValue(true);
        const mockQuizzes = MOCK_QUIZZES.slice();
        const mockQuizRandom = { ...MOCK_QUIZ };
        mockQuizRandom.id = '1-random';

        mockQuizzes.unshift(mockQuizRandom);
        expect(component['quizzes']).toEqual(mockQuizzes);
    });

    it('should set quiz visibility to true', () => {
        const mockQuizId = '1';

        component['getQuizVisibility'](mockQuizId);
        expect(component['quizVisibilities'].get(mockQuizId)).toBeTrue();
    });

    it('should set quiz visibility to false', () => {
        const mockQuizId = '1';
        mockQuizService.getQuizVisibility.and.returnValue(of(false));
        component['getQuizVisibility'](mockQuizId);
        expect(component['quizVisibilities'].get(mockQuizId)).toBeFalse();
    });

    it('should return true for visible quiz', () => {
        const mockQuizId = '1';
        component['quizVisibilities'].set(mockQuizId, true);
        const isVisible = component['isVisible'](mockQuizId);
        expect(isVisible).toBeTrue();
    });

    it('should return false for invisible quiz', () => {
        const mockQuizId = '1';
        component['quizVisibilities'].set(mockQuizId, false);
        const isVisible = component['isVisible'](mockQuizId);
        expect(isVisible).toBeFalse();
    });
});
