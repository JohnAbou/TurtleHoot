import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, HostBinding, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogueTextComponent } from '@app/components/dialogue-text/dialogue-text.component';
import { QuizService } from '@app/services/http-services/quiz.service';
import { RandomModeService } from '@app/services/random-mode.service';
import { Question, QuestionType, Quiz } from '@common/quiz';

@Component({
    selector: 'app-accordeon',
    templateUrl: './accordeon.component.html',
    styleUrls: ['./accordeon.component.scss'],
    animations: [
        trigger('headerAnimation', [
            state('collapsed', style({ height: '40px' })),
            state('expanded', style({ height: '20px' })),
            transition('collapsed <=> expanded', animate('0.3s ease-in-out')),
        ]),
    ],
})
export class AccordeonComponent implements OnInit {
    @Input() quiz: Quiz;
    protected quizzes: Quiz[] = [];
    private randomQuiz: Quiz;
    private expandedIndex = 0;
    private quizVisibilities: Map<string, boolean> = new Map<string, boolean>();
    private quizIds: string[] = [];
    constructor(
        private randomModeService: RandomModeService,
        private quizService: QuizService,
        public dialog: MatDialog,
    ) {}

    @HostBinding('@headerAnimation')
    get headerAnimation() {
        return this.expandedIndex === 0 ? 'collapsed' : 'expanded';
    }

    async ngOnInit(): Promise<void> {
        this.loadQuizzesAndVisibilities();
    }

    protected openDialog(quiz: Quiz) {
        this.dialog.open(DialogueTextComponent, {
            data: quiz,
        });
    }

    protected isVisible(quizId: string): boolean {
        return this.quizVisibilities.get(quizId) || false;
    }
    private loadQuizzesAndVisibilities() {
        this.quizService.getAllQuiz().subscribe({
            next: (data) => {
                this.quizzes = data.filter((quiz) => !quiz.id.includes('-random'));
                this.quizIds = this.getAllIds(this.quizzes);
                this.loadVisibilities();
                this.addRandomQuiz();
            },
        });
    }

    private loadVisibilities() {
        this.quizIds.forEach((quizId) => {
            this.getQuizVisibility(quizId);
        });
    }

    private getAllIds(quizzes: Quiz[]): string[] {
        return quizzes.map((quiz) => quiz.id);
    }

    private getQuizVisibility(quizId: string) {
        this.quizService.getQuizVisibility(quizId).subscribe({
            next: (visibility) => {
                if (visibility) {
                    this.quizVisibilities.set(quizId, true);
                } else {
                    this.quizVisibilities.set(quizId, false);
                }
            },
        });
    }

    private addRandomQuiz() {
        this.randomModeService.getQuestionsQcm().subscribe((data) => {
            const questionsQcm = data.filter((question: Question) => question.type === QuestionType.QCM);

            if (this.randomModeService.hasEnoughQuestionsQcm(questionsQcm)) {
                this.randomQuiz = this.randomModeService.getQuizRandom(questionsQcm);
                this.quizzes.unshift(this.randomQuiz);
                this.quizVisibilities.set(this.randomQuiz.id, true);
            }
        });
    }
}
