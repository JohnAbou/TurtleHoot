import { Component, OnDestroy, OnInit } from '@angular/core';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ChatEvent, ConnectionEvent } from '@common/event-name';
import { AnswerState, Player, PlayerState, PlayerWithStatus } from '@common/player';
import { SortOption } from '@common/player-list-sort';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-player-list',
    templateUrl: './player-list.component.html',
    styleUrls: ['./player-list.component.scss'],
})
export class PlayerListComponent implements OnInit, OnDestroy {
    sortOption = SortOption;
    protected answerState = AnswerState;
    protected sortingOption: SortOption = SortOption.Username;
    protected sortingDirection: 'asc' | 'desc' = 'asc';
    protected players: PlayerWithStatus[] = [];
    private playerLeftSubscription: Subscription;

    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        private socketClientService: SocketClientService,
        private gameService: GameService,
        private popUpService: PopUpService,
    ) {}

    ngOnInit(): void {
        this.sortingOption = this.gameService.currentSortOption;
        this.sortingDirection = this.gameService.sortingDirection;
        this.playerLeftSubscription = this.gameService.playersChangedEvent.subscribe((updatedPlayers: PlayerWithStatus[]) => {
            this.players = updatedPlayers.filter((player) => player.role !== PlayerState.Organizer);
            if (this.gameService.filterPlayers(this.players).length === 0) {
                this.handleNoPlayers();
            }
            this.sortPlayers();
        });

        this.players = this.gameService.getPlayers().filter((player) => player.role !== PlayerState.Organizer);
        if (this.gameService.filterPlayers(this.players).length === 0) {
            this.handleNoPlayers();
        }
        this.sortPlayers();
    }

    ngOnDestroy(): void {
        if (this.playerLeftSubscription) {
            this.playerLeftSubscription.unsubscribe();
        }
        this.gameService.currentSortOption = this.sortingOption;
        this.gameService.sortingDirection = this.sortingDirection;
    }

    protected sortToggled(option: SortOption) {
        if (this.sortingOption === option) {
            this.sortingDirection = this.sortingDirection === 'asc' ? 'desc' : 'asc';
        } else {
            this.sortingOption = option;
            this.sortingDirection = 'asc';
        }
        this.sortPlayers();
    }

    protected toggleMute(player: Player): void {
        player.isMuted = !player.isMuted;
        this.socketClientService.send(ChatEvent.TOOGLE_MUTE_PLAYER, player.id);
    }

    private handleNoPlayers() {
        this.socketClientService.send(ConnectionEvent.LEAVE_ROOM);
        this.popUpService.openGameEnded('Partie terminée', 'Tous les joueurs ont quitté la partie', '/create');
    }

    private sortPlayers(): void {
        switch (this.sortingOption) {
            case SortOption.Points:
                this.sortByPoints();
                break;
            case SortOption.Username:
                this.sortByUsername();
                break;
            case SortOption.AnswerState:
                this.sortByAnswerState();
                break;
            default:
                break;
        }
    }

    private sortByPoints() {
        this.players.sort((a, b) => {
            if (b.points === a.points) {
                return a.username.localeCompare(b.username);
            }
            return this.sortingDirection === 'asc' ? b.points - a.points : a.points - b.points;
        });
    }
    private sortByUsername() {
        this.players.sort((a, b) => (this.sortingDirection === 'asc' ? a.username.localeCompare(b.username) : b.username.localeCompare(a.username)));
    }
    private sortByAnswerState() {
        this.players.sort((a, b) => {
            if (b.answerState === a.answerState) {
                return a.username.localeCompare(b.username);
            }
            return this.sortingDirection === 'asc' ? b.answerState - a.answerState : a.answerState - b.answerState;
        });
    }
}
