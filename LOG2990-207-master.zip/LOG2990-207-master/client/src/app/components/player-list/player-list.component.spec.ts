import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { PopUpComponent } from '@app/components/pop-up/pop-up.component';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { MOCK_QUIZ } from '@common/constants';
import { AnswerState, PlayerState, PlayerWithStatus } from '@common/player';
import { SortOption } from '@common/player-list-sort';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { Subject, of } from 'rxjs';
import { Socket } from 'socket.io-client';
import { PlayerListComponent } from './player-list.component';
import SpyObj = jasmine.SpyObj;
describe('PlayerListComponent', () => {
    let component: PlayerListComponent;
    let fixture: ComponentFixture<PlayerListComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;
    let mockActivatedRoute;
    let gameServiceSpy: SpyObj<GameService>;
    let popUpService: SpyObj<PopUpService>;

    beforeEach(() => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;

        popUpService = jasmine.createSpyObj('PopUpService', ['openGameEnded']);
        gameServiceSpy = jasmine.createSpyObj('GameService', [
            'getPlayers',
            'filterPlayers',
            'configureBaseSocketFeatures',
            'unsubscribeFromSocketFeatures',
        ]);
        const mockPlayers: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                role: PlayerState.Player,
                nBonus: 0,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                id: '2',
                username: 'Player 2',
                role: PlayerState.Player,
                nBonus: 0,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
        ];
        gameServiceSpy.getPlayers.and.returnValue(mockPlayers);
        gameServiceSpy.filterPlayers.and.returnValue(mockPlayers);
        const mockPlayersChangedEvent = new Subject<PlayerWithStatus[]>();
        gameServiceSpy.playersChangedEvent = mockPlayersChangedEvent;

        mockActivatedRoute = {
            queryParams: of({ gameId: 'testGameId' }),
        };

        TestBed.configureTestingModule({
            declarations: [PlayerListComponent, PopUpComponent],
            imports: [HttpClientTestingModule, MatDialogModule, NgxChartsModule, BrowserAnimationsModule, MatListModule, MatDividerModule],
            providers: [
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                { provide: SocketClientService, useValue: socketServiceMock },
                { provide: GameService, useValue: gameServiceSpy },
                { provide: PopUpService, useValue: popUpService },
            ],
        }).compileComponents();

        fixture = TestBed.createComponent(PlayerListComponent);
        component = fixture.componentInstance;
        component['gameService'].gameQuiz = MOCK_QUIZ;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should update players when playersChangedEvent is emitted', () => {
        const updatedPlayers: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                role: PlayerState.Player,
                nBonus: 0,
                points: 30,
                isPlaying: true,
                answerState: AnswerState.default,
                isMuted: false,
            },
        ];

        gameServiceSpy.filterPlayers.and.returnValue(updatedPlayers);

        const playersChangedEvent = new Subject<PlayerWithStatus[]>();
        gameServiceSpy.playersChangedEvent = playersChangedEvent;

        component.ngOnInit();

        playersChangedEvent.next(updatedPlayers);

        expect(component['players']).toEqual(updatedPlayers);
    });

    it('should end game when playersChangedEvent is emitted with 0 players', () => {
        const updatedPlayers: PlayerWithStatus[] = [];
        gameServiceSpy.filterPlayers.and.returnValue([]);

        const playersChangedEvent = new Subject<PlayerWithStatus[]>();
        gameServiceSpy.playersChangedEvent = playersChangedEvent;

        component.ngOnInit();

        playersChangedEvent.next(updatedPlayers);

        expect(component['players']).toEqual(updatedPlayers);
    });
    it('should handle no players correctly', () => {
        const handleNoPlayersSpy = jasmine.createSpy('handleNoPlayers');

        Object.defineProperty(component, 'handleNoPlayers', { value: handleNoPlayersSpy });
        gameServiceSpy.filterPlayers.and.returnValue([]);
        component.ngOnInit();

        expect(handleNoPlayersSpy).toHaveBeenCalled();
    });
    it('should toggle sorting direction when sortToggled is called', () => {
        component['sortingDirection'] = 'asc';
        component['sortingOption'] = SortOption.Username;

        component['sortToggled'](SortOption.Username);
        expect(component['sortingDirection']).toEqual('desc');

        component['sortToggled'](SortOption.Username);
        expect(component['sortingDirection']).toEqual('asc');

        component['sortToggled'](SortOption.Points);
        expect(component['sortingDirection']).toEqual('asc');
    });

    describe('sorting', () => {
        beforeEach(() => {
            const unsortedPlayers: PlayerWithStatus[] = [
                {
                    id: '1',
                    username: 'B',
                    points: 20,
                    nBonus: 0,
                    role: PlayerState.Player,
                    answerState: AnswerState.default,
                    isMuted: false,
                    isPlaying: true,
                },
                {
                    id: '2',
                    username: 'A',
                    points: 10,
                    nBonus: 0,
                    role: PlayerState.Player,
                    answerState: AnswerState.hasAnswered,
                    isMuted: false,
                    isPlaying: true,
                },
                {
                    id: '3',
                    username: 'C',
                    points: 10,
                    nBonus: 0,
                    role: PlayerState.Player,
                    answerState: AnswerState.hasAnswered,
                    isMuted: false,
                    isPlaying: true,
                },
            ];

            component['players'] = JSON.parse(JSON.stringify(unsortedPlayers));
        });
        it('should sort players correctly based on username', () => {
            component['sortingOption'] = SortOption.Username;
            component['sortingDirection'] = 'asc';
            component['sortPlayers']();

            expect(component['players'][0].username).toEqual('A');
            expect(component['players'][1].username).toEqual('B');
            expect(component['players'][2].username).toEqual('C');

            component['sortingOption'] = SortOption.Username;
            component['sortingDirection'] = 'desc';
            component['sortPlayers']();

            expect(component['players'][0].username).toEqual('C');
            expect(component['players'][1].username).toEqual('B');
            expect(component['players'][2].username).toEqual('A');
        });
        it('should sort players correctly based on points', () => {
            component['sortingOption'] = SortOption.Points;
            component['sortingDirection'] = 'desc';
            component['sortPlayers']();

            expect(component['players'][0].username).toEqual('A');
            expect(component['players'][1].username).toEqual('C');
            expect(component['players'][2].username).toEqual('B');

            component['sortingOption'] = SortOption.Points;
            component['sortingDirection'] = 'asc';
            component['sortPlayers']();

            expect(component['players'][0].username).toEqual('B');
            expect(component['players'][1].username).toEqual('A');
            expect(component['players'][2].username).toEqual('C');
        });

        it('should sort players correctly when sortPlayers is called', () => {
            component['sortingOption'] = SortOption.AnswerState;
            component['sortingDirection'] = 'asc';
            component['sortPlayers']();

            expect(component['players'][0].username).toEqual('A');
            expect(component['players'][1].username).toEqual('C');
            expect(component['players'][2].username).toEqual('B');

            component['sortingOption'] = SortOption.AnswerState;
            component['sortingDirection'] = 'desc';
            component['sortPlayers']();

            expect(component['players'][0].username).toEqual('B');
            expect(component['players'][1].username).toEqual('A');
            expect(component['players'][2].username).toEqual('C');
        });
    });

    it('should toggle mute state of player when toggleMute is called', () => {
        const player: PlayerWithStatus = {
            id: '1',
            username: 'TestPlayer',
            points: 0,
            nBonus: 0,
            role: PlayerState.Player,
            answerState: AnswerState.default,
            isMuted: false,
            isPlaying: true,
        };

        component['toggleMute'](player);

        expect(player.isMuted).toEqual(true);

        component['toggleMute'](player);

        expect(player.isMuted).toEqual(false);
    });
});
