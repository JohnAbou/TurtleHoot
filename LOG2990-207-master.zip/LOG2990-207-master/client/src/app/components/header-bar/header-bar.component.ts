import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ConnectionEvent } from '@common/event-name';

@Component({
    selector: 'app-header-bar',
    templateUrl: './header-bar.component.html',
    styleUrls: ['./header-bar.component.scss'],
})
export class HeaderBarComponent {
    constructor(
        private router: Router,
        public socketClientService: SocketClientService,
    ) {}
    protected changePage() {
        this.socketClientService.send(ConnectionEvent.LEAVE_ROOM);
        this.router.navigate(['/home']);
    }
}
