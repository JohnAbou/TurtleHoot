import { ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { Router } from '@angular/router';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ConnectionEvent } from '@common/event-name';
import { HeaderBarComponent } from './header-bar.component';
import SpyObj = jasmine.SpyObj;

describe('HeaderBarComponent', () => {
    let component: HeaderBarComponent;
    let fixture: ComponentFixture<HeaderBarComponent>;
    let routerSpy: SpyObj<Router>;
    let socketClientService: SocketClientService;

    beforeEach(async () => {
        routerSpy = jasmine.createSpyObj('Router', ['navigate']);
        await TestBed.configureTestingModule({
            imports: [],
            declarations: [HeaderBarComponent],
            providers: [{ provide: Router, useValue: routerSpy }, SocketClientService],
        }).compileComponents();

        fixture = TestBed.createComponent(HeaderBarComponent);
        component = fixture.componentInstance;
        socketClientService = TestBed.inject(SocketClientService);
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should navigate to home page on changePage()', fakeAsync(() => {
        spyOn(socketClientService, 'send');
        component['changePage']();
        expect(socketClientService.send).toHaveBeenCalledWith(ConnectionEvent.LEAVE_ROOM);
        expect(routerSpy.navigate).toHaveBeenCalledWith(['/home']);
    }));
});
