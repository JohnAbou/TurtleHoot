import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { AnswerEvent } from '@common/event-name';
import { Grade } from '@common/grade';
import { PlayerAnswerQrl } from '@common/room';

@Component({
    selector: 'app-review',
    templateUrl: './review.component.html',
    styleUrls: ['./review.component.scss'],
})
export class ReviewComponent implements OnInit, OnDestroy {
    @Input() playerAnswers: PlayerAnswerQrl[] = [];
    @Input() questionIndex: number;
    @Output() evaluationFinished: EventEmitter<void> = new EventEmitter<void>();
    protected answerIndex: number;
    private gradesGiven: Grade[] = [];
    constructor(public socketClientService: SocketClientService) {}

    ngOnInit() {
        this.socketClientService.on<PlayerAnswerQrl[]>(AnswerEvent.PLAYER_QRL_ANSWERS, (data: PlayerAnswerQrl[]) => {
            this.playerAnswers = data.sort((a, b) => a.username.localeCompare(b.username));
        });
        this.socketClientService.send(AnswerEvent.START_EVALUATION);
        this.answerIndex = 0;
    }

    ngOnDestroy(): void {
        this.socketClientService.off(AnswerEvent.PLAYER_QRL_ANSWERS);
    }

    protected giveGrade(multiplier: number) {
        this.gradesGiven.push({ points: multiplier, playerId: this.playerAnswers[this.answerIndex].playerId });
        if (this.answerIndex === this.playerAnswers.length - 1) {
            this.handleLastAnswer();
        } else {
            this.nextAnswer();
        }
    }

    private handleLastAnswer() {
        const DECIMAL_DIVIDER = 100;
        this.socketClientService.send(AnswerEvent.FINISHED_CORRECTING, {
            grades: this.gradesGiven,
            questionIndex: this.questionIndex,
            questionValue: this.playerAnswers[this.answerIndex].questionValue,
        });
        for (const gradeGiven of this.gradesGiven) {
            gradeGiven.points = (gradeGiven.points / DECIMAL_DIVIDER) * this.playerAnswers[this.answerIndex].questionValue;
        }
        this.answerIndex++;
        this.evaluationFinished.emit();
    }

    private nextAnswer() {
        if (this.answerIndex !== this.playerAnswers.length) {
            this.answerIndex++;
        }
    }
}
