import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { AnswerEvent } from '@common/event-name';
import { GRADE } from '@common/grade';
import { PlayerAnswerQrl } from '@common/room';
import { Socket } from 'socket.io-client';
import { ReviewComponent } from './review.component';

describe('ReviewComponent', () => {
    let component: ReviewComponent;
    let fixture: ComponentFixture<ReviewComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;

    beforeEach(() => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;
        TestBed.configureTestingModule({
            declarations: [ReviewComponent],
            providers: [{ provide: SocketClientService, useValue: socketServiceMock }],
        });
        fixture = TestBed.createComponent(ReviewComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should unsubscribe from socketClientService on ngOnDestroy', () => {
        spyOn(component['socketClientService'], 'off');
        spyOn(component, 'ngOnDestroy').and.callThrough();
        component.ngOnDestroy();
        expect(component['socketClientService'].off).toHaveBeenCalledWith(AnswerEvent.PLAYER_QRL_ANSWERS);
    });

    it('should initialize correctly on ngOnInit', () => {
        const mockPlayerAnswers: PlayerAnswerQrl[] = [{ playerId: '1', username: 'user1', questionValue: 10, text: '' }];
        spyOn(component['socketClientService'], 'on');
        spyOn(component['socketClientService'], 'send');

        spyOn(component.evaluationFinished, 'emit');
        component.ngOnInit();
        component['answerIndex'] = 0;
        component.playerAnswers = mockPlayerAnswers;
        expect(component.playerAnswers).toEqual(mockPlayerAnswers);
        expect(component['answerIndex']).toEqual(0);
        expect(component['socketClientService'].on).toHaveBeenCalledWith(AnswerEvent.PLAYER_QRL_ANSWERS, jasmine.any(Function));
        expect(component['socketClientService'].send).toHaveBeenCalledWith(AnswerEvent.START_EVALUATION);
    });

    it('should handle give method correctly', () => {
        const mockPlayerAnswers: PlayerAnswerQrl[] = [
            { playerId: '1', username: 'user1', questionValue: 10, text: '' },
            { playerId: '2', username: 'user2', questionValue: 20, text: '' },
        ];
        component.playerAnswers = mockPlayerAnswers;
        spyOn(component.evaluationFinished, 'emit');

        component['giveGrade'](GRADE.half_grade);
        component['giveGrade'](GRADE.full_grade);
        expect(component['answerIndex']).toEqual(2);
        expect(component.evaluationFinished.emit).toHaveBeenCalled();
    });

    it('should handle nextAnswer method correctly', () => {
        component.playerAnswers = [
            { playerId: '1', username: 'user1', questionValue: 10, text: '' },
            { playerId: '2', username: 'user2', questionValue: 20, text: '' },
        ];
        component['answerIndex'] = 0;

        component['nextAnswer']();
        expect(component['answerIndex']).toEqual(1);

        component['nextAnswer']();
        expect(component['answerIndex']).toEqual(2);
    });

    it('should handle playerQrlAnswers event correctly', () => {
        const mockPlayerAnswers: PlayerAnswerQrl[] = [
            { playerId: '1', username: 'a', questionValue: 10, text: '' },
            { playerId: '2', username: 'b', questionValue: 20, text: '' },
        ];

        socketHelper.peerSideEmit(AnswerEvent.PLAYER_QRL_ANSWERS, mockPlayerAnswers);

        expect(component.playerAnswers).toEqual(mockPlayerAnswers.sort((a, b) => a.username.localeCompare(b.username)));
    });
});
