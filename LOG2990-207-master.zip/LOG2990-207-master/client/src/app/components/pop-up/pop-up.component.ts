import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DialogButton } from '@common/dialog-button';

@Component({
    selector: 'app-dialogue-text',
    templateUrl: './pop-up.component.html',
    styleUrls: ['./pop-up.component.scss'],
})
export class PopUpComponent {
    constructor(
        public dialogRef: MatDialogRef<PopUpComponent>,
        @Inject(MAT_DIALOG_DATA) public data: { title: string; text: string; buttons: DialogButton[] },
    ) {}

    protected onButtonClick(action?: () => void): void {
        if (action) {
            action();
        }
        this.dialogRef.close();
    }
}
