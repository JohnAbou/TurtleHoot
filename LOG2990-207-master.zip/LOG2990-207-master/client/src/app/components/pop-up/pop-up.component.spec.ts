import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { PopUpComponent } from './pop-up.component';
import SpyObj = jasmine.SpyObj;

describe('PopUpComponent', () => {
    let component: PopUpComponent;
    let fixture: ComponentFixture<PopUpComponent>;
    let dialogRefSpy: SpyObj<MatDialogRef<PopUpComponent>>;

    beforeEach(async () => {
        dialogRefSpy = jasmine.createSpyObj('MatDialogRef', ['close']);
        await TestBed.configureTestingModule({
            declarations: [PopUpComponent],
            providers: [
                { provide: MatDialogRef, useValue: dialogRefSpy },
                {
                    provide: MAT_DIALOG_DATA,
                    useValue: {
                        title: 'Test Title',
                        text: 'Test Text',
                    },
                },
            ],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(PopUpComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should close dialog on close button click', () => {
        component['onButtonClick']();
        expect(dialogRefSpy.close).toHaveBeenCalled();
    });

    it('should call action and close dialog on button click', () => {
        const actionSpy = jasmine.createSpy('action');
        component['onButtonClick'](actionSpy);
        expect(actionSpy).toHaveBeenCalled();
        expect(component.dialogRef.close).toHaveBeenCalled();
    });

    it('should initialize with correct title and text', () => {
        expect(component.data.title).toEqual('Test Title');
        expect(component.data.text).toEqual('Test Text');
    });
});
