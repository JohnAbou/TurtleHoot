import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Choice, Question, QuestionType } from '@common/quiz';
import { FormService } from 'src/app/services/form-validation.service';

@Component({
    selector: 'app-form',
    templateUrl: './form.component.html',
    styleUrls: ['./form.component.scss'],
})
export class FormComponent {
    protected typeQst: boolean = true;
    protected nChoices: number = 2;
    protected checkboxesState: boolean[] = [];
    protected responseValues: string[] = [];
    protected text: string = '';
    protected points: number;
    private question: Question;
    private cancel = false;
    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        public dialogRef: MatDialogRef<FormComponent>,
        private formService: FormService,
        private snackBar: MatSnackBar,
        @Inject(MAT_DIALOG_DATA) public data: { question: Question },
    ) {
        this.question = data.question;
        this.typeQst = this.question.type === QuestionType.QCM ? true : false;
        this.text = this.question.text;
        if (this.question.choices) {
            this.nChoices = this.question.choices.length;
            this.responseValues = this.question.choices.map((choice: Choice) => choice.text);
            this.checkboxesState = this.question.choices.map((choice: Choice) => choice.isCorrect);
            this.points = this.question.points;
        }
    }

    protected cancelForm() {
        this.cancel = true;
        this.dialogRef.close(this.cancel);
    }

    protected getRange(nChoices: number): number[] {
        return Array.from({ length: nChoices }, (_, index) => index + 1);
    }

    protected updateCheckboxState(index: number, isChecked: boolean) {
        this.checkboxesState[index] = isChecked;
    }

    protected onNumberOfResponsesChange(event: Event) {
        this.nChoices = parseInt((event.target as HTMLSelectElement).value, 10);
    }

    protected moveResponseUp(index: number) {
        if (index > 0) {
            const tempResponse = this.responseValues[index];
            this.responseValues[index] = this.responseValues[index - 1];
            this.responseValues[index - 1] = tempResponse;
            const tempCheckboxState = this.checkboxesState[index];
            this.checkboxesState[index] = this.checkboxesState[index - 1];
            this.checkboxesState[index - 1] = tempCheckboxState;
        }
    }

    protected moveResponseDown(index: number) {
        if (index < this.responseValues.length - 1) {
            const tempResponse = this.responseValues[index];
            this.responseValues[index] = this.responseValues[index + 1];
            this.responseValues[index + 1] = tempResponse;
            const tempCheckboxState = this.checkboxesState[index];
            this.checkboxesState[index] = this.checkboxesState[index + 1];
            this.checkboxesState[index + 1] = tempCheckboxState;
        }
    }

    protected onSubmit() {
        this.updateQuestion();
        if (this.typeQst) {
            this.handleQCMType();
        } else {
            this.handleQRLType();
        }
    }

    protected deleteChoice(index: number) {
        if (this.nChoices > 2) {
            this.responseValues.splice(index, 1);
            this.checkboxesState.splice(index, 1);
            this.nChoices--;
        } else {
            this.snackBar.open('Il faut au moins 2 choix de réponses!', 'OK');
        }
    }

    private updateQuestion() {
        this.question.text = this.text;
        this.question.points = this.points;
    }

    private handleQCMType() {
        if (this.formService.isAtLeastOne(true, this.checkboxesState) && this.formService.isAtLeastOne(false, this.checkboxesState)) {
            this.updateQCMQuestion();
            this.dialogRef.close(this.question);
        } else if (!this.formService.isAtLeastOne(true, this.checkboxesState)) {
            this.snackBar.open('Il faut au moins une bonne réponse.', 'OK');
        } else {
            this.snackBar.open('Il faut au moins une mauvaise réponse.', 'OK');
        }
    }

    private updateQCMQuestion() {
        this.question.type = QuestionType.QCM;
        this.question.choices = [];
        for (let i = 0; i < this.nChoices; i++) {
            const text = this.responseValues[i];
            const isCorrect = this.checkboxesState[i] ?? false;
            this.question.choices.push({ text, isCorrect });
        }
        this.question.choices.length = this.nChoices;
    }

    private handleQRLType() {
        this.question.type = QuestionType.QRL;
        this.question.choices = [];
        this.dialogRef.close(this.question);
    }
}
