import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormService } from '@app/services/form-validation.service';
import { QuestionType } from '@common/quiz';
import { FormComponent } from './form.component';

describe('FormComponent', () => {
    let component: FormComponent;
    let fixture: ComponentFixture<FormComponent>;
    let dialogRefSpy: jasmine.SpyObj<MatDialogRef<FormComponent>>;
    let formServiceSpy: jasmine.SpyObj<FormService>;
    let mockDialogRef: jasmine.SpyObj<MatDialogRef<FormComponent>>;
    let mockFormService: jasmine.SpyObj<FormService>;
    let mockSnackBar: jasmine.SpyObj<MatSnackBar>;

    beforeEach(async () => {
        dialogRefSpy = jasmine.createSpyObj('MatDialogRef', ['close']);
        formServiceSpy = jasmine.createSpyObj('FormService', ['isAtLeastOne']);

        await TestBed.configureTestingModule({
            declarations: [FormComponent],
            imports: [
                FormsModule,
                MatDialogModule,
                MatRadioModule,
                MatCheckboxModule,
                MatFormFieldModule,
                MatInputModule,
                BrowserAnimationsModule,
                NoopAnimationsModule,
                MatIconModule,
                MatSnackBarModule,
            ],
            providers: [
                { provide: MatDialogRef, useValue: dialogRefSpy },
                { provide: FormService, useValue: formServiceSpy },
                {
                    provide: MAT_DIALOG_DATA,
                    useValue: {
                        question: {
                            type: QuestionType.QCM,
                            text: 'Question',
                            choices: [
                                { text: 'Choice 1', isCorrect: true },
                                { text: 'Choice 2', isCorrect: false },
                            ],
                        },
                    },
                },
            ],
            schemas: [NO_ERRORS_SCHEMA],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(FormComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should generate range based on nChoices', () => {
        component['nChoices'] = 3;
        expect(component['getRange'](3)).toEqual([1, 2, 3]);
    });

    it('should update checkbox state correctly', () => {
        component['checkboxesState'] = [false, false, false];
        component['updateCheckboxState'](0, true);
        expect(component['checkboxesState'][0]).toBeTrue();
    });

    it('should move response up correctly', () => {
        component['responseValues'] = ['A', 'B', 'C'];
        component['checkboxesState'] = [true, false, true];
        component['moveResponseUp'](1);
        expect(component['responseValues']).toEqual(['B', 'A', 'C']);
        expect(component['checkboxesState']).toEqual([false, true, true]);
    });

    it('should move response down correctly', () => {
        component['responseValues'] = ['A', 'B', 'C'];
        component['checkboxesState'] = [true, false, true];
        component['moveResponseDown'](1);
        expect(component['responseValues']).toEqual(['A', 'C', 'B']);
        expect(component['checkboxesState']).toEqual([true, true, false]);
    });

    it('should update nChoices when number of responses changes', () => {
        const expectedValue = 5;
        const eventMock = {
            target: {
                value: '5',
            },
        } as unknown;

        component['onNumberOfResponsesChange'](eventMock as Event);

        expect(component['nChoices']).toEqual(expectedValue);
    });
    it('should handle form submission for QRL type', () => {
        component.dialogRef = jasmine.createSpyObj('MatDialogRef', ['close']);

        component['typeQst'] = false;

        component['onSubmit']();

        expect(component.dialogRef.close).toHaveBeenCalledWith(component['question']);
    });
    it('should initialize typeQst correctly based on question type', () => {
        const mockData = {
            question: {
                type: QuestionType.QRL,
                text: 'Sample question text',
                choices: [],
                points: 0,
                id: '',
                lastModification: '',
            },
        };
        const formComponent = new FormComponent(mockDialogRef, mockFormService, mockSnackBar, mockData);
        expect(formComponent['typeQst']).toBeFalse();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(FormComponent);
        component = fixture.componentInstance;
    });

    it('should handle form submission for QCM type with no correct answers', () => {
        spyOn(component['snackBar'], 'open').and.callThrough();
        component['typeQst'] = true;
        component['checkboxesState'] = [false, false, false];

        component['onSubmit']();
        expect(component['snackBar'].open).toHaveBeenCalledWith('Il faut au moins une bonne réponse.', 'OK');
        expect(dialogRefSpy.close).not.toHaveBeenCalled();
    });

    it('should handle form submission for QRL type', () => {
        component['typeQst'] = false;
        component['onSubmit']();

        expect(dialogRefSpy.close).toHaveBeenCalledWith(component['question']);
    });

    it('should return the question if the form is submitted for QCM type with no errors', () => {
        formServiceSpy.isAtLeastOne.and.returnValue(true);
        component['nChoices'] = 3;
        component['typeQst'] = true;
        component['onSubmit']();
        expect(dialogRefSpy.close).toHaveBeenCalled();
    });

    it('should remove choice and checkbox state', () => {
        component['nChoices'] = 3;
        component['responseValues'] = ['Choice 1', 'Choice 2', 'Choice 3'];
        component['checkboxesState'] = [true, false, true];
        component['deleteChoice'](1);
        expect(component['nChoices']).toBe(2);
        expect(component['responseValues']).toEqual(['Choice 1', 'Choice 3']);
        expect(component['checkboxesState']).toEqual([true, true]);
    });

    it('should not remove choice if the question only has 2 choices', () => {
        spyOn(component['snackBar'], 'open').and.callThrough();
        component['nChoices'] = 2;
        component['responseValues'] = ['Choice 1', 'Choice 2'];
        component['checkboxesState'] = [true, true];
        component['deleteChoice'](1);
        expect(component['nChoices']).toBe(2);
        expect(component['responseValues']).toEqual(['Choice 1', 'Choice 2']);
        expect(component['checkboxesState']).toEqual([true, true]);
        expect(component['snackBar'].open).toHaveBeenCalledWith('Il faut au moins 2 choix de réponses!', 'OK');
    });
});
