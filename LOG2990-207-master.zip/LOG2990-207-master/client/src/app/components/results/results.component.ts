import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { HistogramService } from '@app/services/histogram.service';
import { RES_HISTOGRAM_DIMENSIONS } from '@common/constants';
import { AnswerEvent, ConnectionEvent, GameEvent } from '@common/event-name';
import { PlayerWithStatus } from '@common/player';
import { Choice, Question, QuestionType } from '@common/quiz';
import { SingleItem } from '@common/single';

import { Color, ScaleType } from '@swimlane/ngx-charts';

@Component({
    selector: 'app-results',
    templateUrl: './results.component.html',
    styleUrls: ['./results.component.scss'],
})
export class ResultsComponent implements OnInit, OnDestroy {
    protected players: PlayerWithStatus[];
    protected questions: Question[];
    protected questionIndex: number = 0;
    protected showScores: boolean = false;
    protected view: [number, number] = [RES_HISTOGRAM_DIMENSIONS.width, RES_HISTOGRAM_DIMENSIONS.height];
    protected single: SingleItem[] = [];
    protected yAxisTicks: number[] = [];
    protected xAxisLabel: string = 'reponses';
    protected yAxisLabel: string = 'nombre de joueur';

    protected colorScheme: Color = {
        domain: [],
        name: 'color',
        selectable: true,
        group: ScaleType.Ordinal,
    };
    private roomAnswers: number[][];
    private gameId: string;
    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        private route: ActivatedRoute,
        public gameService: GameService,
        public socketService: SocketClientService,
        public router: Router,
        private cdr: ChangeDetectorRef,
        private histogramService: HistogramService,
    ) {}

    ngOnInit(): void {
        this.route.queryParams.subscribe((params) => {
            const gameId = params['gameId'];
            if (gameId) {
                this.gameId = gameId;
            }
        });
        this.socketService.send(GameEvent.VERIFY_ACCESS_TO_GAME, this.gameId);
        this.socketService.on<boolean>(GameEvent.ACCESS_TO_GAME, (access: boolean) => {
            if (access) {
                this.letIntoResults();
            } else {
                this.socketService.send(ConnectionEvent.LEAVE_ROOM);
                this.router.navigate(['/home']);
            }
        });
    }

    ngOnDestroy() {
        this.socketService.off(AnswerEvent.ROOM_ANSWERS);
        this.socketService.off(GameEvent.ACCESS_TO_GAME);
    }

    protected yAxisTickFormatting(value: number): string {
        return value.toString();
    }

    protected leaveGame() {
        this.questionIndex = 0;
        this.socketService.send(ConnectionEvent.LEAVE_ROOM);
        this.router.navigate(['/home']);
    }

    protected nextQuestion() {
        this.questionIndex++;
        this.updateChartData();
    }

    protected previousQuestion() {
        this.questionIndex--;
        this.updateChartData();
    }

    private letIntoResults() {
        const originalPlayers = this.gameService.getSortedPlayers();
        this.players = originalPlayers.filter((player) => player.isPlaying);
        this.questions = this.gameService.gameQuiz.questions;
        this.socketService.send(AnswerEvent.GET_ROOM_ANSWERS);
        this.socketService.on<number[][]>(AnswerEvent.ROOM_ANSWERS, (roomAnswers: number[][]) => {
            this.roomAnswers = roomAnswers;
            this.questionIndex = 0;
            this.setYAxisTicks();
            this.updateChartData();
        });
        this.showScores = true;
    }

    private setYAxisTicks() {
        for (let i = 0; i <= this.players.length; i++) {
            this.yAxisTicks.push(i);
        }
    }

    private updateChartData(): void {
        const question = this.questions[this.questionIndex];
        if (question) {
            this.single = [];
            this.colorScheme.domain = [];

            this.cdr.detectChanges();
            if (question.choices && question.type === QuestionType.QCM) {
                this.updateChartQcm(question.choices);
            } else if (question && question.type === QuestionType.QRL) {
                this.updateChartQrl();
            }
            this.cdr.detectChanges();
        }
    }

    private updateChartQcm(choices: Choice[]): void {
        const chartData = this.histogramService.generateChartData(choices, this.roomAnswers[this.questionIndex]);
        this.single = chartData.data;
        this.colorScheme.domain = chartData.colors;
    }

    private updateChartQrl(): void {
        this.single = [
            { name: '0%', value: this.roomAnswers[this.questionIndex][0] },
            { name: '50%', value: this.roomAnswers[this.questionIndex][1] },
            { name: '100%', value: this.roomAnswers[this.questionIndex][2] },
        ];
        this.colorScheme.domain = ['red', 'orange', 'green'];
    }
}
