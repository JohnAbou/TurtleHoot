import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { HistogramService } from '@app/services/histogram.service';
import { AnswerEvent, ConnectionEvent, GameEvent } from '@common/event-name';
import { AnswerState, PlayerState } from '@common/player';
import { QuestionType } from '@common/quiz';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { of } from 'rxjs';
import { Socket } from 'socket.io-client';
import { ResultsComponent } from './results.component';
describe('ResultsComponent', () => {
    let component: ResultsComponent;
    let fixture: ComponentFixture<ResultsComponent>;
    let gameService: jasmine.SpyObj<GameService>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;
    let histogramSerivceSpy: jasmine.SpyObj<HistogramService>;
    const mockRouter = {
        navigate: jasmine.createSpy('navigate'),
    };

    beforeEach(async () => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;
        const gameServiceSpy = jasmine.createSpyObj('GameService', ['getSortedPlayers', 'gameQuiz']);

        histogramSerivceSpy = jasmine.createSpyObj('HistogramService', ['generateChartData']);
        histogramSerivceSpy.generateChartData.and.returnValue({ data: [{ name: 'A', value: 1 }], colors: [] });

        await TestBed.configureTestingModule({
            imports: [RouterTestingModule, NgxChartsModule, BrowserAnimationsModule, NoopAnimationsModule],
            declarations: [ResultsComponent],
            providers: [
                { provide: ActivatedRoute, useValue: { queryParams: of({ gameId: '123' }) } },
                { provide: GameService, useValue: gameServiceSpy },
                { provide: SocketClientService, useValue: socketServiceMock },
                { provide: Router, useValue: mockRouter },
                { provide: HistogramService, useValue: histogramSerivceSpy },
            ],
        }).compileComponents();

        gameService = TestBed.inject(GameService) as jasmine.SpyObj<GameService>;
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ResultsComponent);
        component = fixture.componentInstance;
        gameService.getSortedPlayers.and.returnValue([]);
        gameService.gameQuiz = {
            id: '1',
            title: 'Test Quiz',
            description: 'A test quiz',
            duration: 10,
            lastModification: '2024-03-18',
            questions: [
                {
                    id: 'q1',
                    lastModification: '2024-03-18',
                    type: QuestionType.QCM,
                    text: 'What is 1+1?',
                    points: 1,
                    choices: [
                        { text: '1', isCorrect: false },
                        { text: '2', isCorrect: true },
                        { text: '3', isCorrect: false },
                        { text: '4', isCorrect: false },
                    ],
                },
            ],
        };
        gameService.players = [
            {
                username: 'Player 1',
                id: '1',
                role: PlayerState.Player,
                points: 0,
                nBonus: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                username: 'Player 2',
                id: '2',
                role: PlayerState.Player,
                points: 0,
                nBonus: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
        ];
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should initialize component properly in ngOnInit()', () => {
        component.ngOnInit();
        expect(component['gameId']).toBeDefined();
        expect(component['questionIndex']).toBe(0);
    });

    it('should navigate to home when leaving game', () => {
        spyOn(component['socketService'], 'send');
        component['leaveGame']();

        expect(mockRouter.navigate).toHaveBeenCalledWith(['/home']);
        expect(component['socketService'].send).toHaveBeenCalledWith(ConnectionEvent.LEAVE_ROOM);
    });

    it('should navigate to next question', () => {
        const updateChartDataSpy = jasmine.createSpy('updateChartData');

        Object.defineProperty(component, 'updateChartData', { value: updateChartDataSpy });
        component['questions'] = [
            { id: 'q1', lastModification: '2024-03-18', type: QuestionType.QCM, text: '', points: 0 },
            { id: 'q2', lastModification: '2024-03-18', type: QuestionType.QCM, text: '', points: 0 },
        ];
        component['nextQuestion']();
        expect(component['questionIndex']).toBe(1);
        expect(component['updateChartData']).toHaveBeenCalled();
    });

    it('should navigate to previous question', () => {
        const updateChartDataSpy = jasmine.createSpy('updateChartData');

        Object.defineProperty(component, 'updateChartData', { value: updateChartDataSpy });
        component['questions'] = [{ id: 'q1', lastModification: '2024-03-18', type: QuestionType.QCM, text: '', points: 0 }];
        component['questionIndex'] = 1;
        component['previousQuestion']();
        expect(component['questionIndex']).toBe(0);
        expect(updateChartDataSpy).toHaveBeenCalled();
    });

    it('should update chart data in updateChartData()', fakeAsync(() => {
        component['questions'] = [
            {
                id: 'q1',
                lastModification: '2024-03-18',
                type: QuestionType.QCM,
                text: 'Question',
                points: 1,
                choices: [{ text: 'A', isCorrect: true }],
            },
        ];
        component['questionIndex'] = 0;

        component[AnswerEvent.ROOM_ANSWERS] = [[1]];
        component['updateChartData']();
        // Le delay pour mettre à jour le graphique
        // eslint-disable-next-line @typescript-eslint/no-magic-numbers
        tick(10);
        expect(component['single']).toEqual([{ name: 'A', value: 1 }]);
    }));

    it('should set yAxisTicks correctly in setYAxisTicks()', () => {
        component['players'] = [
            {
                username: 'Player 1',
                id: '1',
                role: PlayerState.Player,
                points: 0,
                nBonus: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                username: 'Player 2',
                id: '2',
                role: PlayerState.Player,
                points: 0,
                nBonus: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
        ];
        component['yAxisTicks'] = [];
        component['setYAxisTicks']();
        expect(component['yAxisTicks']).toEqual([0, 1, 2]);
    });

    it('should format yAxisTick correctly in yAxisTickFormatting()', () => {
        const value = 5;
        const formattedValue = component['yAxisTickFormatting'](value);
        expect(formattedValue).toBe('5');
    });

    it('should navigate to home when access to game is denied', () => {
        component.ngOnInit();
        spyOn(component['socketService'], 'send');
        socketHelper.peerSideEmit(GameEvent.ACCESS_TO_GAME, false);

        expect(component['socketService'].send).toHaveBeenCalledWith(ConnectionEvent.LEAVE_ROOM);
        expect(mockRouter.navigate).toHaveBeenCalledWith(['/home']);
    });

    it('should let into page if access is granted', () => {
        component.ngOnInit();
        const letIntoResultsSpy = jasmine.createSpy('updateChartData');

        Object.defineProperty(component, 'letIntoResults', { value: letIntoResultsSpy });

        socketHelper.peerSideEmit(GameEvent.ACCESS_TO_GAME, true);

        expect(letIntoResultsSpy).toHaveBeenCalled();
    });

    it('should initialize correctly if access is granted', () => {
        component['letIntoResults']();
        socketHelper.peerSideEmit(AnswerEvent.ROOM_ANSWERS, [
            [1, 2],
            // Nous devons simulez des réponses pour les tests
            // eslint-disable-next-line @typescript-eslint/no-magic-numbers
            [3, 4],
        ]);

        expect(component[AnswerEvent.ROOM_ANSWERS]).toEqual([
            [1, 2],
            // Nous devons simulez des réponses pour les tests
            // eslint-disable-next-line @typescript-eslint/no-magic-numbers
            [3, 4],
        ]);
        expect(component['questionIndex']).toBe(0);
    });
    it('should update the chart for a qrl question', fakeAsync(() => {
        component['questions'] = [
            {
                id: 'q1',
                lastModification: '2024-03-18',
                type: QuestionType.QRL,
                text: 'Question',
                points: 1,
            },
        ];
        component['questionIndex'] = 0;

        component['roomAnswers'] = [[1]];
        component['updateChartData']();
        const colors = ['red', 'orange', 'green'];
        // Le delay pour mettre à jour le graphique
        // eslint-disable-next-line @typescript-eslint/no-magic-numbers
        tick(10);
        expect(component['colorScheme'].domain).toEqual(colors);
    }));
});
