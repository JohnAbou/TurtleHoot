import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { AdminState } from '@app/interfaces/admin-page.state';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { MOCK_QUIZ } from '@common/constants';
import { Quiz } from '@common/quiz';
import { of } from 'rxjs';
import { GameListComponent } from './game-list.component';

describe('GameListComponent', () => {
    let component: GameListComponent;
    let mockQuizService: jasmine.SpyObj<QuizService>;
    let popUpService: jasmine.SpyObj<PopUpService>;

    beforeEach(async () => {
        mockQuizService = jasmine.createSpyObj('QuizService', [
            'addQuiz',
            'deleteQuiz',
            'getQuiz',
            'getAllQuiz',
            'updateQuiz',
            'uploadQuiz',
            'getQuizVisibility',
            'changeVisibility',
            'generateId',
        ]);
        popUpService = jasmine.createSpyObj('PopUpService', ['openCareful']);
        await TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            declarations: [GameListComponent],
            providers: [
                { provide: MatDialog, useValue: {} },
                { provide: QuizService, useValue: mockQuizService },
                { provide: PopUpService, useValue: popUpService },
            ],
        }).compileComponents();
    });

    beforeEach(() => {
        const fixture = TestBed.createComponent(GameListComponent);
        component = fixture.componentInstance;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('should emit AdminState.CreationQuiz when modifyQuiz is called', () => {
        const mockPageState = spyOn(component.pageState, 'emit');

        component['modifyQuiz']();

        expect(mockPageState).toHaveBeenCalledWith(AdminState.CreationQuiz);
    });

    it('should load quizzes and visibilities', () => {
        const mockQuizzes: Quiz[] = [
            { id: '1', title: 'Quiz 1', description: '', duration: 0, lastModification: '', questions: [] },
            { id: '2', title: 'Quiz 2', description: '', duration: 0, lastModification: '', questions: [] },
        ];
        const quizVisibility1 = true;
        const quizVisibility2 = true;

        mockQuizService.getAllQuiz.and.returnValue(of(mockQuizzes));
        mockQuizService.getQuizVisibility.and.returnValues(of(quizVisibility1), of(quizVisibility2));

        component['loadQuizzesAndVisibilities']();

        expect(mockQuizService.getAllQuiz).toHaveBeenCalled();
        expect(mockQuizService.getQuizVisibility).toHaveBeenCalledTimes(2);
        expect(component['quizzes']).toEqual(mockQuizzes);
        expect(component['quizIds']).toEqual(['1', '2']);
        expect(component['quizVisibilities'].size).toBe(2);
    });

    it('should delete a quiz', () => {
        const quizIdToDelete = '1';
        const mockQuizzes: Quiz[] = [
            { id: '1', title: 'Quiz 1', description: '', duration: 0, lastModification: '', questions: [] },
            { id: '2', title: 'Quiz 2', description: '', duration: 0, lastModification: '', questions: [] },
        ];
        (popUpService.openCareful as jasmine.Spy).and.callFake((text: string, action?: () => void) => {
            if (action) {
                action();
            }
        });
        component['quizzes'] = mockQuizzes;
        component['quizIds'] = ['1', '2'];
        component['quizVisibilities'].set('1', true);

        mockQuizService.deleteQuiz.and.returnValue(of({}));

        component['deleteQuiz'](quizIdToDelete);

        expect(mockQuizService.deleteQuiz).toHaveBeenCalledWith(quizIdToDelete);
        expect(component['quizzes'].length).toBe(1);
        expect(component['quizIds'].length).toBe(1);
        expect(component['quizVisibilities'].has('1')).toBeFalsy();
    });

    it('should export quiz data without _id property', () => {
        const exportedQuiz = component['exportQuiz'](MOCK_QUIZ);
        expect(exportedQuiz).toEqual(MOCK_QUIZ);
    });

    it('should return true when quiz is visible', () => {
        component['quizVisibilities'].set('1', true);
        expect(component['isVisible']('1')).toBe(true);
    });

    it('should return false when quiz is not visible', () => {
        component['quizVisibilities'].set('2', false);
        expect(component['isVisible']('2')).toBe(false);
    });

    it('should toggle visibility of a quiz', () => {
        const quizId = '1';
        component['quizVisibilities'].set(quizId, true);

        mockQuizService.changeVisibility.and.returnValue(of({ quizId: '1', visible: true }));

        component['changeVisibility'](quizId);

        expect(mockQuizService.changeVisibility).toHaveBeenCalledWith(quizId, false);
        expect(component['quizVisibilities'].get(quizId)).toBe(false);
    });

    it('should call loadQuizzesAndVisibilities on initialization', () => {
        const loadQuizzesAndVisibilitiesSpy = jasmine.createSpy('loadQuizzesAndVisibilities');

        Object.defineProperty(component, 'loadQuizzesAndVisibilities', { value: loadQuizzesAndVisibilitiesSpy });
        component.ngOnInit();
        expect(loadQuizzesAndVisibilitiesSpy).toHaveBeenCalled();
    });

    it('should set visibility to true', () => {
        const mockQuizId = '1';

        mockQuizService.getQuizVisibility.and.returnValue(of(true));

        component['getQuizVisibility'](mockQuizId);

        expect(mockQuizService.getQuizVisibility).toHaveBeenCalledWith(mockQuizId);

        expect(component['quizVisibilities'].get(mockQuizId)).toBe(true);
    });

    it('should set visibility to false when quiz visibility is false', () => {
        const mockQuizId = '1';

        mockQuizService.getQuizVisibility.and.returnValue(of(false));

        component['getQuizVisibility'](mockQuizId);

        expect(mockQuizService.getQuizVisibility).toHaveBeenCalledWith(mockQuizId);

        expect(component['quizVisibilities'].get(mockQuizId)).toBe(false);
    });

    it('should toggle visibility to true when current visibility is false', () => {
        const mockQuizId = '1';
        component['quizVisibilities'].set(mockQuizId, false);

        mockQuizService.changeVisibility.and.returnValue(of({ quizId: mockQuizId, visible: true }));

        component['changeVisibility'](mockQuizId);

        expect(mockQuizService.changeVisibility).toHaveBeenCalledWith(mockQuizId, true);
        expect(component['quizVisibilities'].get(mockQuizId)).toBe(true);
    });

    it('should toggle visibility to false when current visibility is true', () => {
        const mockQuizId = '1';
        component['quizVisibilities'].set(mockQuizId, true);

        mockQuizService.changeVisibility.and.returnValue(of({ quizId: mockQuizId, visible: false }));

        component['changeVisibility'](mockQuizId);

        expect(mockQuizService.changeVisibility).toHaveBeenCalledWith(mockQuizId, false);
        expect(component['quizVisibilities'].get(mockQuizId)).toBe(false);
    });
});
