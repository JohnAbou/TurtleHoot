import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AdminState } from '@app/interfaces/admin-page.state';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { Quiz } from '@common/quiz';

@Component({
    selector: 'app-game-list',
    templateUrl: './game-list.component.html',
    styleUrls: ['./game-list.component.scss'],
})
export class GameListComponent implements OnInit {
    @Output()
    pageState: EventEmitter<AdminState> = new EventEmitter<AdminState>();
    protected quizzes: Quiz[] = [];
    private quizVisibilities: Map<string, boolean> = new Map<string, boolean>();
    private quizIds: string[] = [];

    constructor(
        @Inject(MatDialog) public dialog: MatDialog,
        private quizService: QuizService,
        private popUpService: PopUpService,
    ) {}

    ngOnInit(): void {
        this.loadQuizzesAndVisibilities();
    }

    protected modifyQuiz() {
        this.pageState.emit(AdminState.CreationQuiz);
    }

    protected deleteQuiz(quizId: string) {
        this.popUpService.openCareful('Voulez vous vraiment supprimer ce quiz?', () => {
            this.quizService.deleteQuiz(quizId).subscribe({
                next: () => {
                    this.quizzes = this.quizzes.filter((quiz) => quiz.id !== quizId);
                    this.quizIds = this.quizIds.filter((id) => id !== quizId);
                    this.quizVisibilities.delete(quizId);
                },
            });
        });
    }

    protected exportQuiz(quiz: Quiz) {
        const quizToExport = { ...quiz };
        if ('_id' in quizToExport) {
            // Nous avons besoin du _ pour le id de mongoDB afin d'exporter le quiz sans _id
            // eslint-disable-next-line no-underscore-dangle
            delete quizToExport._id;
        }
        const jsonContent = JSON.stringify(quizToExport);
        const blob = new Blob([jsonContent], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${quiz.title}.json`;
        a.click();
        URL.revokeObjectURL(url);

        return quizToExport;
    }

    protected isVisible(quizId: string): boolean {
        return this.quizVisibilities.get(quizId) || false;
    }

    protected changeVisibility(quizId: string) {
        const currentVisibility = this.quizVisibilities.get(quizId) || false;
        const newVisibility = !currentVisibility;
        this.quizService.changeVisibility(quizId, newVisibility).subscribe({
            next: () => {
                this.quizVisibilities.set(quizId, newVisibility);
            },
        });
    }

    private loadQuizzesAndVisibilities() {
        this.quizService.getAllQuiz().subscribe({
            next: (data) => {
                this.quizzes = data.filter((quiz) => !quiz.id.includes('-random'));
                this.quizIds = this.getAllIds(this.quizzes);
                this.loadVisibilities();
            },
        });
    }

    private getAllIds(quizzes: Quiz[]): string[] {
        return quizzes.map((quiz) => quiz.id);
    }

    private loadVisibilities() {
        this.quizIds.forEach((quizId) => {
            this.getQuizVisibility(quizId);
        });
    }

    private getQuizVisibility(quizId: string) {
        this.quizService.getQuizVisibility(quizId).subscribe({
            next: (visibility) => {
                if (visibility) {
                    this.quizVisibilities.set(quizId, true);
                } else {
                    this.quizVisibilities.set(quizId, false);
                }
            },
        });
    }
}
