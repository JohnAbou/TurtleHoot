import { HttpErrorResponse, HttpResponse, HttpStatusCode } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GlowButtonComponent } from '@app/components/glow-button/glow-button.component';
import { QuizService } from '@app/services/http-services/quiz.service';
import { of, throwError } from 'rxjs';
import { ImportQuizComponent } from './import-quiz.component';

describe('ImportQuizComponent', () => {
    let component: ImportQuizComponent;
    let fixture: ComponentFixture<ImportQuizComponent>;
    let quizServiceSpy: jasmine.SpyObj<QuizService>;

    beforeEach(async () => {
        const mockQuizService = jasmine.createSpyObj('QuizService', ['uploadQuizFromJson']);

        await TestBed.configureTestingModule({
            declarations: [ImportQuizComponent, GlowButtonComponent],
            imports: [MatSnackBarModule, BrowserAnimationsModule],
            providers: [{ provide: QuizService, useValue: mockQuizService }],
        }).compileComponents();

        quizServiceSpy = TestBed.inject(QuizService) as jasmine.SpyObj<QuizService>;
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ImportQuizComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should handle file selection', () => {
        const file = new File(['file content'], 'quiz.json', { type: 'application/json' });
        const event = { target: { files: [file] } } as unknown as Event;
        spyOn(component['snackBar'], 'open').and.callThrough();
        component['onFileChange'](event);

        expect(component.file).toEqual(file);
        expect(component['isFileValid']).toBeTrue();
    });

    it('should reject invalid file types', () => {
        const file = new File(['file content'], 'quiz.txt', { type: 'text/plain' });
        const event = { target: { files: [file] } } as unknown as Event;
        spyOn(component['snackBar'], 'open').and.callThrough();
        component['onFileChange'](event);

        expect(component.file).toBeUndefined();
        expect(component['isFileValid']).toBeFalse();
    });

    it('should upload file content', async () => {
        const fileContent = '{"question": "What is your name?"}';
        const file = new File([fileContent], 'quiz.json', { type: 'application/json' });
        component.file = file;

        const response = new HttpResponse<string>({
            status: HttpStatusCode.Created,
            body: 'Success message',
        });

        quizServiceSpy.uploadQuizFromJson.and.returnValue(of(response));
        spyOn(component['snackBar'], 'open').and.callThrough();

        await component['upload']();

        expect(quizServiceSpy.uploadQuizFromJson).toHaveBeenCalled();
        expect(component['snackBar'].open).toHaveBeenCalledWith(
            `Le serveur a reçu la requête a retourné un code ${HttpStatusCode.Created} : Success message`,
            'OK',
        );
    });

    it('should handle upload importation errors', async () => {
        const fileContent = '{"question": "What is your name?"}';
        const file = new File([fileContent], 'quiz.json', { type: 'application/json' });
        component.file = file;
        spyOn(component['snackBar'], 'open').and.callThrough();

        await component['upload']();
        expect(component['snackBar'].open).toHaveBeenCalledWith(
            "L'importation a échoué pour une raison inconnue, vérifier l'exactitude du fichier importé!",
            'OK',
        );
    });

    it('should handle parsing errors', async () => {
        const fileContent = 'invalid JSON content';
        const file = new File([fileContent], 'quiz.json', { type: 'application/json' });
        component.file = file;
        spyOn(component['snackBar'], 'open').and.callThrough();

        await component['upload']();
        expect(component['snackBar'].open).toHaveBeenCalledWith(
            "L'importation a échoué pour une raison inconnue, vérifier l'exactitude du fichier importé!",
            'OK',
        );
    });

    it('should handle missing file', async () => {
        spyOn(component['snackBar'], 'open').and.callThrough();

        await component['upload']();
        expect(component['snackBar'].open).toHaveBeenCalledWith("Sélectionner un fichier d'abord!", 'OK');
    });

    it('should handle HTTP errors during upload', async () => {
        const fileContent = '{"question": "What is json?"}';
        const file = new File([fileContent], 'quiz.json', { type: 'application/json' });
        component.file = file;

        const errorResponse = new HttpErrorResponse({
            error: 'Internal Server Error',
            status: HttpStatusCode.InternalServerError,
            statusText: 'Internal Server Error',
        });

        quizServiceSpy.uploadQuizFromJson.and.returnValue(throwError(() => errorResponse));
        spyOn(component['snackBar'], 'open').and.callThrough();

        await component['upload']();

        expect(quizServiceSpy.uploadQuizFromJson).toHaveBeenCalled();
        expect(component['snackBar'].open).toHaveBeenCalledWith(
            'Il y a eu une erreur lors du téléversement. Veuillez réessayer: Internal Server Error',
            'OK',
        );
    });
});
