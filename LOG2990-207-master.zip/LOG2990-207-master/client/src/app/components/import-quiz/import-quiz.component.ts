import { HttpErrorResponse, HttpStatusCode } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { QuizService } from '@app/services/http-services/quiz.service';
import { Quiz } from '@common/quiz';

@Component({
    selector: 'app-import-quiz',
    templateUrl: './import-quiz.component.html',
    styleUrls: ['./import-quiz.component.scss'],
})
export class ImportQuizComponent {
    file: File;
    protected isFileValid: boolean = true;

    constructor(
        private quizService: QuizService,
        private snackBar: MatSnackBar,
    ) {}

    protected onFileChange(event: Event): void {
        const inputElement = event.target as HTMLInputElement;

        if (inputElement.files && inputElement.files.length > 0) {
            const selectedFile: File = inputElement.files[0];

            this.isFileValid = selectedFile.type === 'application/json';
            if (this.isFileValid) {
                this.file = selectedFile;
            } else {
                inputElement.value = '';
            }
        }
    }

    protected async upload(): Promise<void> {
        if (this.file) {
            const fileContent: string = await this.file.text();
            try {
                const fileContentJson: Quiz = JSON.parse(fileContent);
                this.quizService.uploadQuizFromJson(fileContentJson, true).subscribe({
                    next: (response) => {
                        if (response.status === HttpStatusCode.Created) {
                            this.snackBar.open(`Le serveur a reçu la requête a retourné un code ${response.status} : ${response.body}`, 'OK');
                        }
                    },
                    error: (err: HttpErrorResponse) => {
                        this.snackBar.open('Il y a eu une erreur lors du téléversement. Veuillez réessayer: ' + err.error, 'OK');
                    },
                });
            } catch (err) {
                this.snackBar.open("L'importation a échoué pour une raison inconnue, vérifier l'exactitude du fichier importé!", 'OK');
            }
        } else {
            this.snackBar.open("Sélectionner un fichier d'abord!", 'OK');
        }
    }
}
