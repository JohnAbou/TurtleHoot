import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { GlowButtonComponent } from '@app/components/glow-button/glow-button.component';
import { AdminState } from '@app/interfaces/admin-page.state';
import { HeaderAdminComponent } from './header-admin.component';
describe('HeaderAdminComponent', () => {
    let component: HeaderAdminComponent;
    let fixture: ComponentFixture<HeaderAdminComponent>;
    let mockMatDialog: Partial<MatDialog>;

    beforeEach(waitForAsync(() => {
        mockMatDialog = {
            open: jasmine.createSpy('open'),
        };

        TestBed.configureTestingModule({
            declarations: [HeaderAdminComponent, GlowButtonComponent],
            imports: [HttpClientTestingModule],
            providers: [{ provide: MatDialog, useValue: mockMatDialog }],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HeaderAdminComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should open the import dialog when importQuiz is called', () => {
        component['importQuiz']();
        expect(mockMatDialog.open).toHaveBeenCalled();
    });

    it('should emit the new page state when changePage is called', () => {
        const newPageState: AdminState = AdminState.Connection;
        spyOn(component.changePageEmitter, 'emit');

        component['changePage'](newPageState);

        expect(component.changePageEmitter.emit).toHaveBeenCalledWith(newPageState);
    });

    it('should navigate to home when header icon is clicked', () => {
        spyOn(component['router'], 'navigate');

        component['navigateToHome']();

        expect(component['router'].navigate).toHaveBeenCalledWith(['/home']);
    });
});
