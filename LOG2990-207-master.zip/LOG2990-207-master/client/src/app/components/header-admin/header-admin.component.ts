import { Component, EventEmitter, Output, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AdminState } from '@app/interfaces/admin-page.state';

@Component({
    selector: 'app-header-admin',
    templateUrl: './header-admin.component.html',
    styleUrls: ['./header-admin.component.scss'],
})
export class HeaderAdminComponent {
    @Output()
    changePageEmitter: EventEmitter<AdminState> = new EventEmitter<AdminState>();
    @ViewChild('importDialogContent')
    private readonly importDialogContentRef: TemplateRef<HTMLElement>;
    readonly pageState = AdminState;
    constructor(
        private readonly matDialog: MatDialog,
        private readonly router: Router,
    ) {}

    protected importQuiz(): void {
        this.matDialog.open(this.importDialogContentRef);
    }
    protected changePage(newPageState: AdminState): void {
        this.router.navigate([], {
            queryParams: {},
        });
        this.changePageEmitter.emit(newPageState);
    }
    protected navigateToHome() {
        this.router.navigate(['/home']);
    }
}
