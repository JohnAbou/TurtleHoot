// Cette partie du code est grande car elle regroupe tout nos fonctionnalités et services afin de faire l'aire de jeu
/* eslint-disable max-lines */
import { AfterViewInit, Component, HostListener, Input, OnDestroy, OnInit, QueryList, ViewChildren } from '@angular/core';
import { MatButtonToggle } from '@angular/material/button-toggle';
import { Router } from '@angular/router';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { KeyboardHandlerService } from '@app/services/envent-handler-services/keyboard-handler.service';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { QcmHandlerService } from '@app/services/envent-handler-services/qcm-handler.service';
import { QrlHandlerService } from '@app/services/envent-handler-services/qrl-handler.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { HistoryService } from '@app/services/http-services/history.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { InteractionTimerService } from '@app/services/interaction-timer.service';
import { TimeService } from '@app/services/time.service';
import { MAX_TEXT_LENGTH_PERCENTAGE, QRL_DURATION, QUESTION_DELAY } from '@common/constants';
import { AnswerEvent, ConnectionEvent, GameEvent, PanicModeEvent, TimerEvent } from '@common/event-name';
import { Question, QuestionType, Quiz } from '@common/quiz';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-play-area',
    templateUrl: './play-area.component.html',
    styleUrls: ['./play-area.component.scss'],
})
export class PlayAreaComponent implements OnInit, OnDestroy, AfterViewInit {
    @ViewChildren('toggleButtons') toggleButtons!: QueryList<MatButtonToggle>;
    @Input() quizId: string;
    @Input() gameId: string;
    @Input() testing: boolean;
    protected questionType = QuestionType;
    protected playerPoints = 0;
    protected isTransitioning = false;
    protected isEvaluating = false;
    protected currentQuestionIndex = 0;
    protected currentQuestion: Question;
    protected qrlAnswer: string = '';
    protected buttonStyles: { [key: string]: boolean } = {};
    protected buttonSelected: { [key: string]: boolean } = {};
    protected isPlaying = true;
    private panicSound = new Audio('./assets/purge_sound.mp3');
    private currentQuiz: Quiz;
    private lastQuestion = false;
    private hasInteracted = false;
    private quizDuration: number;
    private subscription: Subscription;

    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        private readonly timeService: TimeService,
        private readonly keyboardHandlerService: KeyboardHandlerService,
        private interactionTimerService: InteractionTimerService,
        private readonly qcmHandlerService: QcmHandlerService,
        private readonly qrlHandlerService: QrlHandlerService,
        private readonly gameService: GameService,
        private readonly router: Router,
        private readonly socketClientService: SocketClientService,
        private readonly quizService: QuizService,
        private historyService: HistoryService,
        private popUpService: PopUpService,
    ) {
        this.subscription = this.keyboardHandlerService.enterKeyEvent.subscribe(() => {
            this.submitButtonPressed();
        });
        this.subscription.add(
            this.keyboardHandlerService.toggleButtonEvent.subscribe((index: number) => {
                this.qcmHandlerService.toggleButton(index, this.currentQuestionIndex);
            }),
        );
        this.subscription.add(
            this.timeService.timerExpiredEvent.subscribe(() => {
                this.handleTimerExpiration();
            }),
        );
        this.subscription.add(
            this.qcmHandlerService.buttonsChanged.subscribe((buttons: QueryList<MatButtonToggle>) => {
                this.toggleButtons = buttons;
            }),
        );
    }

    get time(): number {
        return this.timeService.time;
    }

    @HostListener('keydown', ['$event'])
    buttonDetect(event: KeyboardEvent) {
        if (this.isPlaying) {
            this.keyboardHandlerService.onKeyboardEvent(event);
        }
    }

    ngOnInit(): void {
        if (this.testing) {
            this.handleTestingInit();
        } else {
            this.socketClientService.send(GameEvent.VERIFY_ACCESS_TO_GAME, this.gameId);
        }
        this.configureAccessToGame();
    }

    ngAfterViewInit(): void {
        this.subscription.add(
            this.toggleButtons.changes.subscribe((buttons: QueryList<MatButtonToggle>) => {
                this.qcmHandlerService.updateToggleButtons(buttons);
            }),
        );
    }

    letIntoPage() {
        this.currentQuestionIndex = 0;
        this.toggleButtons = new QueryList<MatButtonToggle>();
        this.qcmHandlerService.updateToggleButtons(this.toggleButtons);
        this.gameService.configureBaseSocketFeatures();
        this.configureBaseSocketFeatures();
        this.loadQuiz();
    }

    configureBaseSocketFeatures() {
        this.configureAllPlayersAnswered();
        this.configureQuestionEnded();
        this.configureNewPoints();
        this.configurePanicCountdownUpdated();
        this.configureTimerTick();
        this.configureEvaluationInProgress();
        this.configureEvaluationFinished();
    }

    ngOnDestroy(): void {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
        this.unsubscribeFromSocketEvents();
        this.stopPanicSound();
    }

    protected getFontSize(textLength: number): string {
        const minFontSize = 5;
        const maxFontSize = 45;

        const fontSize = maxFontSize - (textLength * (maxFontSize - minFontSize)) / MAX_TEXT_LENGTH_PERCENTAGE;

        return `${fontSize}px`;
    }

    protected submitButtonPressed(): void {
        this.validateAnswer();
    }

    protected abandonButtonPressed(): void {
        this.popUpService.openAbandon(() => {
            this.socketClientService.send(ConnectionEvent.LEAVE_ROOM);
            this.stopPanicSound();
            if (this.testing) {
                this.router.navigate(['/create']);
            } else {
                this.router.navigate(['/home']);
            }
        });
    }

    protected onCountdownFinishedTransition(): void {
        this.configureTimerTick();
        this.onCountdownFinished();
    }

    protected playerInteracted() {
        if (!this.hasInteracted) {
            this.socketClientService.send(AnswerEvent.PLAYER_INTERACTED, this.currentQuestionIndex);
            this.hasInteracted = true;
        }
        this.interactionTimerService.startInteractionTimer(() => {
            this.socketClientService.send(AnswerEvent.PLAYER_AFK, this.currentQuestionIndex);
            this.hasInteracted = false;
        });
    }

    protected onTogglePressed(index: number, questionIndex: number): void {
        this.qcmHandlerService.onTogglePressed(index, questionIndex);
    }

    private configureAllPlayersAnswered() {
        this.socketClientService.on(AnswerEvent.ALL_PLAYERS_ANSWERED, () => {
            this.socketClientService.send(TimerEvent.STOP_TIMER, this.gameId);
            this.isPlaying = false;
            this.stopPanicSound();
            this.handleChoicesView();
            if (this.testing) {
                this.socketClientService.send(AnswerEvent.END_QUESTION);
            }
            if (this.quizId.includes('-random')) {
                setTimeout(() => {
                    this.socketClientService.send(AnswerEvent.END_QUESTION);
                }, QUESTION_DELAY);
            }
        });
    }
    private configureQuestionEnded() {
        this.socketClientService.on(AnswerEvent.QUESTION_ENDED, () => {
            if (this.isPlaying) {
                this.validateAnswer();
            }
            this.handleQuestionEnded();
            this.stopPanicSound();
        });
    }
    private configureNewPoints() {
        this.socketClientService.on<number>(AnswerEvent.NEW_POINTS, (newPoints: number) => {
            this.playerPoints = newPoints;
        });
    }
    private configurePanicCountdownUpdated() {
        this.socketClientService.on(PanicModeEvent.PANIC_COUNTDOWN_UPDATED, () => {
            this.panicSound.play();
            this.timeService.decrement();
        });
    }
    private configureTimerTick() {
        this.socketClientService.on(TimerEvent.TIMER_TICK, () => {
            this.timeService.decrement();
        });
    }
    private configureEvaluationInProgress() {
        this.socketClientService.on(AnswerEvent.EVALUATION_IN_PROGRESS, () => {
            this.interactionTimerService.resetInteractionTimer();
            this.hasInteracted = false;
            this.isEvaluating = true;
        });
    }
    private configureEvaluationFinished() {
        this.socketClientService.on(AnswerEvent.EVALUATION_FINISHED, () => {
            this.isEvaluating = false;
            if (this.testing) {
                this.socketClientService.send(TimerEvent.STOP_TIMER, this.gameId);
                this.socketClientService.send(AnswerEvent.END_QUESTION);
            }
        });
    }

    private handleTestingInit() {
        this.socketClientService.send(ConnectionEvent.CREATE_TEST_GAME);
        this.socketClientService.on(ConnectionEvent.TEST_GAME_CREATED, () => {
            this.qcmHandlerService.testing = true;
            this.gameId = this.socketClientService.socket.id;
            this.socketClientService.send(GameEvent.VERIFY_ACCESS_TO_GAME, this.gameId);
        });
    }

    private configureAccessToGame() {
        this.socketClientService.on<boolean>(GameEvent.ACCESS_TO_GAME, (access: boolean) => {
            if (!access) {
                this.socketClientService.send(ConnectionEvent.LEAVE_ROOM);
                this.router.navigate(['/home']);
            } else {
                this.letIntoPage();
                const adjustNumberOfPlayers = this.currentQuiz.id.includes('-random') ? 1 : 0;
                this.historyService.addStartTimestamp();
                this.historyService.addPlayerCount(this.gameService.players.length - 1 + adjustNumberOfPlayers);
            }
        });
    }

    private unsubscribeFromSocketEvents() {
        this.socketClientService.off(AnswerEvent.ALL_PLAYERS_ANSWERED);
        this.socketClientService.off(AnswerEvent.QUESTION_ENDED);
        this.socketClientService.off(ConnectionEvent.TEST_GAME_CREATED);
        this.socketClientService.off(GameEvent.ACCESS_TO_GAME);
        this.socketClientService.off(TimerEvent.TIMER_TICK);
        this.socketClientService.off(AnswerEvent.NEW_POINTS);
        this.socketClientService.off(PanicModeEvent.PANIC_COUNTDOWN_UPDATED);
        this.socketClientService.off(AnswerEvent.EVALUATION_IN_PROGRESS);
        this.socketClientService.off(AnswerEvent.EVALUATION_FINISHED);
        this.gameService.unsubscribeFromSocketFeatures();
    }

    private validateAnswer(): void {
        if (this.currentQuestion.type === QuestionType.QCM) {
            this.qcmHandlerService.validateQcmAnswer(this.time, this.currentQuestion, this.buttonSelected);
        } else if (this.currentQuestion.type === QuestionType.QRL) {
            const answer = this.qrlAnswer;
            if (this.testing) {
                this.socketClientService.send(AnswerEvent.FINISHED_CORRECTING, {
                    grades: [{ points: 100, playerId: this.socketClientService.socket.id }],
                    questionIndex: this.currentQuestionIndex,
                    questionValue: this.currentQuestion.points,
                });
            } else {
                this.qrlHandlerService.validateQrlAnswer(this.time, this.currentQuestion, answer);
            }
        }
        this.isPlaying = false;
        this.buttonStyles = {};
    }

    private loadQuiz() {
        if (this.testing) {
            this.quizService.getQuiz(this.quizId).subscribe({
                next: (quiz) => {
                    this.setQuiz(quiz);
                    this.socketClientService.send(TimerEvent.START_TIMER, this.gameId);
                },
            });
        } else {
            this.setQuiz(this.gameService.gameQuiz);
        }
    }

    private setQuiz(quiz: Quiz) {
        this.currentQuiz = quiz;
        this.currentQuestion = quiz.questions[this.currentQuestionIndex];
        if (this.currentQuiz.questions.length <= 1) {
            this.lastQuestion = true;
        }
        this.quizDuration = quiz.duration;
        this.setTime();
    }

    private handleTimerExpiration() {
        if (this.isPlaying) {
            this.validateAnswer();
            this.stopPanicSound();
        }
    }

    private handleQuestionEnded(): void {
        if (this.testing) {
            this.handleQuestionEndedTesting();
        } else {
            if (this.lastQuestion) {
                this.handleLastQuestionEnded();
            } else {
                this.socketClientService.off(TimerEvent.TIMER_TICK);
                if (this.quizId.includes('-random') && this.gameService.filterPlayers(this.gameService.getPlayers()).length > 1) {
                    this.configureTimerTick();
                }
                this.isTransitioning = true;
            }
        }
    }

    private handleQuestionEndedTesting() {
        setTimeout(() => {
            if (this.lastQuestion) {
                this.socketClientService.send(ConnectionEvent.LEAVE_ROOM);
                this.router.navigate(['/create']);
            } else {
                this.onCountdownFinished();
                this.socketClientService.send(TimerEvent.START_TIMER, this.gameId);
            }
        }, QUESTION_DELAY);
    }

    private handleLastQuestionEnded() {
        this.stopPanicSound();
        this.router.navigate(['/result'], { queryParams: { gameId: this.gameId } });
        if (this.quizId.includes('-random')) {
            this.historyService.addEndTimestamp();
            this.historyService.addQuizTitle(this.currentQuiz);
            this.historyService.addBestScore(this.gameService.getSortedPlayers()[0].points);
            this.historyService.addToHistory();
            this.historyService.removeDuplicates();
        }
    }

    private handleChoicesView(): void {
        if (this.currentQuestion.choices) {
            this.currentQuestion.choices.forEach((choice, index) => {
                this.buttonStyles[index] = choice.isCorrect;
            });
        }
    }

    private nextQuestion(): void {
        this.currentQuestionIndex++;
        this.currentQuestion = this.currentQuiz.questions[this.currentQuestionIndex];
    }

    private onCountdownFinished(): void {
        this.qrlAnswer = '';
        this.isTransitioning = false;
        if (this.currentQuestionIndex + 1 === this.currentQuiz.questions.length - 1) {
            this.lastQuestion = true;
        }

        this.nextQuestion();
        this.buttonStyles = {};
        this.buttonSelected = {};
        this.setTime();
        this.socketClientService.send(TimerEvent.START_TIMER, this.gameId);
        this.isPlaying = true;
    }

    private stopPanicSound() {
        this.panicSound.pause();
        this.panicSound.currentTime = 0;
    }

    private setTime() {
        if (this.currentQuestion.type === QuestionType.QCM) {
            this.timeService.setTime(this.quizDuration);
        } else {
            this.timeService.setTime(QRL_DURATION);
        }
    }
}
