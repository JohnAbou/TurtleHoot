// Nous devons depasser 350 lignes afin de tester les différents cas du component
/* eslint-disable max-lines */
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { QueryList } from '@angular/core';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { MatButtonToggle, MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatDialogModule } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { PlayAreaComponent } from '@app/components/play-area/play-area.component';
import { PopUpComponent } from '@app/components/pop-up/pop-up.component';
import { GameService } from '@app/services/envent-handler-services/game.service';
import { KeyboardHandlerService } from '@app/services/envent-handler-services/keyboard-handler.service';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { QcmHandlerService } from '@app/services/envent-handler-services/qcm-handler.service';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { HistoryService } from '@app/services/http-services/history.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { TimeService } from '@app/services/time.service';
import { MOCK_PLAYERS, MOCK_QUIZ, QRL_DURATION, QUESTION_DELAY } from '@common/constants';
import { AnswerEvent, ConnectionEvent, GameEvent, PanicModeEvent, TimerEvent } from '@common/event-name';
import { Question, QuestionType } from '@common/quiz';
import { Subject, of } from 'rxjs';
import { Socket } from 'socket.io-client';

import SpyObj = jasmine.SpyObj;

describe('PlayAreaComponent', () => {
    let component: PlayAreaComponent;
    let fixture: ComponentFixture<PlayAreaComponent>;
    let timeServiceSpy: SpyObj<TimeService>;
    let keyboardHandlerServiceSpy: SpyObj<KeyboardHandlerService>;
    let routerSpy: SpyObj<Router>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;
    let popUpService: SpyObj<PopUpService>;
    let popUpComponentSpy: jasmine.SpyObj<PopUpComponent>;
    let qcmHandlerServiceSpy: SpyObj<QcmHandlerService>;
    let historyServiceSpy: SpyObj<HistoryService>;
    let gameServiceSpy: SpyObj<GameService>;
    let mockQuizService: jasmine.SpyObj<QuizService>;

    beforeEach(async () => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;

        qcmHandlerServiceSpy = jasmine.createSpyObj('QcmHandlerService', ['updateToggleButtons', 'toggleButton', 'validateQcmAnswer']);
        mockQuizService = jasmine.createSpyObj('QuizService', ['getQuiz']);
        qcmHandlerServiceSpy.buttonsChanged = new Subject<QueryList<MatButtonToggle>>();

        popUpService = jasmine.createSpyObj('PopUpService', ['openAbandon']);

        mockQuizService.getQuiz.and.returnValue(of(MOCK_QUIZ));

        routerSpy = jasmine.createSpyObj('Router', ['navigate']);

        const mockTimerExpiredEvent = new Subject<void>();
        timeServiceSpy = jasmine.createSpyObj('TimeService', ['decrement', 'setTime']);
        timeServiceSpy.timerExpiredEvent = mockTimerExpiredEvent;

        const mockToggleButtonEvent = new Subject<number>();
        const mockEnterKeyEvent = new Subject<void>();
        keyboardHandlerServiceSpy = jasmine.createSpyObj('KeyboardHandlerService', ['onKeyboardEvent']);
        keyboardHandlerServiceSpy.enterKeyEvent = mockEnterKeyEvent;
        keyboardHandlerServiceSpy.toggleButtonEvent = mockToggleButtonEvent;

        popUpComponentSpy = jasmine.createSpyObj('PopUpComponent', ['onButtonClick']);

        historyServiceSpy = jasmine.createSpyObj('HistoryService', [
            'addStartTimestamp',
            'addEndTimestamp',
            'addQuizTitle',
            'addBestScore',
            'addToHistory',
            'addPlayerCount',
            'removeDuplicates',
        ]);

        gameServiceSpy = jasmine.createSpyObj('GameService', [
            'filterPlayers',
            'configureBaseSocketFeatures',
            'unsubscribeFromSocketFeatures',
            'getSortedPlayers',
        ]);

        await TestBed.configureTestingModule({
            declarations: [PlayAreaComponent],
            imports: [HttpClientTestingModule, MatDialogModule, MatButtonToggleModule],
            providers: [
                { provide: Router, useValue: routerSpy },
                { provide: TimeService, useValue: timeServiceSpy },
                { provide: KeyboardHandlerService, useValue: keyboardHandlerServiceSpy },
                { provide: SocketClientService, useValue: socketServiceMock },
                { provide: PopUpService, useValue: popUpService },
                { provide: HistoryService, useValue: historyServiceSpy },
                { provide: Router, useValue: routerSpy },
                { provide: PopUpComponent, useValue: popUpComponentSpy },
                { provide: QcmHandlerService, useValue: qcmHandlerServiceSpy },
                { provide: GameService, useValue: gameServiceSpy },
                { provide: QuizService, useValue: mockQuizService },
            ],
        }).compileComponents();
        fixture = TestBed.createComponent(PlayAreaComponent);
        component = fixture.componentInstance;
        component['gameService'].gameQuiz = MOCK_QUIZ;
        component.quizId = '1';
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should load quiz correctly when testing', () => {
        component.testing = true;
        component['loadQuiz']();
        expect(component['currentQuiz']).toEqual(MOCK_QUIZ);
    });

    it('should calculate font size', () => {
        const textLength = 10;
        const expectedFontSize = '41px';

        expect(component['getFontSize'](textLength)).toEqual(expectedFontSize);
    });

    it('should register input and stop timer on enter key', () => {
        const handleTimerExpirationSpy = jasmine.createSpy('handleTimerExpiration');

        Object.defineProperty(component, 'handleTimerExpiration', { value: handleTimerExpirationSpy });
        const submitButtonPressedSpy = jasmine.createSpy('submitButtonPressed');

        Object.defineProperty(component, 'submitButtonPressed', { value: submitButtonPressedSpy });
        component['currentQuestion'] = MOCK_QUIZ.questions[0];
        keyboardHandlerServiceSpy.enterKeyEvent.next();
        expect(submitButtonPressedSpy).toHaveBeenCalled();
        timeServiceSpy.timerExpiredEvent.next();
        expect(handleTimerExpirationSpy).toHaveBeenCalled();
    });

    it('should call onKeyboardEvent on button press', () => {
        const keyboardEvent = new KeyboardEvent('keydown', { key: '1' });
        component.buttonDetect(keyboardEvent);
        expect(keyboardHandlerServiceSpy.onKeyboardEvent).toHaveBeenCalled();
    });

    it('should route to create after last question if testing', fakeAsync(() => {
        component['lastQuestion'] = true;
        component.testing = true;
        component['handleQuestionEnded']();
        tick(QUESTION_DELAY);
        expect(routerSpy.navigate).toHaveBeenCalledWith(['/create']);
    }));

    it('should route to result and save game after last question if random', fakeAsync(() => {
        gameServiceSpy.getSortedPlayers.and.returnValue(MOCK_PLAYERS);
        component.quizId = '1-random';
        component['lastQuestion'] = true;
        component.testing = false;
        component['handleQuestionEnded']();
        tick(QUESTION_DELAY);
        expect(historyServiceSpy.addToHistory).toHaveBeenCalled();
    }));

    it('should route to result after last question', () => {
        component['lastQuestion'] = true;
        component['handleQuestionEnded']();
        expect(routerSpy.navigate).toHaveBeenCalledWith(['/result'], { queryParams: { gameId: component.gameId } });
    });

    it('should set lastQuestion to true if quiz only has one question', () => {
        const mockQuiz = JSON.parse(JSON.stringify(MOCK_QUIZ));
        mockQuiz.questions = [MOCK_QUIZ.questions[0]];
        component['setQuiz'](mockQuiz);
        expect(component['lastQuestion']).toBeTrue();
    });

    it('should handle countdown ended', () => {
        const validateAnswerSpy = jasmine.createSpy(AnswerEvent.VALIDATE_ANSWER);

        Object.defineProperty(component, AnswerEvent.VALIDATE_ANSWER, { value: validateAnswerSpy });
        component['currentQuiz'] = MOCK_QUIZ;
        component['currentQuestion'] = MOCK_QUIZ.questions[0];
        component['isPlaying'] = true;
        component['onCountdownFinishedTransition']();
        socketHelper.peerSideEmit(TimerEvent.TIMER_TICK);
        expect(timeServiceSpy.decrement).toHaveBeenCalled();
        expect(component['currentQuestion']).toEqual(MOCK_QUIZ.questions[1]);
    });

    it('should handle question ended', () => {
        component.letIntoPage();
        const validateAnswerSpy = jasmine.createSpy(AnswerEvent.VALIDATE_ANSWER);

        Object.defineProperty(component, AnswerEvent.VALIDATE_ANSWER, { value: validateAnswerSpy });
        component['isPlaying'] = true;
        socketHelper.peerSideEmit(AnswerEvent.QUESTION_ENDED);
        expect(component['isTransitioning']).toBeTrue();
    });

    it('should handle question ended when testing', fakeAsync(() => {
        const onCountdownFinishedSpy = jasmine.createSpy('onCountdownFinished');

        Object.defineProperty(component, 'onCountdownFinished', { value: onCountdownFinishedSpy });
        component['isPlaying'] = true;
        component['testing'] = true;
        component['handleQuestionEnded']();
        tick(QUESTION_DELAY);
        expect(onCountdownFinishedSpy).toHaveBeenCalled();
    }));
    it('should handle choices view correctly', () => {
        const question: Question = {
            type: QuestionType.QCM,
            text: 'Example question text',
            points: 40,
            choices: [
                { text: 'Choice 1', isCorrect: true },
                { text: 'Choice 2', isCorrect: false },
            ],
            id: '',
            lastModification: '',
        };
        component['currentQuestion'] = question;

        component['handleChoicesView']();

        expect(component['buttonStyles'][0]).toBe(true);
        expect(component['buttonStyles'][1]).toBe(false);
    });

    it('should decrement time on timertick', () => {
        component.letIntoPage();
        socketHelper.peerSideEmit(TimerEvent.TIMER_TICK);
        expect(timeServiceSpy.decrement).toHaveBeenCalled();
    });
    it('should handle testGameCreated correctly', () => {
        component.testing = true;
        component.ngOnInit();
        spyOn(component['socketClientService'], 'send');
        socketHelper.peerSideEmit(ConnectionEvent.TEST_GAME_CREATED);

        expect(component['socketClientService'].send).toHaveBeenCalledWith(
            GameEvent.VERIFY_ACCESS_TO_GAME,
            component['socketClientService'].socket.id,
        );
    });
    it('should handle newPoints correctly', () => {
        const points = 10;
        component.letIntoPage();
        socketHelper.peerSideEmit(AnswerEvent.NEW_POINTS, points);

        expect(component['playerPoints']).toEqual(points);
    });
    it('should handle accessToGame correctly when denied', () => {
        spyOn(component['socketClientService'], 'send');
        socketHelper.peerSideEmit(GameEvent.ACCESS_TO_GAME, false);

        expect(component['socketClientService'].send).toHaveBeenCalledWith(ConnectionEvent.LEAVE_ROOM);
    });
    it('should handle accessToGame correctly when accepted', () => {
        gameServiceSpy.players = MOCK_PLAYERS;
        component['currentQuiz'] = MOCK_QUIZ;
        spyOn(component, 'letIntoPage');
        socketHelper.peerSideEmit(GameEvent.ACCESS_TO_GAME, true);

        expect(component.letIntoPage).toHaveBeenCalled();
    });
    it('should handle allPlayersAnswered correctly when denied', () => {
        const handleChoicesViewSpy = jasmine.createSpy('handleChoicesView');

        Object.defineProperty(component, 'handleChoicesView', { value: handleChoicesViewSpy });
        component.letIntoPage();
        spyOn(component['socketClientService'], 'send');
        component.testing = true;

        socketHelper.peerSideEmit(AnswerEvent.ALL_PLAYERS_ANSWERED);

        expect(component['isPlaying']).toBeFalse();
        expect(component['socketClientService'].send).toHaveBeenCalledWith(AnswerEvent.END_QUESTION);
    });

    it('should handle allPlayersAnswered correctly when denied in random mode with only organizer', fakeAsync(() => {
        component.letIntoPage();
        spyOn(component['socketClientService'], 'send');
        const handleChoicesViewSpy = jasmine.createSpy('handleChoicesView');

        Object.defineProperty(component, 'handleChoicesView', { value: handleChoicesViewSpy });
        component.testing = false;
        component.quizId = '1-random';
        socketHelper.peerSideEmit(AnswerEvent.ALL_PLAYERS_ANSWERED);
        tick(QUESTION_DELAY);
        expect(component['isPlaying']).toBeFalse();
        expect(component['socketClientService'].send).toHaveBeenCalledWith(AnswerEvent.END_QUESTION);
    }));

    it('should create test game if testing', () => {
        component.gameId = '1';
        spyOn(component['socketClientService'], 'send');
        const loadQuizSpy = jasmine.createSpy('loadQuiz');

        Object.defineProperty(component, 'loadQuiz', { value: loadQuizSpy });
        component.testing = true;
        component.ngOnInit();

        expect(component['socketClientService'].send).toHaveBeenCalledWith(ConnectionEvent.CREATE_TEST_GAME);
    });
    it('should handle timer expired event', () => {
        component['isPlaying'] = true;
        const validateAnswerSpy = jasmine.createSpy(AnswerEvent.VALIDATE_ANSWER);

        Object.defineProperty(component, AnswerEvent.VALIDATE_ANSWER, { value: validateAnswerSpy });
        timeServiceSpy.timerExpiredEvent.next();
        expect(component[AnswerEvent.VALIDATE_ANSWER]).toHaveBeenCalled();
    });

    it('should handle toggleButtonEvent correctly', () => {
        keyboardHandlerServiceSpy.toggleButtonEvent.next(1);
        expect(qcmHandlerServiceSpy.toggleButton).toHaveBeenCalled();
    });

    it('should handle buttonsChanged correctly', () => {
        const mockMatButtonToggle1 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const mockMatButtonToggle2 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const queryList = new QueryList<MatButtonToggle>();
        queryList.reset([mockMatButtonToggle1, mockMatButtonToggle2]);

        qcmHandlerServiceSpy.buttonsChanged.next(queryList);

        expect(component.toggleButtons).toEqual(queryList);
    });
    it('should subscribe to changes in toggleButtons and call updateToggleButtons', () => {
        const mockMatButtonToggle1 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const mockMatButtonToggle2 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const queryList = new QueryList<MatButtonToggle>();
        queryList.reset([mockMatButtonToggle1, mockMatButtonToggle2]);
        component['toggleButtons'] = queryList;
        component.ngAfterViewInit();
        queryList.notifyOnChanges();
        expect(qcmHandlerServiceSpy.updateToggleButtons).toHaveBeenCalledWith(queryList);
    });

    it('should put hasInteracted to false and isEvaluating to True when evaluation is in progress', () => {
        component['hasInteracted'] = true;
        component['isEvaluating'] = false;
        component.letIntoPage();
        socketHelper.peerSideEmit(AnswerEvent.EVALUATION_IN_PROGRESS);
        expect(component['hasInteracted']).toBeFalse();
        expect(component['isEvaluating']).toBeTrue();
    });
    it('should handle evaluationEnded correctly', () => {
        component['isEvaluating'] = true;
        const handleQuestionEndedSpy = jasmine.createSpy('handleQuestionEnded');

        Object.defineProperty(component, 'handleQuestionEnded', { value: handleQuestionEndedSpy });
        component.letIntoPage();
        socketHelper.peerSideEmit(AnswerEvent.EVALUATION_FINISHED);
        expect(component['isEvaluating']).toBeFalse();
    });
    it('should handle evaluationEnded correctly when testing', () => {
        component['isEvaluating'] = true;
        const handleQuestionEndedSpy = jasmine.createSpy('handleQuestionEnded');

        Object.defineProperty(component, 'handleQuestionEnded', { value: handleQuestionEndedSpy });
        component.testing = true;
        component.letIntoPage();
        socketHelper.peerSideEmit(AnswerEvent.EVALUATION_FINISHED);
        expect(component['isEvaluating']).toBeFalse();
    });
    it('should validate qrl answer correctly', () => {
        const qrlQuestion = (component['currentQuestion'] = {
            id: '1',
            type: QuestionType.QRL,
            text: 'Question 1',
            points: 10,
            choices: [{ text: 'Choice 1', isCorrect: false }],
            lastModification: '2024-02-13',
        });
        component['currentQuestion'] = qrlQuestion;
        component[AnswerEvent.VALIDATE_ANSWER]();
        expect(component['isPlaying']).toBeFalse();
        expect(component['buttonStyles'][0]).toBeFalsy();
    });
    it('should know when a player is afk', () => {
        component['hasInteracted'] = false;
        component[AnswerEvent.PLAYER_INTERACTED]();
        expect(component['hasInteracted']).toBeTrue();
    });
    it('should play panic sound and decrement time on panicCountdownUpdated event', () => {
        const panicSoundPlaySpy = spyOn(component['panicSound'], 'play');
        component.letIntoPage();

        socketHelper.peerSideEmit(PanicModeEvent.PANIC_COUNTDOWN_UPDATED);

        expect(panicSoundPlaySpy).toHaveBeenCalled();
        expect(timeServiceSpy.decrement).toHaveBeenCalled();
    });
    it('should set time correctly for QCM', () => {
        component['currentQuestion'] = MOCK_QUIZ.questions[0];
        component['quizDuration'] = 20;
        component['setTime']();

        expect(timeServiceSpy.setTime).toHaveBeenCalledWith(component['quizDuration']);
    });
    it('should set time correctly for QRL', () => {
        component['currentQuestion'] = MOCK_QUIZ.questions[2];
        component['setTime']();

        expect(timeServiceSpy.setTime).toHaveBeenCalledWith(QRL_DURATION);
    });

    it('should open abandon confirmation popup and navigate correctly when testing', () => {
        component.testing = true;

        (popUpService.openAbandon as jasmine.Spy).and.callFake((action?: () => void) => {
            if (action) {
                action();
            }
        });
        spyOn(component['socketClientService'], 'send');

        component['abandonButtonPressed']();

        expect(component['socketClientService'].send).toHaveBeenCalledWith(ConnectionEvent.LEAVE_ROOM);

        expect(routerSpy.navigate).toHaveBeenCalledWith(['/create']);
    });

    it('should open abandon confirmation popup and navigate correctly', () => {
        component.testing = false;

        (popUpService.openAbandon as jasmine.Spy).and.callFake((action?: () => void) => {
            if (action) {
                action();
            }
        });
        spyOn(component['socketClientService'], 'send');

        component['abandonButtonPressed']();

        expect(component['socketClientService'].send).toHaveBeenCalledWith(ConnectionEvent.LEAVE_ROOM);

        expect(routerSpy.navigate).toHaveBeenCalledWith(['/home']);
    });
});
