import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { TimeService } from '@app/services/time.service';
import { TimerEvent } from '@common/event-name';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-countdown',
    templateUrl: './countdown.component.html',
    styleUrls: ['./countdown.component.scss'],
})
export class CountdownComponent implements OnInit, OnDestroy {
    @Input() initialValue: number;
    @Input() text = '';
    @Input() title = '';
    @Input() gameId: string;
    @Output() countdownFinished: EventEmitter<void> = new EventEmitter<void>();
    timerSubscription: Subscription;

    constructor(
        readonly timeService: TimeService,
        readonly socketClientService: SocketClientService,
    ) {}

    get time(): number {
        return this.timeService.time;
    }

    ngOnInit() {
        this.startCountdown();
    }

    ngOnDestroy() {
        if (this.timerSubscription) {
            this.timerSubscription.unsubscribe();
        }
    }

    private startCountdown() {
        this.timeService.setTime(this.initialValue);
        this.socketClientService.on(TimerEvent.TIMER_TICK, () => {
            this.timeService.decrement();
        });
        this.socketClientService.send(TimerEvent.START_TIMER, this.gameId);
        this.timerSubscription = this.timeService.timerExpiredEvent.subscribe(() => {
            this.socketClientService.off(TimerEvent.TIMER_TICK);
            this.countdownFinished.emit();
        });
    }
}
