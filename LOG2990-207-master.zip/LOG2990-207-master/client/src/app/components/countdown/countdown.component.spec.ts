import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { TimeService } from '@app/services/time.service';
import { TimerEvent } from '@common/event-name';
import { Socket } from 'socket.io-client';
import { CountdownComponent } from './countdown.component';

describe('CountdownComponent', () => {
    let component: CountdownComponent;
    let fixture: ComponentFixture<CountdownComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;
    let timeService: TimeService;

    beforeEach(async () => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;
        await TestBed.configureTestingModule({
            declarations: [CountdownComponent],
            providers: [{ provide: SocketClientService, useValue: socketServiceMock }, TimeService],
        }).compileComponents();

        fixture = TestBed.createComponent(CountdownComponent);
        component = fixture.componentInstance;
        timeService = TestBed.inject(TimeService);
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should start countdown with initial value and decrement properly', fakeAsync(() => {
        component.initialValue = 3;
        component['startCountdown']();
        expect(component.time).toBe(3);
        component.timeService.decrement();
        expect(component.time).toBe(2);
        component.timeService.decrement();
        expect(component.time).toBe(1);
    }));

    it('should call off method of SocketClientService when timerExpiredEvent emits', fakeAsync(() => {
        spyOn(socketServiceMock, 'off');
        component['startCountdown']();
        timeService.timerExpiredEvent.next();
        tick();
        expect(socketServiceMock.off).toHaveBeenCalledWith(TimerEvent.TIMER_TICK);
    }));

    it('should decrement time service on timerTick', () => {
        spyOn(timeService, 'decrement');
        component.initialValue = 3;
        component['startCountdown']();
        socketHelper.peerSideEmit(TimerEvent.TIMER_TICK);
        expect(timeService.decrement).toHaveBeenCalled();
    });
});
