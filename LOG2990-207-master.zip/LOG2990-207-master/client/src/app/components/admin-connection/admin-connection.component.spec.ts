import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatIcon } from '@angular/material/icon';
import { GlowButtonComponent } from '@app/components/glow-button/glow-button.component';
import { CommunicationService } from '@app/services/http-services/communication.service';
import { of, throwError } from 'rxjs';
import { AdminConnectionComponent } from './admin-connection.component';

describe('AdminConnectionComponent', () => {
    let component: AdminConnectionComponent;
    let fixture: ComponentFixture<AdminConnectionComponent>;
    let communicationService: CommunicationService;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [AdminConnectionComponent, GlowButtonComponent, MatIcon],
            imports: [ReactiveFormsModule, HttpClientTestingModule],
            providers: [CommunicationService],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(AdminConnectionComponent);
        component = fixture.componentInstance;
        communicationService = TestBed.inject(CommunicationService);
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should initialize the form', () => {
        expect(component['loginForm']).toBeDefined();
    });

    it('should emit connection status when form is submitted with valid data', () => {
        const spy = spyOn(communicationService, 'credentialPost').and.returnValue(of(new HttpResponse({ status: 200, body: 'Success' })));
        component['loginForm'].setValue({ password: 'validpassword' });
        component['onSubmit']();
        expect(spy).toHaveBeenCalled();
        expect(component['connectionSuccessful']).toBe(true);
    });

    it('should handle error when server returns error', () => {
        spyOn(communicationService, 'credentialPost').and.returnValue(throwError(() => new Error('Error')));
        component['loginForm'].setValue({ password: 'invalidpassword' });
        component['onSubmit']();
        expect(component['message'].value).toContain('mauvais mot de passe ou la connexion au serveur a échoué');
    });

    it('should handle form submission with invalid data', () => {
        component['onSubmit']();
        expect(component['message'].value).toContain('Entrez des valeurs valides');
    });
});
