import { HttpResponse, HttpStatusCode } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommunicationService } from '@app/services/http-services/communication.service';
import { BehaviorSubject } from 'rxjs';

@Component({
    selector: 'app-admin-connection-component',
    templateUrl: './admin-connection.component.html',
    styleUrls: ['./admin-connection.component.scss'],
})
export class AdminConnectionComponent implements OnInit {
    @Output() connectionStatusChange: EventEmitter<boolean> = new EventEmitter<boolean>();
    protected loginForm: FormGroup;
    protected message: BehaviorSubject<string> = new BehaviorSubject<string>('');
    private connectionSuccessful: boolean = false;

    constructor(
        private formBuilder: FormBuilder,
        private readonly communicationService: CommunicationService,
    ) {}

    ngOnInit(): void {
        this.createForm();
    }

    protected onSubmit(): void {
        if (this.loginForm.valid) {
            const newConnectionAttempt: string = this.loginForm.value;
            this.communicationService.credentialPost(newConnectionAttempt).subscribe({
                next: (response: HttpResponse<string>) => {
                    if (response.status === HttpStatusCode.Ok) {
                        this.connectionSuccessful = true;
                        this.connectionStatusChange.emit(this.connectionSuccessful);
                    }
                    const responseString = `Le serveur a reçu la requête a retourné un code ${response.status} : ${response.statusText}`;
                    this.message.next(responseString);
                },
                error: () => {
                    const responseString = 'Vous avez entré un mauvais mot de passe ou la connexion au serveur a échoué.';
                    this.message.next(responseString);
                },
            });
        } else {
            this.message.next('Entrez des valeurs valides!');
        }
    }

    private createForm(): void {
        this.loginForm = this.formBuilder.group({
            password: ['', Validators.required],
        });
    }
}
