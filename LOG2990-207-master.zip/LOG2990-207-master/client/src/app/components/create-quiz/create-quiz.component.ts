import { HttpStatusCode } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { AdminState } from '@app/interfaces/admin-page.state';
import { QuestionService } from '@app/services/http-services/question.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { QUIZ_VALUES } from '@common/constants';
import { Question, Quiz } from '@common/quiz';
import { nanoid } from 'nanoid';

@Component({
    selector: 'app-create-quiz',
    templateUrl: './create-quiz.component.html',
    styleUrls: ['./create-quiz.component.scss'],
})
export class CreateQuizComponent implements OnInit {
    @Output()
    pageState: EventEmitter<AdminState> = new EventEmitter<AdminState>();
    @ViewChild('questionBankDialogContent')
    private readonly questionBankDialogContent: TemplateRef<HTMLElement>;

    protected quizOnPage: Quiz = {
        id: nanoid(),
        title: '',
        description: '',
        duration: QUIZ_VALUES.minTimeQuestion,
        lastModification: new Date().toDateString(),
        questions: [],
    };
    protected allQuestionsFromDatabase: Question[];

    protected readonly adminState = AdminState;
    private isNew: boolean = true;

    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        private route: ActivatedRoute,
        private quizService: QuizService,
        private snackBar: MatSnackBar,
        private questionService: QuestionService,
        private readonly matDialog: MatDialog,
    ) {}

    ngOnInit() {
        this.route.queryParams.subscribe((params) => {
            const idParam: string = params['id'];
            if (idParam) {
                this.loadQuiz(idParam);
                this.quizOnPage.id = idParam;
                this.isNew = false;
            }
        });
        this.questionService.getAllQuestions().subscribe((data) => {
            if (data) {
                this.allQuestionsFromDatabase = data;
            }
        });
    }
    protected onSliderInput(event: Event): void {
        const sliderValue = (event.target as HTMLInputElement).value;
        this.quizOnPage.duration = parseFloat(sliderValue);
    }

    protected updateQuestions(questions: Question[]) {
        this.quizOnPage.questions = questions;
    }

    protected updateSingleQuestion(question: Question) {
        if (!this.quizOnPage.questions.some((quest) => quest.id === question.id)) {
            this.quizOnPage.questions.push(question);
        }
    }
    protected toggleDisplayAddingFromDb() {
        this.matDialog.open(this.questionBankDialogContent);
    }
    protected onSubmit(): void {
        this.quizService.uploadQuizFromJson(this.quizOnPage, this.isNew).subscribe({
            next: (response) => {
                let responseString = '';
                if (response.status === HttpStatusCode.Ok) {
                    responseString = `Le serveur a modifié le quiz (${response.statusText}) : ${response.body}`;
                } else if (response.status === HttpStatusCode.Created) {
                    responseString = `Le serveur a créé le nouveau quiz (${response.statusText}) : ${response.body}`;
                }
                this.snackBar.open(responseString, 'OK');
                this.pageState.emit(AdminState.AdminHome);
            },
            error: (err) => {
                const responseString = `Erreur lors de la création/modification du quiz (${err.statusText}) : ${err.error}`;
                this.snackBar.open(responseString, 'OK');
            },
        });
    }
    private loadQuiz(id: string): void {
        this.quizService.getQuiz(id).subscribe((quiz: Quiz) => {
            if (quiz) {
                this.quizOnPage = quiz;
            }
        });
    }
}
