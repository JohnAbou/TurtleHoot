import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { QuestionBankComponent } from '@app/pages/question-bank-page/question-bank-page.component';
import { QuestionService } from '@app/services/http-services/question.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { MOCK_QUESTIONS } from '@common/constants';
import { Question, QuestionType, Quiz } from '@common/quiz';
import { of, throwError } from 'rxjs';
import { CreateQuizComponent } from './create-quiz.component';
describe('CreateQuizComponent', () => {
    let component: CreateQuizComponent;
    let fixture: ComponentFixture<CreateQuizComponent>;
    let mockActivatedRoute: unknown;
    let mockQuizService: jasmine.SpyObj<QuizService>;
    let mockQuestionService: jasmine.SpyObj<QuestionService>;

    beforeEach(async () => {
        mockQuestionService = jasmine.createSpyObj('QuestionService', ['getAllQuestions']);
        mockActivatedRoute = {
            queryParams: of({ id: '1a2b3c' }),
        };
        const mockQuiz: Quiz = {
            id: '1a2b3c',
            title: 'Questionnaire sur le JS',
            description: 'Questions de pratique sur le langage JavaScript',
            duration: 60,
            lastModification: '12 Feb 2024',
            questions: [],
        };

        mockQuizService = jasmine.createSpyObj('QuizService', ['uploadQuizFromJson', 'getQuiz']);
        mockQuizService.getQuiz.and.returnValue(of(mockQuiz));
        mockQuizService.uploadQuizFromJson.and.returnValue(of(new HttpResponse({ status: 200, body: 'Success' })));
        mockQuestionService.getAllQuestions.and.returnValue(of(MOCK_QUESTIONS));

        await TestBed.configureTestingModule({
            declarations: [CreateQuizComponent, QuestionBankComponent],
            imports: [FormsModule, HttpClientTestingModule, MatDialogModule, MatSnackBarModule, BrowserAnimationsModule],
            providers: [
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                { provide: QuizService, useValue: mockQuizService },
                { provide: MatDialog, useClass: MatDialog },
                { provide: QuestionService, useValue: mockQuestionService },
            ],
            schemas: [NO_ERRORS_SCHEMA],
        }).compileComponents();

        fixture = TestBed.createComponent(CreateQuizComponent);
        component = fixture.componentInstance;
        component['quizOnPage'] = mockQuiz;
        component['allQuestionsFromDatabase'] = MOCK_QUESTIONS;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should load quiz on init', () => {
        expect(component['quizOnPage'].id).toBe('1a2b3c');
        expect(component['quizOnPage'].title).toBe('Questionnaire sur le JS');
        expect(component['quizOnPage'].description).toBe('Questions de pratique sur le langage JavaScript');
        const expectedValue = 60;
        expect(component['quizOnPage'].duration).toBe(expectedValue);
    });

    it('should update duration on slider input', () => {
        const event = new Event('input');
        Object.defineProperty(event, 'target', {
            value: { value: '40' },
            writable: true,
        });
        component['onSliderInput'](event);
        const expectedValue = 40;
        expect(component['quizOnPage'].duration).toBe(expectedValue);
    });

    it('should submit quiz', () => {
        spyOn(component['snackBar'], 'open').and.callThrough();
        component['onSubmit']();
        expect(mockQuizService.uploadQuizFromJson).toHaveBeenCalledWith(component['quizOnPage'], false);
    });

    it('should handle error when submitting quiz', () => {
        const errorResponse = new HttpErrorResponse({ status: 500, statusText: 'Internal Server Error', error: 'Error occurred' });
        mockQuizService.uploadQuizFromJson.and.returnValue(throwError(() => errorResponse));
        spyOn(component['snackBar'], 'open').and.callThrough();
        component['onSubmit']();
        expect(component['snackBar'].open).toHaveBeenCalledWith(
            'Erreur lors de la création/modification du quiz (Internal Server Error) : Error occurred',
            'OK',
        );
    });

    it('should update single question if not already present', () => {
        const question: Question = { id: '1', text: 'Test question', choices: [], lastModification: '', type: QuestionType.QCM, points: 0 };
        component['updateSingleQuestion'](question);
        expect(component['quizOnPage'].questions.length).toBe(1);
        expect(component['quizOnPage'].questions[0]).toEqual(question);
    });

    it('should not update single question if already present', () => {
        const question: Question = { id: '1', text: 'Test question', choices: [], lastModification: '', type: QuestionType.QCM, points: 0 };
        component['quizOnPage'].questions.push(question);
        component['updateSingleQuestion'](question);
        expect(component['quizOnPage'].questions.length).toBe(1);
    });

    it('should fetch questions from server on init', () => {
        expect(component['allQuestionsFromDatabase']).toEqual(MOCK_QUESTIONS);
    });

    it('should load questions from the server on initialization', () => {
        component.ngOnInit();

        expect(component['allQuestionsFromDatabase']).toEqual(MOCK_QUESTIONS);
    });

    it('should update the questions in the quiz', () => {
        const mockQuestions: Question[] = [
            { id: '1', text: 'Question 1', choices: [], lastModification: '', type: QuestionType.QCM, points: 0 },
            { id: '2', text: 'Question 2', choices: [], lastModification: '', type: QuestionType.QCM, points: 0 },
        ];
        component['updateQuestions'](mockQuestions);
        expect(component['quizOnPage'].questions).toEqual(mockQuestions);
    });

    it('should submit quiz and handle created response', () => {
        const mockResponse = new HttpResponse({
            status: 201,
            statusText: 'Created',
            body: 'New Quiz Created',
        });
        mockQuizService.uploadQuizFromJson.and.returnValue(of(mockResponse));

        spyOn(component['snackBar'], 'open').and.callThrough();
        component['onSubmit']();

        expect(mockQuizService.uploadQuizFromJson).toHaveBeenCalledWith(component['quizOnPage'], false);
        expect(component['snackBar'].open).toHaveBeenCalledWith('Le serveur a créé le nouveau quiz (Created) : New Quiz Created', 'OK');
    });
});
