import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { RandomModeService } from '@app/services/random-mode.service';
import { MOCK_QUIZ, MOCK_QUIZZES } from '@common/constants';
import { ConnectionEvent } from '@common/event-name';
import { of, throwError } from 'rxjs';
import { Socket } from 'socket.io-client';
import { DialogueTextComponent } from './dialogue-text.component';

describe('DialogueTextComponent', () => {
    let component: DialogueTextComponent;
    let fixture: ComponentFixture<DialogueTextComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;
    let dialogRefSpy: jasmine.SpyObj<MatDialogRef<DialogueTextComponent>>;
    let randomModeService: RandomModeService;
    let socketClientService: SocketClientService;
    let mockQuizService: jasmine.SpyObj<QuizService>;

    beforeEach(async () => {
        mockQuizService = jasmine.createSpyObj('QuizService', ['getAllQuiz', 'getQuizVisibility', 'addQuiz']);
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;
        dialogRefSpy = jasmine.createSpyObj('MatDialogRef', ['close']);
        await TestBed.configureTestingModule({
            declarations: [DialogueTextComponent],
            imports: [BrowserAnimationsModule, HttpClientTestingModule, RouterTestingModule, MatDialogModule, MatSnackBarModule],
            providers: [
                { provide: MatDialogRef, useValue: dialogRefSpy },
                {
                    provide: MAT_DIALOG_DATA,
                    useValue: MOCK_QUIZ,
                },
                { provide: ActivatedRoute, useValue: { queryParamMap: of({ get: () => 'testGameId' }) } },
                { provide: SocketClientService, useValue: socketServiceMock },
                { provide: QuizService, useValue: mockQuizService },
            ],
        }).compileComponents();
        mockQuizService.addQuiz.and.returnValue(of(MOCK_QUIZ));
        mockQuizService.getAllQuiz.and.returnValue(of(MOCK_QUIZZES));
        mockQuizService.getQuizVisibility.and.returnValue(of(true));
        fixture = TestBed.createComponent(DialogueTextComponent);
        component = fixture.componentInstance;
        randomModeService = TestBed.inject(RandomModeService);
        socketClientService = TestBed.inject(SocketClientService);
        fixture.detectChanges();
    });

    it('should navigate to play area and close dialog on calling navigateToPlayArea', () => {
        const quizId = '1';
        spyOn(component.router, 'navigate');

        component['navigateToPlayArea'](quizId);
        expect(component.router.navigate).toHaveBeenCalledWith([`/game/${quizId}`], { queryParams: { testing: true } });
        expect(dialogRefSpy.close).toHaveBeenCalled();
    });

    it('should navigate to wait area and close dialog on calling navigateToWaitArea', () => {
        const quizId = '1';
        spyOn(component.router, 'navigate');
        const testGameId = 'testGameId';
        component['navigateToWaitArea'](quizId);
        socketHelper.peerSideEmit(ConnectionEvent.GAME_CREATED, testGameId);
        expect(dialogRefSpy.close).toHaveBeenCalled();

        expect(component.router.navigate).toHaveBeenCalledWith(['/wait'], {
            relativeTo: component.activatedRoute,
            queryParams: { gameId: testGameId },
        });
    });

    it('should navigate to wait area and close dialog on calling navigateToRandomPlayArea', () => {
        const quizId = '1-random';
        spyOn(component.router, 'navigate');
        const testGameId = 'testGameId';
        component['navigateToPlayArea'](quizId);
        socketHelper.peerSideEmit(ConnectionEvent.GAME_CREATED, testGameId);
        expect(dialogRefSpy.close).toHaveBeenCalled();

        expect(component.router.navigate).toHaveBeenCalledWith(['/wait'], {
            relativeTo: component.activatedRoute,
            queryParams: { gameId: testGameId },
        });
    });

    it('should display error message if quiz is deleted or not available', () => {
        spyOn(component['snackBar'], 'open').and.callThrough();
        const errorResponse = new HttpErrorResponse({ status: 404 });
        mockQuizService.getQuizVisibility.and.returnValue(throwError(() => errorResponse));
        component['navigateToPlayArea']('1');

        expect(component['snackBar'].open).toHaveBeenCalledWith(
            "Le quiz a été supprimé ou n'est plus disponible. Veuillez en sélectionner un autre.",
            'OK',
        );
    });

    it('should save the temp quiz and create a game', () => {
        const quizId = 'random-quiz-id';
        spyOn(socketClientService, 'send').and.callThrough();
        component['navigateToRandomPlayArea'](quizId);

        expect(mockQuizService.addQuiz).toHaveBeenCalledWith(randomModeService.quizRandom);
        expect(socketClientService.send).toHaveBeenCalledWith(ConnectionEvent.CREATE_GAME, quizId);
    });
});
