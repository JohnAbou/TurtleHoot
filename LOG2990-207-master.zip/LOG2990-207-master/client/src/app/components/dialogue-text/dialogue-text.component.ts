import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { QuizService } from '@app/services/http-services/quiz.service';
import { RandomModeService } from '@app/services/random-mode.service';
import { ConnectionEvent } from '@common/event-name';
import { QuestionType, Quiz } from '@common/quiz';

@Component({
    selector: 'app-dialogue-text',
    templateUrl: './dialogue-text.component.html',
    styleUrls: ['./dialogue-text.component.scss'],
})
export class DialogueTextComponent implements OnInit {
    questionType = QuestionType;

    // Nous avons disable cette erreur de lint car nous devons utiliser plus de 4 paramètres dans le construteur
    // eslint-disable-next-line max-params
    constructor(
        @Inject(MAT_DIALOG_DATA) public data: Quiz,
        public router: Router,
        public dialogRef: MatDialogRef<DialogueTextComponent>,
        private snackBar: MatSnackBar,
        private socketClientService: SocketClientService,
        public activatedRoute: ActivatedRoute,
        private randomModeService: RandomModeService,
        public quizService: QuizService,
    ) {}

    ngOnInit(): void {
        this.connect();
    }

    protected navigateToPlayArea(quizId: string): void {
        this.canNavigateToArea(quizId, 'game');
    }

    protected navigateToWaitArea(quizId: string): void {
        this.canNavigateToArea(quizId, 'wait');
    }

    protected displayErrorMessage(): void {
        this.snackBar.open("Le quiz a été supprimé ou n'est plus disponible. Veuillez en sélectionner un autre.", 'OK');
    }

    private connect() {
        this.socketClientService.on<string>(ConnectionEvent.GAME_CREATED, (gameId: string) => {
            const queryParams: Params = {
                gameId,
            };
            this.router.navigate(['/wait'], {
                relativeTo: this.activatedRoute,
                queryParams,
            });
        });
    }

    private canNavigateToArea(quizId: string, destination: string): void {
        if (quizId.includes('-random')) {
            this.navigateToRandomPlayArea(quizId);
            return;
        }

        this.quizService.getQuizVisibility(quizId).subscribe({
            next: (data) => {
                if (data) {
                    this.handleRouting(quizId, destination);
                } else {
                    this.displayErrorMessage();
                }
            },
            error: () => {
                this.displayErrorMessage();
            },
        });
    }

    private handleRouting(quizId: string, destination: string) {
        if (destination === 'game') {
            this.router.navigate(['/game/' + quizId], { queryParams: { testing: true } });
            this.dialogRef.close();
        } else if (destination === 'wait') {
            this.socketClientService.send(ConnectionEvent.CREATE_GAME, quizId);
            this.dialogRef.close();
        }
    }

    private navigateToRandomPlayArea(quizId: string): void {
        this.quizService.addQuiz(this.randomModeService.quizRandom).subscribe({
            next: () => {
                this.socketClientService.send(ConnectionEvent.CREATE_GAME, quizId);
                this.dialogRef.close();
            },
        });
    }
}
