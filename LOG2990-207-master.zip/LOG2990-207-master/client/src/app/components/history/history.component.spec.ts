import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { HistoryService } from '@app/services/http-services/history.service';
import { MOCK_HISTORY, MOCK_HISTORY2, MOCK_HISTORY3 } from '@common/constants';
import { SortField } from '@common/history';
import { HistoryComponent } from './history.component';

describe('HistoryComponent', () => {
    let component: HistoryComponent;
    let fixture: ComponentFixture<HistoryComponent>;
    let mockHistoryService: jasmine.SpyObj<HistoryService>;
    let popUpService: jasmine.SpyObj<PopUpService>;

    beforeEach(async () => {
        popUpService = jasmine.createSpyObj('PopUpService', ['openCareful']);
        const historyServiceSpy = jasmine.createSpyObj('HistoryService', ['getAllHistory', 'deleteAllHistory']);

        await TestBed.configureTestingModule({
            declarations: [HistoryComponent],
            providers: [
                { provide: HistoryService, useValue: historyServiceSpy },
                { provide: PopUpService, useValue: popUpService },
            ],
            imports: [MatSelectModule, MatFormFieldModule, BrowserAnimationsModule],
        }).compileComponents();

        mockHistoryService = TestBed.inject(HistoryService) as jasmine.SpyObj<HistoryService>;
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(HistoryComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should call history service on init', async () => {
        mockHistoryService.getAllHistory.and.returnValue(Promise.resolve(MOCK_HISTORY));

        await component.ngOnInit();

        expect(mockHistoryService.getAllHistory).toHaveBeenCalled();
        expect(component['history']).toEqual(MOCK_HISTORY);
    });

    it('should delete history when "Oui" button is clicked in the dialog', () => {
        (popUpService.openCareful as jasmine.Spy).and.callFake((text: string, action?: () => void) => {
            if (action) {
                action();
            }
        });

        component['deleteButtonPressed']();

        expect(mockHistoryService.deleteAllHistory).toHaveBeenCalled();
    });

    it('should sort history in ascending order by title', () => {
        component['history'] = [...MOCK_HISTORY3];

        component['sortBy'](SortField.QuizTitle);
        expect(component['history'][0].quizTitle).toBe('A');
        expect(component['history'][1].quizTitle).toBe('B');
    });

    it('should sort history in descending order by title', () => {
        component['history'] = [...MOCK_HISTORY];
        component['sortByField'] = SortField.QuizTitle;
        component['sortBy'](SortField.QuizTitle);
        expect(component['history'][0].quizTitle).toBe('C');
        expect(component['history'][1].quizTitle).toBe('B');
        expect(component['history'][2].quizTitle).toBe('A');
    });

    it('should sort history in ascending order by player count', () => {
        component['history'] = [...MOCK_HISTORY];
        component['sortBy'](SortField.PlayerCount);
        expect(component['history'][0].quizTitle).toBe('C');
        expect(component['history'][1].quizTitle).toBe('B');
        expect(component['history'][2].quizTitle).toBe('A');
    });

    it('should sort history in descending order by player count', () => {
        component['history'] = [...MOCK_HISTORY];
        component['sortByField'] = SortField.PlayerCount;
        component['sortBy'](SortField.PlayerCount);
        expect(component['history'][0].quizTitle).toBe('A');
        expect(component['history'][1].quizTitle).toBe('B');
        expect(component['history'][2].quizTitle).toBe('C');
    });

    it('should sort history in ascending order by best score', () => {
        component['history'] = [...MOCK_HISTORY];
        component['sortBy'](SortField.BestScore);
        expect(component['history'][0].quizTitle).toBe('C');
        expect(component['history'][1].quizTitle).toBe('B');
        expect(component['history'][2].quizTitle).toBe('A');
    });

    it('should sort history in descending order by best score', () => {
        component['history'] = [...MOCK_HISTORY];
        component['sortByField'] = SortField.BestScore;
        component['sortBy'](SortField.BestScore);
        expect(component['history'][0].quizTitle).toBe('A');
        expect(component['history'][1].quizTitle).toBe('B');
        expect(component['history'][2].quizTitle).toBe('C');
    });

    it('should sort history in ascending order by start time', () => {
        component['history'] = [...MOCK_HISTORY];
        component['sortByField'] = SortField.BestScore;
        component['sortBy'](SortField.StartTime);
        expect(component['history'][0].quizTitle).toBe('A');
        expect(component['history'][1].quizTitle).toBe('B');
        expect(component['history'][2].quizTitle).toBe('C');
    });

    it('should sort history in descending order by start time', () => {
        component['history'] = [...MOCK_HISTORY];
        component['sortByField'] = SortField.StartTime;
        component['sortBy'](SortField.StartTime);
        expect(component['history'][0].quizTitle).toBe('C');
        expect(component['history'][1].quizTitle).toBe('B');
        expect(component['history'][2].quizTitle).toBe('A');
    });

    it('should sort history in ascending order by end time', () => {
        component['history'] = [...MOCK_HISTORY];
        component['sortBy'](SortField.EndTime);
        expect(component['history'][0].quizTitle).toBe('A');
        expect(component['history'][1].quizTitle).toBe('B');
        expect(component['history'][2].quizTitle).toBe('C');
    });

    it('should sort history in descending order by end time', () => {
        component['history'] = [...MOCK_HISTORY];
        component['sortByField'] = SortField.EndTime;
        component['sortBy'](SortField.EndTime);
        expect(component['history'][0].quizTitle).toBe('C');
        expect(component['history'][1].quizTitle).toBe('B');
        expect(component['history'][2].quizTitle).toBe('A');
    });

    it('should sort history in descending order by end time', () => {
        component['history'] = [...MOCK_HISTORY2];
        component['sortByField'] = SortField.EndTime;
        component['sortBy'](SortField.EndTime);
        expect(component['history'][0].quizTitle).toBe('A');
        expect(component['history'][1].quizTitle).toBe('A');
    });
});
