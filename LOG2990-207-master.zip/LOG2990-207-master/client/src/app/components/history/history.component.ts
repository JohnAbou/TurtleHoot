import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { PopUpService } from '@app/services/envent-handler-services/pop-up.service';
import { HistoryService } from '@app/services/http-services/history.service';
import { ASC_DIRECTION, DESC_DIRECTION } from '@common/constants';
import { HistoryInformation, SortField } from '@common/history';
@Component({
    selector: 'app-history',
    templateUrl: './history.component.html',
    styleUrls: ['./history.component.scss'],
})
export class HistoryComponent implements OnInit {
    protected history: HistoryInformation[];
    protected sortField = SortField;
    protected sortByField: SortField = SortField.StartTime;
    protected sortDirection: number = 1;
    constructor(
        private historyService: HistoryService,
        private changeDetectorRef: ChangeDetectorRef,
        private popUpService: PopUpService,
    ) {}

    async ngOnInit() {
        this.history = await this.historyService.getAllHistory();
    }

    protected deleteButtonPressed(): void {
        const text = "Voulez vous vraiment vider l'historique ? Vous ne pourrez plus récupérer l'information supprimée.";
        this.popUpService.openCareful(text, async () => {
            this.historyService.deleteAllHistory();
            this.history = [];
            this.changeDetectorRef.detectChanges();
        });
    }
    protected sortBy(field: SortField): void {
        this.handleSortValue(field);
        this.sortData();
    }
    private handleSortValue(field: SortField) {
        if (field === this.sortByField) {
            this.sortDirection *= -1;
        } else {
            this.sortDirection = 1;
            this.sortByField = field;
        }
    }
    private sortData() {
        this.history.sort((a, b) => {
            const aValue = a[this.sortByField];
            const bValue = b[this.sortByField];
            if (this.sortByField === SortField.QuizTitle) {
                const aTitleValue = a.quizTitle.toLowerCase();
                const bTitleValue = b.quizTitle.toLowerCase();
                if (aTitleValue > bTitleValue) return ASC_DIRECTION * this.sortDirection;
                if (aTitleValue < bTitleValue) return DESC_DIRECTION * this.sortDirection;
            }
            if (aValue < bValue) return ASC_DIRECTION * this.sortDirection;
            if (aValue > bValue) return DESC_DIRECTION * this.sortDirection;
            return 0;
        });
    }
}
