import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GlowButtonComponent } from './glow-button.component';

describe('GlowButtonComponent', () => {
    let component: GlowButtonComponent;
    let fixture: ComponentFixture<GlowButtonComponent>;
    let buttonElement: HTMLElement;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [GlowButtonComponent],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(GlowButtonComponent);
        component = fixture.componentInstance;
        buttonElement = fixture.nativeElement.querySelector('button');
        fixture.detectChanges();
    });

    it('should create the component', () => {
        expect(component).toBeTruthy();
    });

    it('should set default values if inputs are not provided', () => {
        expect(component.buttonText).toEqual('Button');
        expect(component.height).toEqual('auto');
        expect(component.width).toEqual('auto');
        expect(component.backgroundColor).toEqual('#27282c');
        expect(component.color).toEqual('#1e9bff');
        expect(component.animationColor).toEqual('#27282c');
        expect(component.fontSize).toEqual('1.05em');
    });

    it('should display the button text correctly', () => {
        const buttonText = 'Click me!';
        component.buttonText = buttonText;
        fixture.detectChanges();
        expect(buttonElement?.textContent?.trim()).toEqual(buttonText);
    });
});
