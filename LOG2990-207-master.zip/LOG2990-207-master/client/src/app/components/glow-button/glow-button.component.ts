import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-glow-button',
    templateUrl: './glow-button.component.html',
    styleUrls: ['./glow-button.component.scss'],
})
export class GlowButtonComponent {
    @Input() buttonText: string = 'Button';
    @Input() height: string = 'auto';
    @Input() width: string = 'auto';
    @Input() backgroundColor: string = '#27282c';
    @Input() color: string = '#1e9bff';
    @Input() animationColor: string = '#27282c';
    @Input() fontSize: string = '1.05em';
}
