import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ChatEvent, GameEvent } from '@common/event-name';
import { Message } from '@common/user-message';
import { Socket } from 'socket.io-client';
import { ChatboxComponent } from './chatbox.component';

describe('ChatboxComponent', () => {
    let component: ChatboxComponent;
    let fixture: ComponentFixture<ChatboxComponent>;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;

    beforeEach(async () => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;

        await TestBed.configureTestingModule({
            declarations: [ChatboxComponent],
            providers: [{ provide: SocketClientService, useValue: socketServiceMock }],
            imports: [FormsModule, MatDialogModule],
            schemas: [NO_ERRORS_SCHEMA],
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ChatboxComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should initialize with isMinimized set to false', () => {
        expect(component['isMinimized']).toBeFalse();
    });

    it('should toggle isMinimized property on calling toggleChat', () => {
        expect(component['isMinimized']).toBeFalse();

        component['toggleChat']();
        expect(component['isMinimized']).toBeTrue();

        component['toggleChat']();
        expect(component['isMinimized']).toBeFalse();
    });

    it('should get the id of the socket', () => {
        socketServiceMock.socket.id = '123';
        const socketId = component.socketId;
        expect(socketId).toEqual('123');
    });

    describe('Emiting events', () => {
        it('should add a message to roomMessages array from server on roomMessage event', () => {
            const roomMessage: Message = { socketId: '123', username: '123', text: 'message 1', time: 'time' };
            socketHelper.peerSideEmit(ChatEvent.ROOM_MESSAGE, roomMessage);
            expect(component['messages'].length).toBe(1);
            expect(component['messages']).toContain(roomMessage);
        });

        it('should add multiple messages to roomMessages array from server on multiple roomMessage events', () => {
            const roomMessages: Message[] = [
                { socketId: '123', username: '123', text: 'message 1', time: 'time1' },
                { socketId: '124', username: '124', text: 'message 2', time: 'time2' },
                { socketId: '125', username: '125', text: 'message 3', time: 'time3' },
            ];
            roomMessages.forEach((message) => socketHelper.peerSideEmit(ChatEvent.ROOM_MESSAGE, message));
            expect(component['messages'].length).toBe(roomMessages.length);
            expect(component['messages']).toEqual(roomMessages);
        });

        it('should send a message to a specific room on the server and reset roomMessage with a roomMessage event', () => {
            const spy = spyOn(component.socketClientService, 'send');
            const eventName = ChatEvent.ROOM_MESSAGE;
            const testString = 'test';
            component['message'] = testString;
            component['sendMessage']();
            expect(spy).toHaveBeenCalledWith(eventName, testString);
            expect(component['message']).toEqual('');
        });
    });

    it('should update the username when receiving username event from server', () => {
        const testUsername = 'testUser';
        socketHelper.peerSideEmit(GameEvent.GET_USERNAME, testUsername);
        expect(component['username']).toEqual(testUsername);
    });

    it('should update the mute state of the user when receiving playerMuteToggled event from server', () => {
        const muteState = true;
        socketHelper.peerSideEmit(ChatEvent.TOOGLE_MUTE_PLAYER, muteState);
        expect(component['isMuted']).toEqual(muteState);
        expect(component['messages'][0].text).toEqual("L'organisateur vous a retiré le droit de clavardage.");
    });

    it('should update the mute state of the user when receiving playerMuteToggled event from server', () => {
        const muteState = false;
        socketHelper.peerSideEmit(ChatEvent.TOOGLE_MUTE_PLAYER, muteState);
        expect(component['isMuted']).toEqual(muteState);
        expect(component['messages'][0].text).toEqual("L'organisateur vous a redonné le droit de clavardage.");
    });

    it('should update the room messages when receiving room message event from server', () => {
        const testRoomMessages: Message[] = [
            { socketId: '123', username: 'user1', text: 'message1', time: 'time1' },
            { socketId: '124', username: 'user2', text: 'message2', time: 'time2' },
        ];
        socketHelper.peerSideEmit(ChatEvent.GET_ROOM_MESSAGES, testRoomMessages);
        expect(component['messages']).toEqual(testRoomMessages);
    });
});
