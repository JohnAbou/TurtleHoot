import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { SocketClientService } from '@app/services/envent-handler-services/socket-client.service';
import { ChatEvent, GameEvent } from '@common/event-name';
import { Message } from '@common/user-message';

@Component({
    selector: 'app-chatbox',
    templateUrl: './chatbox.component.html',
    styleUrls: ['./chatbox.component.scss'],
    changeDetection: ChangeDetectionStrategy.Default,
})
export class ChatboxComponent implements OnInit, OnDestroy {
    protected username: string;
    protected isMuted = false;
    protected isMinimized = false;
    protected messages: Message[] = [];
    protected message = '';

    constructor(public socketClientService: SocketClientService) {}

    get socketId() {
        return this.socketClientService.socket.id;
    }

    ngOnInit(): void {
        this.configureBaseSocketFeatures();
        this.getRoomMessages();
        this.getUsername();
    }

    ngOnDestroy() {
        this.messages = [];
        this.socketClientService.off(ChatEvent.ROOM_MESSAGE);
        this.socketClientService.off(ChatEvent.GET_ROOM_MESSAGES);
        this.socketClientService.off(GameEvent.GET_USERNAME);
        this.socketClientService.off(ChatEvent.TOOGLE_MUTE_PLAYER);
    }

    protected sendMessage() {
        const trimmedMessage = this.message.trim();

        if (trimmedMessage) {
            this.message = trimmedMessage;
            this.sendToRoom();
        }
    }

    protected toggleChat() {
        this.isMinimized = !this.isMinimized;
    }

    private configureBaseSocketFeatures() {
        this.configureRoomMessage();
        this.configureRoomMessages();
        this.configureUsername();
        this.configurePlayerMuteToggled();
    }

    private configureRoomMessage() {
        this.socketClientService.on<Message>(ChatEvent.ROOM_MESSAGE, (data) => {
            const message: Message = {
                socketId: data.socketId,
                username: data.username,
                text: data.text,
                time: data.time,
            };
            this.messages.push(message);
        });
    }
    private configureRoomMessages() {
        this.socketClientService.on<Message[]>(ChatEvent.GET_ROOM_MESSAGES, (data) => {
            this.messages = data.slice();
        });
    }
    private configureUsername() {
        this.socketClientService.on<string>(GameEvent.GET_USERNAME, (data) => {
            this.username = data;
        });
    }
    private configurePlayerMuteToggled() {
        this.socketClientService.on<boolean>(ChatEvent.TOOGLE_MUTE_PLAYER, (muteState: boolean) => {
            this.isMuted = muteState;
            this.message = '';
            const message: Message = {
                socketId: 'muteToggled',
                username: '',
                text: `L'organisateur vous a ${muteState ? 'retiré' : 'redonné'} le droit de clavardage.`,
                time: '',
            };
            this.messages.push(message);
        });
    }

    private sendToRoom() {
        this.socketClientService.send(ChatEvent.ROOM_MESSAGE, this.message);
        this.message = '';
    }

    private getRoomMessages() {
        this.socketClientService.send(ChatEvent.GET_ROOM_MESSAGES);
    }

    private getUsername() {
        this.socketClientService.send(GameEvent.GET_USERNAME);
    }
}
