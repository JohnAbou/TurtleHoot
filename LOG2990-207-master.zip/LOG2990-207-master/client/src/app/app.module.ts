import { CdkAccordionModule } from '@angular/cdk/accordion';
import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AccordeonComponent } from '@app/components/accordeon/accordeon.component';
import { AdminConnectionComponent } from '@app/components/admin-connection/admin-connection.component';
import { ChatboxComponent } from '@app/components/chatbox/chatbox.component';
import { DialogueTextComponent } from '@app/components/dialogue-text/dialogue-text.component';
import { GameListComponent } from '@app/components/game-list/game-list.component';
import { GlowButtonComponent } from '@app/components/glow-button/glow-button.component';
import { HeaderAdminComponent } from '@app/components/header-admin/header-admin.component';
import { ImportQuizComponent } from '@app/components/import-quiz/import-quiz.component';
import { AppRoutingModule } from '@app/modules/app-routing.module';
import { AppMaterialModule } from '@app/modules/material.module';
import { AdminPageComponent } from '@app/pages/admin-page/admin-page.component';
import { AppComponent } from '@app/pages/app/app.component';
import { CreateGamePageComponent } from '@app/pages/create-game-page/create-game-page.component';
import { GamePageComponent } from '@app/pages/game-page/game-page.component';
import { HomePageComponent } from '@app/pages/home-page/home-page.component';
import { WaitPageComponent } from '@app/pages/wait-page/wait-page.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { CountdownComponent } from './components/countdown/countdown.component';
import { CreateQuizComponent } from './components/create-quiz/create-quiz.component';
import { FormComponent } from './components/form/form.component';
import { GlowButtonImageComponent } from './components/glow-button-image/glow-button-image.component';
import { HeaderBarComponent } from './components/header-bar/header-bar.component';
import { HistoryComponent } from './components/history/history.component';
import { JoinGameComponent } from './components/join-game/join-game.component';
import { NameListComponent } from './components/name-list/name-list.component';
import { PlayAreaComponent } from './components/play-area/play-area.component';
import { PlayerListComponent } from './components/player-list/player-list.component';
import { PopUpComponent } from './components/pop-up/pop-up.component';
import { ResultsComponent } from './components/results/results.component';
import { ReviewComponent } from './components/review/review.component';
import { TimerNumberComponent } from './components/timer-number/timer-number.component';
import { OrganizerPageComponent } from './pages/organizer-page/organizer-page.component';
import { QuestionBankComponent } from './pages/question-bank-page/question-bank-page.component';
import { ResultPageComponent } from './pages/result-page/result-page.component';
import { SocketClientService } from './services/envent-handler-services/socket-client.service';
/**
 * Main module that is used in main.ts.
 * All automatically generated components will appear in this module.
 * Please do not move this module in the module folder.
 * Otherwise Angular Cli will not know in which module to put new component
 */
@NgModule({
    declarations: [
        AppComponent,
        JoinGameComponent,
        HistoryComponent,
        GamePageComponent,
        HomePageComponent,
        WaitPageComponent,
        QuestionBankComponent,
        HeaderAdminComponent,
        ImportQuizComponent,
        GameListComponent,
        AdminConnectionComponent,
        AdminPageComponent,
        AccordeonComponent,
        DialogueTextComponent,
        ChatboxComponent,
        GlowButtonComponent,
        CreateGamePageComponent,
        HeaderBarComponent,
        FormComponent,
        GlowButtonImageComponent,
        PlayAreaComponent,
        CreateQuizComponent,
        OrganizerPageComponent,
        NameListComponent,
        PlayerListComponent,
        PopUpComponent,
        ResultPageComponent,
        ResultsComponent,
        CountdownComponent,
        TimerNumberComponent,
        ReviewComponent,
    ],

    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        FormsModule,
        CdkAccordionModule,
        AppRoutingModule,
        AppMaterialModule,
        MatSnackBarModule,
        MatDialogModule,
        HttpClientModule,
        NgxChartsModule,
        MatSelectModule,
        MatFormFieldModule,
    ],

    providers: [SocketClientService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    bootstrap: [AppComponent],
})
export class AppModule {}
