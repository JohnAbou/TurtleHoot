import { Injectable } from '@angular/core';
import { INTERACTION_COOLDOWN } from '@common/constants';

@Injectable({
    providedIn: 'root',
})
export class InteractionTimerService {
    private interactTimer: ReturnType<typeof setTimeout> | undefined;
    private interactDelay: number = INTERACTION_COOLDOWN;

    startInteractionTimer(onTimerExpire: () => void) {
        if (this.interactTimer) {
            clearTimeout(this.interactTimer);
        }

        this.interactTimer = setTimeout(() => {
            onTimerExpire();
        }, this.interactDelay);
    }

    resetInteractionTimer() {
        if (this.interactTimer) {
            clearTimeout(this.interactTimer);
        }
    }
}
