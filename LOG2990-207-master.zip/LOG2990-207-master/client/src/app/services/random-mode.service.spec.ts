import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { MOCK_QUESTION, MOCK_QUESTIONS } from '@common/constants';
import { Question, QuestionType } from '@common/quiz';
import { of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RandomModeService } from './random-mode.service';

describe('RandomModeService', () => {
    let service: RandomModeService;
    let httpMock: HttpTestingController;
    const QUESTION_DELAY = 20;
    const NUMBER_OF_QUESTIONS = 5;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [RandomModeService],
        });
        service = TestBed.inject(RandomModeService);
        httpMock = TestBed.inject(HttpTestingController);
    });

    afterEach(() => {
        httpMock.verify();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should retrieve questions from the server', () => {
        const mockQuestions: Question[] = MOCK_QUESTIONS;
        service.getQuestionsQcm().subscribe((questions) => {
            expect(questions).toEqual(mockQuestions);
        });

        const req = httpMock.expectOne(`${environment.serverUrl}/questionbank`);
        expect(req.request.method).toBe('GET');
        req.flush(mockQuestions);
    });

    it('should check if there are enough questions', () => {
        const mockQuestions: Question[] = [MOCK_QUESTION, MOCK_QUESTION, MOCK_QUESTION, MOCK_QUESTION, MOCK_QUESTION];
        const result = service.hasEnoughQuestionsQcm(mockQuestions);
        expect(result).toBeTrue();
    });

    it('should generate a random quiz', () => {
        const firstQuestion: Question = {
            type: QuestionType.QCM,
            text: '#1',
            points: 40,
            choices: [
                { text: 'Choice 1', isCorrect: true },
                { text: 'Choice 2', isCorrect: false },
            ],
            id: '',
            lastModification: '',
        };

        const mockQuestions: Question[] = [firstQuestion, MOCK_QUESTION, MOCK_QUESTION, MOCK_QUESTION, MOCK_QUESTION];
        const randomQuiz = service.getQuizRandom(mockQuestions);

        expect(randomQuiz.id).toContain('-random');
        expect(randomQuiz.title).toBe('mode aléatoire');
        expect(randomQuiz.duration).toBe(QUESTION_DELAY);
        expect(randomQuiz.description).toContain('questions ont été choisies aléatoirement');
        expect(randomQuiz.questions.length).toBe(NUMBER_OF_QUESTIONS);
    });

    it('should get a random index', () => {
        const randomIndex = service['getRandomIndex'](MOCK_QUESTIONS);

        expect(randomIndex).toBeGreaterThanOrEqual(0);
        expect(randomIndex).toBeLessThan(MOCK_QUESTIONS.length);
    });

    it('should delete a temporary quiz', () => {
        const quizId = 'temp-quiz';
        const mockResponse: HttpResponse<string> = new HttpResponse({ status: 200, statusText: 'OK' });
        spyOn(service['http'], 'delete').and.returnValue(of(mockResponse));
        service.deleteTempQuiz(quizId).subscribe((response) => {
            expect(response).toEqual(mockResponse);
        });
    });
});
