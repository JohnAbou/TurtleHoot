import { TestBed } from '@angular/core/testing';
import { FormService } from './form-validation.service';

describe('FormService', () => {
    let service: FormService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [FormService],
        });
        service = TestBed.inject(FormService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should return true if at least one checkbox is checked', () => {
        const checkboxesState = [true, false, false];
        expect(service.isAtLeastOne(true, checkboxesState)).toBeTrue();
    });

    it('should return true if at least one checkbox is unchecked', () => {
        const checkboxesState = [true, false, false];
        expect(service.isAtLeastOne(false, checkboxesState)).toBeTrue();
    });

    it('should return false if no checkbox is checked', () => {
        const checkboxesState = [false, false, false];
        expect(service.isAtLeastOne(true, checkboxesState)).toBeFalse();
    });

    it('should move response up correctly', () => {
        const responseValues = ['A', 'B', 'C'];
        const checkboxesState = [true, false, true];
        service.moveResponseUp(responseValues, checkboxesState, 1);
        expect(responseValues).toEqual(['B', 'A', 'C']);
        expect(checkboxesState).toEqual([false, true, true]);
    });

    it('should move response down correctly', () => {
        const responseValues = ['A', 'B', 'C'];
        const checkboxesState = [true, false, true];
        service.moveResponseDown(responseValues, checkboxesState, 1);
        expect(responseValues).toEqual(['A', 'C', 'B']);
        expect(checkboxesState).toEqual([true, true, false]);
    });
});
