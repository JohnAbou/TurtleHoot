import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class FormService {
    isAtLeastOne(checked: boolean, checkboxesState: boolean[]): boolean {
        return checkboxesState.some((state) => (checked ? state : !state));
    }

    moveResponseUp(responseValues: string[], checkboxesState: boolean[], index: number): void {
        if (index > 0) {
            this.swap(responseValues, index, index - 1);
            this.swap(checkboxesState, index, index - 1);
        }
    }

    moveResponseDown(responseValues: string[], checkboxesState: boolean[], index: number): void {
        if (index < responseValues.length - 1) {
            this.swap(responseValues, index, index + 1);
            this.swap(checkboxesState, index, index + 1);
        }
    }

    private swap(array: unknown[], index1: number, index2: number): void {
        const temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
    }
}
