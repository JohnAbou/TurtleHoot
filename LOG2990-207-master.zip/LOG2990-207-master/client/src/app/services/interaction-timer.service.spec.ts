import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { InteractionTimerService } from './interaction-timer.service';

describe('InteractionTimerService', () => {
    let service: InteractionTimerService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [InteractionTimerService],
        });
        service = TestBed.inject(InteractionTimerService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should start interaction timer', fakeAsync(() => {
        let timerExpired = false;
        const onTimerExpire = () => {
            timerExpired = true;
        };

        service.startInteractionTimer(onTimerExpire);

        expect(timerExpired).toBe(false);

        tick(service['interactDelay']);

        expect(timerExpired).toBe(true);
    }));

    it('should restart interaction timer', fakeAsync(() => {
        const tickTime = 4000;
        const remainingTime = 1000;
        let timerExpired = false;
        const onTimerExpire = () => {
            timerExpired = true;
        };

        service.startInteractionTimer(onTimerExpire);

        expect(timerExpired).toBe(false);

        tick(tickTime);

        service.startInteractionTimer(onTimerExpire);

        tick(remainingTime);

        expect(timerExpired).toBe(false);

        tick(service['interactDelay']);
    }));

    it('should reset interaction timer', fakeAsync(() => {
        let timerExpired = false;
        const onTimerExpire = () => {
            timerExpired = true;
        };

        service.startInteractionTimer(onTimerExpire);
        expect(timerExpired).toBe(false);

        service.resetInteractionTimer();
        tick(service['interactDelay']);

        expect(timerExpired).toBe(false);
    }));
});
