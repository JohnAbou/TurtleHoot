import { TestBed } from '@angular/core/testing';
import { MOCK_QUESTION } from '@common/constants';
import { AnswerEvent } from '@common/event-name';
import { QrlHandlerService } from './qrl-handler.service';
import { SocketClientService } from './socket-client.service';

describe('QrlHandlerService', () => {
    let service: QrlHandlerService;
    let socketClientServiceSpy: jasmine.SpyObj<SocketClientService>;

    beforeEach(() => {
        const socketClientServiceSpyObj = jasmine.createSpyObj('SocketClientService', ['send']);
        TestBed.configureTestingModule({
            providers: [{ provide: SocketClientService, useValue: socketClientServiceSpyObj }],
        });
        service = TestBed.inject(QrlHandlerService);
        socketClientServiceSpy = TestBed.inject(SocketClientService) as jasmine.SpyObj<SocketClientService>;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should validate QRL answer and send data to socket client service', () => {
        const time = 60;

        service.validateQrlAnswer(time, MOCK_QUESTION, '');

        expect(socketClientServiceSpy.send).toHaveBeenCalledWith(AnswerEvent.VALIDATE_QRL_ANSWER, {
            timeLeft: time,
            question: MOCK_QUESTION,
            answer: '',
        });
    });
});
