import { Injectable, QueryList } from '@angular/core';
import { MatButtonToggle } from '@angular/material/button-toggle';
import { AnswerEvent } from '@common/event-name';
import { Question } from '@common/quiz';
import { Subject } from 'rxjs';
import { SocketClientService } from './socket-client.service';

@Injectable({
    providedIn: 'root',
})
export class QcmHandlerService {
    buttonsChanged = new Subject<QueryList<MatButtonToggle>>();
    testing = false;
    private toggleButtons: QueryList<MatButtonToggle>;

    constructor(private socketClientService: SocketClientService) {}

    updateToggleButtons(toggleButtons: QueryList<MatButtonToggle>): void {
        this.toggleButtons = toggleButtons;
    }

    validateQcmAnswer(time: number, currentQuestion: Question, buttonsSelected: { [key: string]: boolean }): { [key: string]: boolean } {
        const buttonsSelectedUpdated = this.updateButtonsSelected(buttonsSelected);
        this.socketClientService.send(AnswerEvent.VALIDATE_QCM_ANSWER, {
            timeLeft: time,
            question: currentQuestion,
            buttonsSelected: buttonsSelectedUpdated,
        });
        return buttonsSelectedUpdated;
    }

    onTogglePressed(index: number, currentQuestionIndex: number): void {
        this.sendChoiceSelected(index, this.toggleButtons.toArray()[index].checked, currentQuestionIndex);
    }

    toggleButton(index: number, currentQuestionIndex: number): void {
        const specificButton = this.toggleButtons.toArray()[index - 1];

        if (specificButton) {
            specificButton.checked = !specificButton.checked;
            this.buttonsChanged.next(this.toggleButtons);
            this.sendChoiceSelected(index - 1, specificButton.checked, currentQuestionIndex);
        }
    }

    private sendChoiceSelected(choiceIndex: number, isSelected: boolean, currentQuestionIndex: number): void {
        if (!this.testing) {
            this.socketClientService.send(AnswerEvent.CHOICE_SELECTED, {
                questionIndex: currentQuestionIndex,
                choiceIndex,
                isSelected,
                choicesLength: this.toggleButtons.toArray().length,
            });
        }
    }

    private updateButtonsSelected(buttonsSelected: { [key: string]: boolean }): { [key: string]: boolean } {
        this.toggleButtons.forEach((button, index) => {
            buttonsSelected[index] = button.checked;
            button.checked = true;
            button.disabled = true;
        });
        this.buttonsChanged.next(this.toggleButtons);
        return buttonsSelected;
    }
}
