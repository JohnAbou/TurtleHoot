import { QueryList } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { MatButtonToggle } from '@angular/material/button-toggle';
import { MOCK_QUESTION } from '@common/constants';
import { AnswerEvent } from '@common/event-name';
import { QcmHandlerService } from './qcm-handler.service';
import { SocketClientService } from './socket-client.service';

describe('QcmHandlerService', () => {
    let service: QcmHandlerService;
    let socketClientServiceSpy: jasmine.SpyObj<SocketClientService>;

    beforeEach(() => {
        const mockMatButtonToggle1 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const mockMatButtonToggle2 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const queryList = new QueryList<MatButtonToggle>();
        queryList.reset([mockMatButtonToggle1, mockMatButtonToggle2]);

        const socketClientServiceSpyObj = jasmine.createSpyObj('SocketClientService', ['send']);
        TestBed.configureTestingModule({
            providers: [{ provide: SocketClientService, useValue: socketClientServiceSpyObj }],
        });
        service = TestBed.inject(QcmHandlerService);
        service['toggleButtons'] = queryList;
        socketClientServiceSpy = TestBed.inject(SocketClientService) as jasmine.SpyObj<SocketClientService>;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should initialize toggleButtons correctly', () => {
        const mockMatButtonToggle1 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const mockMatButtonToggle2 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const queryList = new QueryList<MatButtonToggle>();
        queryList.reset([mockMatButtonToggle1, mockMatButtonToggle2]);

        service.updateToggleButtons(queryList);

        expect(service['toggleButtons']).toEqual(queryList);
    });

    it('should update toggleButtons correctly', () => {
        const mockMatButtonToggle1 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const mockMatButtonToggle2 = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        const queryList = new QueryList<MatButtonToggle>();
        queryList.reset([mockMatButtonToggle1, mockMatButtonToggle2]);

        service.updateToggleButtons(queryList);

        expect(service['toggleButtons']).toEqual(queryList);
    });

    it('should validate QCM answer and send data to socket client service', () => {
        const time = 60;

        const buttonsSelected = {
            // L'index des boutons sélectionnés est l'index des choix dans la question
            // eslint-disable-next-line @typescript-eslint/naming-convention
            0: true,
            // eslint-disable-next-line @typescript-eslint/naming-convention
            1: false,
        };

        // on doit spy sur la fonction privée pour tester le comportement
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        spyOn<any>(service, 'updateButtonsSelected').and.returnValue(buttonsSelected);

        const result = service.validateQcmAnswer(time, MOCK_QUESTION, buttonsSelected);

        expect(result).toEqual(buttonsSelected);
        expect(socketClientServiceSpy.send).toHaveBeenCalledWith(AnswerEvent.VALIDATE_QCM_ANSWER, {
            timeLeft: time,
            question: MOCK_QUESTION,
            buttonsSelected,
        });
    });

    it('should handle onTogglePressed correctly and send choice selected to socket client service', () => {
        const index = 0;
        const currentQuestionIndex = 1;

        const mockButton = jasmine.createSpyObj('MatButtonToggle', ['toggle']);
        mockButton.checked = true;
        spyOn(service['toggleButtons'], 'toArray').and.returnValue([mockButton]);
        const sendChoiceSelectedSpy = jasmine.createSpy('sendChoiceSelected');

        Object.defineProperty(service, 'sendChoiceSelected', { value: sendChoiceSelectedSpy });

        service.onTogglePressed(index, currentQuestionIndex);

        expect(sendChoiceSelectedSpy).toHaveBeenCalledWith(index, true, currentQuestionIndex);
    });

    it('should toggle button correctly and send choice selected to socket client service', () => {
        const index = 1;
        const currentQuestionIndex = 1;

        const sendChoiceSelectedSpy = jasmine.createSpy('sendChoiceSelected');

        Object.defineProperty(service, 'sendChoiceSelected', { value: sendChoiceSelectedSpy });

        service.toggleButton(index, currentQuestionIndex);

        expect(sendChoiceSelectedSpy).toHaveBeenCalledWith(index - 1, true, currentQuestionIndex);
    });

    it('should send choice selected to socket client service correctly', () => {
        const choiceIndex = 0;
        const isSelected = true;
        const currentQuestionIndex = 1;
        const choicesLength = 2;

        service.testing = false;

        service['sendChoiceSelected'](choiceIndex, isSelected, currentQuestionIndex);

        expect(socketClientServiceSpy.send).toHaveBeenCalledWith(AnswerEvent.CHOICE_SELECTED, {
            questionIndex: currentQuestionIndex,
            choiceIndex,
            isSelected,
            choicesLength,
        });
    });

    it('should update buttons selected correctly', () => {
        spyOn(service.buttonsChanged, 'next');
        service['toggleButtons'].forEach((button) => {
            button.checked = true;
        });
        const buttonsSelected = {
            // L'index des boutons sélectionnés est l'index des choix dans la question
            // eslint-disable-next-line @typescript-eslint/naming-convention
            0: true,
            // eslint-disable-next-line @typescript-eslint/naming-convention
            1: false,
        };

        const result = service['updateButtonsSelected'](buttonsSelected);

        expect(result).toEqual({
            // L'index des boutons sélectionnés est l'index des choix dans la question
            // eslint-disable-next-line @typescript-eslint/naming-convention
            0: true,
            // eslint-disable-next-line @typescript-eslint/naming-convention
            1: true,
        });

        expect(service.buttonsChanged.next).toHaveBeenCalled();
    });

    it('should update buttons selected correctly when buttons are empty', () => {
        const buttonsSelected = {};
        service['toggleButtons'] = new QueryList<MatButtonToggle>();

        const result = service['updateButtonsSelected'](buttonsSelected);

        expect(result).toEqual({});
    });
});
