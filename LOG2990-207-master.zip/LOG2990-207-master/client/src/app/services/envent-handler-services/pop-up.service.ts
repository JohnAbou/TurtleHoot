import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { PopUpComponent } from '@app/components/pop-up/pop-up.component';
import { PopUpButton, PopUpData } from '@common/popup';

@Injectable({
    providedIn: 'root',
})
export class PopUpService {
    popUpData: PopUpData = {
        title: '',
        text: '',
        buttons: [] as PopUpButton[],
    };

    constructor(
        private readonly dialog: MatDialog,
        private router: Router,
    ) {}

    openAbandon(action?: () => void) {
        this.popUpData.title = 'Attention!';
        this.popUpData.text = 'Voulez vous vraiment quitter la partie? Vous ne pourrez plus revenir.';
        this.popUpData.buttons = [{ text: 'Non' }, { text: 'Oui', action }];
        this.dialog.open(PopUpComponent, {
            width: '400px',
            data: this.popUpData,
        });
    }

    openGameEnded(title: string, text: string, route: string) {
        this.popUpData.title = title;
        this.popUpData.text = text;
        this.popUpData.buttons = [{ text: 'Fermer' }];
        const dialogRef = this.dialog.open(PopUpComponent, {
            width: '400px',
            data: this.popUpData,
        });

        dialogRef.afterClosed().subscribe(() => {
            this.router.navigate([route]);
        });
    }

    openCareful(text: string, action?: () => void) {
        this.popUpData.title = 'Attention!';
        this.popUpData.text = text;
        this.popUpData.buttons = [{ text: 'Non' }, { text: 'Oui', action }];
        this.dialog.open(PopUpComponent, {
            width: '400px',
            data: this.popUpData,
        });
    }
}
