import { TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { PopUpComponent } from '@app/components/pop-up/pop-up.component';
import { of } from 'rxjs';
import { PopUpService } from './pop-up.service';

describe('PopUpService', () => {
    let service: PopUpService;
    let dialogSpy: jasmine.SpyObj<MatDialog>;
    let routerSpy: jasmine.SpyObj<Router>;

    beforeEach(() => {
        const dialogSpyObj = jasmine.createSpyObj('MatDialog', ['open']);
        const routerSpyObj = jasmine.createSpyObj('Router', ['navigate']);

        TestBed.configureTestingModule({
            providers: [PopUpService, { provide: MatDialog, useValue: dialogSpyObj }, { provide: Router, useValue: routerSpyObj }],
        });
        service = TestBed.inject(PopUpService);
        dialogSpy = TestBed.inject(MatDialog) as jasmine.SpyObj<MatDialog>;
        routerSpy = TestBed.inject(Router) as jasmine.SpyObj<Router>;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should open abandon confirmation popup', () => {
        service.openAbandon();

        expect(dialogSpy.open).toHaveBeenCalledWith(PopUpComponent, {
            width: '400px',
            data: {
                title: 'Attention!',
                text: 'Voulez vous vraiment quitter la partie? Vous ne pourrez plus revenir.',
                buttons: [{ text: 'Non' }, { text: 'Oui', action: undefined }],
            },
        });
    });

    it('should open game ended popup and navigate when closed', () => {
        const title = 'Game Ended';
        const text = 'Game Over!';
        const route = '/home';

        const dialogRefSpyObj = jasmine.createSpyObj({ afterClosed: of(null) });
        dialogSpy.open.and.returnValue(dialogRefSpyObj);

        service.openGameEnded(title, text, route);

        expect(dialogSpy.open).toHaveBeenCalledWith(PopUpComponent, {
            width: '400px',
            data: {
                title,
                text,
                buttons: [{ text: 'Fermer' }],
            },
        });

        dialogRefSpyObj.afterClosed.and.callFake((callback: () => void) => {
            // Execute the callback directly
            callback();
            return of(null); // Return a new observable to mimic the behavior
        });

        // Expect that router.navigate was called with the provided route
        expect(routerSpy.navigate).toHaveBeenCalledWith([route]);
    });

    it('should open careful popup', () => {
        const text = 'Be careful!';
        const action = () => {
            return;
        };

        service.openCareful(text, action);

        expect(dialogSpy.open).toHaveBeenCalledWith(PopUpComponent, {
            width: '400px',
            data: {
                title: 'Attention!',
                text,
                buttons: [{ text: 'Non' }, { text: 'Oui', action }],
            },
        });
    });
});
