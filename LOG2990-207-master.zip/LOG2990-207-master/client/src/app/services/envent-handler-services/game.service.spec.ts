import { TestBed } from '@angular/core/testing';
import { SocketClientServiceMock, SocketTestHelper } from '@app/classes/socket-test-helper';
import { MOCK_PLAYERS } from '@common/constants';
import { AnswerEvent, ConnectionEvent, GameEvent } from '@common/event-name';
import { AnswerState, Player, PlayerState, PlayerWithStatus } from '@common/player';
import { Socket } from 'socket.io-client';
import { GameService } from './game.service';
import { SocketClientService } from './socket-client.service';

describe('GameService', () => {
    let service: GameService;
    let socketServiceMock: SocketClientServiceMock;
    let socketHelper: SocketTestHelper;

    beforeEach(() => {
        socketHelper = new SocketTestHelper();
        socketServiceMock = new SocketClientServiceMock();
        socketServiceMock.socket = socketHelper as unknown as Socket;

        TestBed.configureTestingModule({
            providers: [{ provide: SocketClientService, useValue: socketServiceMock }],
        });
        service = TestBed.inject(GameService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should add player to the list', () => {
        service['addPlayer'](MOCK_PLAYERS[0]);
        expect(service.getPlayers()).toContain(MOCK_PLAYERS[0]);
    });

    it('should remove player from players list if player exists', () => {
        service['addPlayer'](MOCK_PLAYERS[0]);
        const playerIdToRemove = '1';
        const initialPlayerCount = service.players.length;
        service[ConnectionEvent.KICK_PLAYER](playerIdToRemove);
        expect(service.players.length).toBe(initialPlayerCount - 1);
        expect(service.players.some((player) => player.id === playerIdToRemove)).toBe(false);
    });

    it('should set and get players correctly', () => {
        service['setPlayers'](MOCK_PLAYERS);
        expect(service.getPlayers()).toEqual(MOCK_PLAYERS);
    });

    it('should emit playersChanged event', () => {
        spyOn(service.playersChangedEvent, 'next');
        service['setPlayers'](MOCK_PLAYERS);
        service.playersChanged();
        expect(service.playersChangedEvent.next).toHaveBeenCalledWith(MOCK_PLAYERS);
    });

    it('should handle roomPlayers event correctly', () => {
        service.configureBaseSocketFeatures();
        socketHelper.peerSideEmit(GameEvent.GET_ROOM_PLAYERS, MOCK_PLAYERS);
        expect(service.players).toEqual(MOCK_PLAYERS);
    });

    it('should handle otherPlayerJoined event correctly', () => {
        service.configureBaseSocketFeatures();
        const newPlayer = { id: '3', username: 'Player 3', role: PlayerState.Player, points: 0 };
        service.players = JSON.parse(JSON.stringify(MOCK_PLAYERS));
        socketHelper.peerSideEmit(ConnectionEvent.OTHER_PLAYER_JOINED, newPlayer);

        expect(service.players.length).toEqual(3);
    });

    it('should handle playerLeft event correctly', () => {
        const expectedPlayers: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                nBonus: 0,
                role: PlayerState.Player,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                id: '2',
                username: 'Player 2',
                nBonus: 0,
                role: PlayerState.Player,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: false,
                isMuted: false,
            },
        ];
        service.players = JSON.parse(JSON.stringify(MOCK_PLAYERS));
        service.configureBaseSocketFeatures();

        socketHelper.peerSideEmit(ConnectionEvent.PLAYER_LEFT, '2');
        expect(service.players).toEqual(expectedPlayers);
    });

    it('should handle playerKicked event correctly', () => {
        const expectedPlayers: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                nBonus: 0,
                role: PlayerState.Player,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
        ];
        service.players = JSON.parse(JSON.stringify(MOCK_PLAYERS));
        service.configureBaseSocketFeatures();

        socketHelper.peerSideEmit(ConnectionEvent.PLAYER_KICKED, '2');
        expect(service.players).toEqual(expectedPlayers);
    });

    it('should handle newPlayerPoints event correctly', () => {
        const updatedPlayers: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                nBonus: 0,
                role: PlayerState.Player,
                points: 10,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                id: '2',
                username: 'Player 2',
                nBonus: 0,
                role: PlayerState.Player,
                points: 0,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
        ];
        service.players = JSON.parse(JSON.stringify(MOCK_PLAYERS));
        service.configureBaseSocketFeatures();
        socketHelper.peerSideEmit(GameEvent.NEW_PLAYER_POINTS, updatedPlayers);
        expect(service.players).toEqual(updatedPlayers);
    });

    it('should unsubscribe from socket features correctly', () => {
        const offSpy = spyOn(socketServiceMock, 'off').and.callThrough();

        service.unsubscribeFromSocketFeatures();

        expect(offSpy.calls.allArgs()).toEqual([
            [GameEvent.GET_ROOM_PLAYERS],
            [ConnectionEvent.OTHER_PLAYER_JOINED],
            [ConnectionEvent.PLAYER_LEFT],
            [ConnectionEvent.PLAYER_KICKED],
            [GameEvent.NEW_PLAYER_POINTS],
            [AnswerEvent.PLAYER_ANSWER_SATE_CHANGED],
        ]);
    });

    it('should return sorted players excluding organizer', () => {
        const players: Player[] = [
            { id: '1', username: 'Player 1', role: PlayerState.Player, nBonus: 0, points: 20, answerState: AnswerState.default, isMuted: false },
            { id: '2', username: 'Player 2', role: PlayerState.Organizer, nBonus: 0, points: 30, answerState: AnswerState.default, isMuted: false },
            { id: '3', username: 'Player 3', role: PlayerState.Player, nBonus: 0, points: 10, answerState: AnswerState.default, isMuted: false },
            { id: '4', username: 'b', role: PlayerState.Player, nBonus: 0, points: 5, answerState: AnswerState.default, isMuted: false },
            { id: '5', username: 'a', role: PlayerState.Player, nBonus: 0, points: 5, answerState: AnswerState.default, isMuted: false },
        ];
        service['setPlayers'](players);

        const sortedPlayers = service.getSortedPlayers();

        const expectedLength = 4;
        expect(sortedPlayers.length).toBe(expectedLength);
        expect(sortedPlayers[0].username).toBe('Player 1');
        expect(sortedPlayers[1].username).toBe('Player 3');
        expect(sortedPlayers[2].username).toBe('a');
    });

    it('should filter players correctly', () => {
        const players: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                role: PlayerState.Player,
                nBonus: 0,
                points: 20,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                id: '2',
                username: 'Player 2',
                role: PlayerState.Organizer,
                nBonus: 0,
                points: 30,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                id: '3',
                username: 'Player 3',
                role: PlayerState.Player,
                nBonus: 0,
                points: 10,
                answerState: AnswerState.default,
                isPlaying: false,
                isMuted: false,
            },
        ];

        service.players = players;
        const newPlayers = service.filterPlayers(players);

        expect(newPlayers.length).toBe(2);
    });

    it('should update players correctly on playerAnswerStateChanged', () => {
        const updatedPlayers: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                nBonus: 0,
                role: PlayerState.Player,
                points: 10,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
            {
                id: '2',
                username: 'Player 2',
                nBonus: 0,
                role: PlayerState.Player,
                points: 0,
                answerState: AnswerState.hasAnswered,
                isPlaying: true,
                isMuted: false,
            },
        ];
        service.players = JSON.parse(JSON.stringify(MOCK_PLAYERS));
        service.configureBaseSocketFeatures();
        socketHelper.peerSideEmit(AnswerEvent.PLAYER_ANSWER_SATE_CHANGED, updatedPlayers);
        expect(service.players).toEqual(updatedPlayers);
    });

    it('should change organizer to player correctly', () => {
        const players: PlayerWithStatus[] = [
            {
                id: '1',
                username: 'Player 1',
                role: PlayerState.Organizer,
                nBonus: 0,
                points: 30,
                answerState: AnswerState.default,
                isPlaying: true,
                isMuted: false,
            },
        ];

        service.players = players;
        service.changeToPlayer();

        expect(service.players[0].role).toBe(PlayerState.Player);
    });
});
