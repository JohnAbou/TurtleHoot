import { TestBed } from '@angular/core/testing';
import { take } from 'rxjs/operators';
import { KeyboardHandlerService } from './keyboard-handler.service';

describe('KeyboardHandlerService', () => {
    let service: KeyboardHandlerService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [KeyboardHandlerService],
        });
        service = TestBed.inject(KeyboardHandlerService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should emit enterKeyEvent on "Enter" key press', () => {
        let enterEventEmitted = false;
        service.enterKeyEvent.pipe(take(1)).subscribe(() => {
            enterEventEmitted = true;
        });

        const mockEvent = new KeyboardEvent('keydown', { key: 'Enter' });
        service.onKeyboardEvent(mockEvent);

        expect(enterEventEmitted).toBeTruthy();
    });

    it('should emit toggleButtonEvent with correct value on numeric key press', () => {
        let toggleButtonValue: number | undefined;
        service.toggleButtonEvent.pipe(take(1)).subscribe((value) => {
            toggleButtonValue = value;
        });

        const numericKey = '2';
        const mockEvent = new KeyboardEvent('keydown', { key: numericKey });
        service.onKeyboardEvent(mockEvent);

        expect(toggleButtonValue).toEqual(parseInt(numericKey, 10));
    });

    it('should not emit any events on other key press', () => {
        let enterEventEmitted = false;
        let toggleButtonValue: number | undefined;

        service.enterKeyEvent.subscribe(() => (enterEventEmitted = true));
        service.toggleButtonEvent.subscribe((value) => (toggleButtonValue = value));

        const mockEvent = new KeyboardEvent('keydown', { key: 'ArrowDown' });
        service.onKeyboardEvent(mockEvent);

        expect(enterEventEmitted).toBeFalsy();
        expect(toggleButtonValue).toBeUndefined();
    });
});
