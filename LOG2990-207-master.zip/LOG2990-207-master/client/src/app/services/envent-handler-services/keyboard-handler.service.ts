import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class KeyboardHandlerService {
    enterKeyEvent = new Subject<void>();
    toggleButtonEvent = new Subject<number>();

    onKeyboardEvent(event: KeyboardEvent) {
        const pressedKey = event.key;

        if (pressedKey === 'Enter') {
            this.enterKeyEvent.next();
        } else if (['1', '2', '3', '4'].includes(pressedKey)) {
            this.toggleButtonEvent.next(parseInt(pressedKey, 10));
        }
    }
}
