import { Injectable } from '@angular/core';
import { AnswerEvent } from '@common/event-name';
import { Question } from '@common/quiz';
import { SocketClientService } from './socket-client.service';

@Injectable({
    providedIn: 'root',
})
export class QrlHandlerService {
    constructor(private socket: SocketClientService) {}

    validateQrlAnswer(time: number, currentQuestion: Question, answer: string) {
        this.socket.send(AnswerEvent.VALIDATE_QRL_ANSWER, {
            timeLeft: time,
            question: currentQuestion,
            answer,
        });
    }
}
