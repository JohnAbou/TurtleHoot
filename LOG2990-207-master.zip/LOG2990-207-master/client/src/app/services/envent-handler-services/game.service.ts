import { Injectable } from '@angular/core';
import { INVALID_INDEX } from '@common/constants';
import { AnswerEvent, ConnectionEvent, GameEvent } from '@common/event-name';
import { AnswerState, Player, PlayerState, PlayerWithStatus } from '@common/player';
import { SortOption } from '@common/player-list-sort';
import { Quiz } from '@common/quiz';
import { Subject } from 'rxjs';
import { SocketClientService } from './socket-client.service';

@Injectable({
    providedIn: 'root',
})
export class GameService {
    gameQuiz: Quiz;
    playersChangedEvent = new Subject<PlayerWithStatus[]>();
    players: PlayerWithStatus[] = [];
    currentSortOption: SortOption = SortOption.Username;
    sortingDirection: 'asc' | 'desc' = 'asc';

    constructor(private socketClientService: SocketClientService) {}

    filterPlayers(players: PlayerWithStatus[]) {
        return players.filter((player) => player.isPlaying);
    }

    getPlayers() {
        return this.players;
    }

    getSortedPlayers() {
        const sortedPlayers = this.players.filter((player) => player.role !== PlayerState.Organizer);
        return sortedPlayers.sort((a, b) => {
            if (b.points === a.points) {
                return a.username.localeCompare(b.username);
            }
            return b.points - a.points;
        });
    }

    playersChanged() {
        this.playersChangedEvent.next(this.players);
    }

    configureBaseSocketFeatures() {
        this.configureRoomPlayers();
        this.configureOtherPlayerJoined();
        this.configurePlayerLeft();
        this.configurePlayerKicked();
        this.configureNewPlayerPoints();
        this.configurePlayerAnswerStateChanged();
    }
    changeToPlayer() {
        const organizer = this.players.find((player) => player.role === PlayerState.Organizer);
        if (organizer) {
            organizer.role = PlayerState.Player;
        }
    }

    unsubscribeFromSocketFeatures() {
        this.socketClientService.off(GameEvent.GET_ROOM_PLAYERS);
        this.socketClientService.off(ConnectionEvent.OTHER_PLAYER_JOINED);
        this.socketClientService.off(ConnectionEvent.PLAYER_LEFT);
        this.socketClientService.off(ConnectionEvent.PLAYER_KICKED);
        this.socketClientService.off(GameEvent.NEW_PLAYER_POINTS);
        this.socketClientService.off(AnswerEvent.PLAYER_ANSWER_SATE_CHANGED);
    }

    private configureRoomPlayers() {
        this.socketClientService.on<Player[]>(GameEvent.GET_ROOM_PLAYERS, (players: Player[]) => {
            this.setPlayers(players);
            this.playersChanged();
        });
    }
    private configureOtherPlayerJoined() {
        this.socketClientService.on<Player>(ConnectionEvent.OTHER_PLAYER_JOINED, (player: Player) => {
            this.addPlayer(player);
            this.playersChanged();
        });
    }
    private configurePlayerLeft() {
        this.socketClientService.on<string>(ConnectionEvent.PLAYER_LEFT, (playerId: string) => {
            this.removePlayer(playerId);
            this.playersChanged();
        });
    }
    private configurePlayerKicked() {
        this.socketClientService.on<string>(ConnectionEvent.PLAYER_KICKED, (playerId: string) => {
            this.kickPlayer(playerId);
            this.playersChanged();
        });
    }
    private configureNewPlayerPoints() {
        this.socketClientService.on<Player[]>(GameEvent.NEW_PLAYER_POINTS, (newPlayers: Player[]) => {
            this.updatePlayers(newPlayers);
            this.playersChanged();
        });
    }
    private configurePlayerAnswerStateChanged() {
        this.socketClientService.on<Player[]>(AnswerEvent.PLAYER_ANSWER_SATE_CHANGED, (players: Player[]) => {
            this.updatePlayers(players);
            this.playersChanged();
        });
    }

    private setPlayers(players: Player[]) {
        this.players = players.map((player) => ({ ...player, isPlaying: true }));
    }

    private addPlayer(player: Player) {
        this.players.push({ ...player, isPlaying: true });
    }

    private removePlayer(id: string) {
        const playerIndex = this.players.findIndex((p) => p.id === id);
        if (playerIndex !== INVALID_INDEX) {
            this.players[playerIndex].isPlaying = false;
        }
    }

    private kickPlayer(id: string) {
        const playerIndex = this.players.findIndex((p) => p.id === id);
        if (playerIndex !== INVALID_INDEX) {
            this.players.splice(playerIndex, 1);
        }
    }

    private updatePlayers(updatedPlayers: Player[]) {
        this.players.forEach((player) => {
            const foundPlayer = updatedPlayers.find((p) => p.id === player.id && p.role === PlayerState.Player);
            if (foundPlayer) {
                player.nBonus = foundPlayer.nBonus;
                player.points = foundPlayer.points;
                if (foundPlayer.answerState !== AnswerState.hasForceAnswered) {
                    player.answerState = foundPlayer.answerState;
                }
            }
        });
    }
}
