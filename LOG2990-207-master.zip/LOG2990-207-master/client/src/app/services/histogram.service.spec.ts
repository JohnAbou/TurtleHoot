import { TestBed } from '@angular/core/testing';
import { Choice } from '@common/quiz';
import { HistogramService } from './histogram.service';

describe('HistogramService', () => {
    let service: HistogramService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(HistogramService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should generate chart data', () => {
        const choices: Choice[] = [
            { text: 'Choice 1', isCorrect: true },
            { text: 'Choice 2', isCorrect: false },
        ];
        const roomAnswers: number[] = [2, 3];
        const chartData = service.generateChartData(choices, roomAnswers);
        expect(chartData.data.length).toBe(choices.length);
        expect(chartData.colors.length).toBe(choices.length);
        expect(chartData.data[0].name).toBe('Choice 1');
        expect(chartData.data[0].value).toBe(2);
        expect(chartData.colors[0]).toBe('green');
    });

    it('should generate chart data with default values when roomAnswers is not provided', () => {
        const choices: Choice[] = [
            { text: 'Choice 1', isCorrect: true },
            { text: 'Choice 2', isCorrect: false },
        ];
        const chartData = service.generateChartData(choices);
        expect(chartData.data.length).toBe(choices.length);
        expect(chartData.colors.length).toBe(choices.length);
        expect(chartData.data[0].name).toBe('Choice 1');
        expect(chartData.data[0].value).toBe(0);
        expect(chartData.colors[0]).toBe('green');
    });
});
