import { Injectable } from '@angular/core';
import { Choice } from '@common/quiz';
import { SingleItem } from '@common/single';

@Injectable({
    providedIn: 'root',
})
export class HistogramService {
    generateChartData(choices: Choice[], roomAnswers?: number[]): { data: SingleItem[]; colors: string[] } {
        const data: SingleItem[] = [];
        const colors: string[] = [];
        if (choices && choices.length > 0) {
            choices.forEach((choice, index) => {
                const value = roomAnswers && roomAnswers[index] ? roomAnswers[index] : 0;
                data.push({ name: choice.text, value });
                colors.push(this.getColor(choice.isCorrect));
            });
        }
        return { data, colors };
    }

    private getColor(isCorrect: boolean): string {
        return isCorrect ? 'green' : 'red';
    }
}
