import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NUMBER_OF_QUESTIONS_RANDOM, RANDOM_QUIZ_DURATION } from '@common/constants';
import { Question, Quiz } from '@common/quiz';
import { nanoid } from 'nanoid';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root',
})
export class RandomModeService {
    quizRandom: Quiz;
    private readonly baseUrl: string = environment.serverUrl;
    constructor(private readonly http: HttpClient) {}

    getQuestionsQcm(): Observable<Question[]> {
        return this.http.get<Question[]>(this.baseUrl + '/questionbank');
    }

    hasEnoughQuestionsQcm(questionsQcm: Question[]): boolean {
        return questionsQcm.length >= NUMBER_OF_QUESTIONS_RANDOM;
    }

    getQuizRandom(questionsQcm: Question[]): Quiz {
        const idSize = 6;
        this.quizRandom = {
            id: nanoid(idSize) + '-random',
            title: 'mode aléatoire',
            duration: RANDOM_QUIZ_DURATION,
            description: 'Voici un quiz dont les questions ont été choisies aléatoirement',
            lastModification: new Date().toDateString(),
            questions: [],
        };
        this.quizRandom.questions = this.getQuestionsRandom(questionsQcm);
        return this.quizRandom;
    }

    getQuestionsRandom(questionsQcm: Question[]): Question[] {
        const questionsRandom: Question[] = [];
        for (let i = 0; i < NUMBER_OF_QUESTIONS_RANDOM; i++) {
            const randomIndex = this.getRandomIndex(questionsQcm);
            questionsRandom.push(questionsQcm[randomIndex]);
            questionsQcm.splice(randomIndex, 1);
        }
        return questionsRandom;
    }

    getRandomIndex(questionsQcm: Question[]): number {
        return Math.floor(Math.random() * questionsQcm.length);
    }

    deleteTempQuiz(id: string): Observable<HttpResponse<string>> {
        return this.http.delete(`${this.baseUrl}/quizzes/${id}`, { observe: 'response', responseType: 'text' });
    }
}
