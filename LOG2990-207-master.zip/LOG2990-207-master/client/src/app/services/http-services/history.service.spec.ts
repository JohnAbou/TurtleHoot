import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { HistoryInformation } from '@common/history';
import { Quiz } from '@common/quiz';
import { environment } from 'src/environments/environment';
import { HistoryService } from './history.service';

describe('HistoryService', () => {
    let service: HistoryService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [HistoryService],
        });
        service = TestBed.inject(HistoryService);
        httpMock = TestBed.inject(HttpTestingController);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should add quiz title', () => {
        const quizTitle = 'Sample Quiz';
        const quiz: Quiz = { id: '1', title: quizTitle, description: '', duration: 0, lastModification: '', questions: [] };
        service.addQuizTitle(quiz);
        expect(service.historyInformation.quizTitle).toEqual(quizTitle);
    });

    it('should add player count', () => {
        const playerCount = 5;
        service.addPlayerCount(playerCount);
        expect(service.historyInformation.playerCount).toEqual(playerCount);
    });

    it('should add start timestamp', () => {
        service.addStartTimestamp();
        const startTime = service.historyInformation.startTime;
        const expectedTime = service['getCurrentFormattedDate']();
        expect(startTime).toEqual(expectedTime);
    });

    it('should add end timestamp', () => {
        service.addEndTimestamp();
        const endTime = service.historyInformation.endTime;
        const expectedTime = service['getCurrentFormattedDate']();
        expect(endTime).toEqual(expectedTime);
    });

    it('should add best score', () => {
        const bestScore = 100;
        service.addBestScore(bestScore);
        expect(service.historyInformation.bestScore).toEqual(bestScore);
    });

    it('should add to history', () => {
        const mockResponse: HistoryInformation = {
            quizTitle: 'Sample Quiz',
            playerCount: 5,
            bestScore: 100,
            startTime: service['getCurrentFormattedDate'](),
            endTime: service['getCurrentFormattedDate'](),
        };
        service.addToHistory();
        const req = httpMock.expectOne(`${environment.serverUrl}/history`);
        expect(req.request.method).toBe('POST');
        req.flush(mockResponse);
    });

    it('should add information to history', () => {
        const mockResponse: HistoryInformation = {
            quizTitle: 'Sample Quiz',
            playerCount: 5,
            bestScore: 100,
            startTime: service['getCurrentFormattedDate'](),
            endTime: service['getCurrentFormattedDate'](),
        };
        service.addInfoToHistory(mockResponse);
        const req = httpMock.expectOne(`${environment.serverUrl}/history`);
        expect(req.request.method).toBe('POST');
        req.flush(mockResponse);
    });

    it('should delete all history', () => {
        const mockResponse = { success: true };
        service.deleteAllHistory();
        const req = httpMock.expectOne(`${environment.serverUrl}/history`);
        expect(req.request.method).toBe('DELETE');
        req.flush(mockResponse);
    });

    it('should get all history', async () => {
        const mockResponse: unknown[] = [
            { quizTitle: 'Quiz 1', playerCount: 3, bestScore: 80, startTime: '2024-03-28 10:00:00', endTime: '2024-03-28 11:00:00' },
            { quizTitle: 'Quiz 2', playerCount: 2, bestScore: 90, startTime: '2024-03-28 12:00:00', endTime: '2024-03-28 13:00:00' },
        ];

        spyOn(window, 'fetch').and.returnValue(
            Promise.resolve({
                json: async () => Promise.resolve(mockResponse),
            } as Response),
        );

        const history = await service.getAllHistory();
        expect(history).toEqual(mockResponse);

        expect(window.fetch).toHaveBeenCalledWith(`${environment.serverUrl}/history`);
    });

    it('should remove duplicates from history', async () => {
        const mockResponse: HistoryInformation[] = [
            { quizTitle: 'Quiz 1', playerCount: 3, bestScore: 80, startTime: '2024-03-28 10:00:00', endTime: '2024-03-28 11:00:00' },
            { quizTitle: 'Quiz 1', playerCount: 3, bestScore: 80, startTime: '2024-03-28 10:00:00', endTime: '2024-03-28 11:00:00' },
            { quizTitle: 'Quiz 2', playerCount: 2, bestScore: 90, startTime: '2024-03-28 12:00:00', endTime: '2024-03-28 13:00:00' },
        ];
        spyOn(service, 'getAllHistory').and.returnValue(Promise.resolve(mockResponse));
        spyOn(service, 'addInfoToHistory');
        await service.removeDuplicates();
        expect(service.getAllHistory).toHaveBeenCalled();
        expect(service.addInfoToHistory).toHaveBeenCalled();
    });
});
