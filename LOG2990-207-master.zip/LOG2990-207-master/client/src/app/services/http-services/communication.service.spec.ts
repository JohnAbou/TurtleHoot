import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { Message } from '@common/message';
import { Observable, Observer, of } from 'rxjs';
import { CommunicationService } from './communication.service';

const exampleMessage: Message = { title: 'Error', body: 'A problem has occured' };

describe('CommunicationService', () => {
    let service: CommunicationService;
    let httpClientSpy: jasmine.SpyObj<HttpClient>;

    beforeEach(() => {
        const spy = jasmine.createSpyObj('HttpClient', ['post', 'get']);

        TestBed.configureTestingModule({
            providers: [{ provide: HttpClient, useValue: spy }],
        });
        service = TestBed.inject(CommunicationService);
        httpClientSpy = TestBed.inject(HttpClient) as jasmine.SpyObj<HttpClient>;
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should post credentials', () => {
        const response = new HttpResponse<string>({ body: 'OK', status: 200 });
        httpClientSpy.post.and.returnValue(of(response));

        service.credentialPost('credential').subscribe((res) => {
            expect(res).toEqual(response);
        });
        expect(httpClientSpy.post.calls.count()).toBe(1);
    });

    it('should handle error when posting credentials', () => {
        const errorResponse = new HttpErrorResponse({ error: 'error', status: 404 });
        httpClientSpy.post.and.returnValue(
            new Observable((observer: Observer<HttpResponse<string>>) => {
                observer.error(errorResponse);
            }),
        );

        service.credentialPost('credential').subscribe({
            error: (error) => {
                expect(error).toEqual(errorResponse);
            },
        });

        expect(httpClientSpy.post.calls.count()).toBe(1);
    });

    it('should get example message', () => {
        httpClientSpy.get.and.returnValue(of(exampleMessage));

        service.basicGet().subscribe((res) => {
            expect(res).toEqual(exampleMessage);
        });
        expect(httpClientSpy.get.calls.count()).toBe(1);
    });

    it('should handle error when getting example message', () => {
        const errorResponse = new HttpErrorResponse({ error: 'error', status: 404 });
        httpClientSpy.get.and.returnValue(
            new Observable((observer) => {
                observer.error(errorResponse);
            }),
        );
        service.basicGet().subscribe({
            error: (err) => {
                expect(err).toEqual(errorResponse);
            },
        });
        expect(httpClientSpy.get.calls.count()).toBe(1);
    });

    it('should post example message', () => {
        const response = new HttpResponse<string>({ body: 'OK', status: 200 });
        httpClientSpy.post.and.returnValue(of(response));

        service.basicPost(exampleMessage).subscribe((res) => {
            expect(res).toEqual(response);
        });
        expect(httpClientSpy.post.calls.count()).toBe(1);
    });

    it('should handle error when posting example message', () => {
        const errorResponse = new HttpErrorResponse({ error: 'error', status: 404 });
        httpClientSpy.post.and.returnValue(
            new Observable((observer) => {
                observer.error(errorResponse);
            }),
        );

        service.basicPost(exampleMessage).subscribe({
            error: (err) => {
                expect(err).toEqual(errorResponse);
            },
        });
        expect(httpClientSpy.post.calls.count()).toBe(1);
    });
});
