import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DATE_SLICE_VALUE } from '@common/constants';
import { HistoryInformation } from '@common/history';
import { Quiz } from '@common/quiz';
import { environment } from 'src/environments/environment';
@Injectable({
    providedIn: 'root',
})
export class HistoryService {
    historyInformation: HistoryInformation = {
        quizTitle: '',
        playerCount: 0,
        bestScore: 0,
        startTime: '',
        endTime: '',
    };

    private readonly baseUrl: string = environment.serverUrl;

    constructor(public http: HttpClient) {}

    addQuizTitle(quiz: Quiz) {
        this.historyInformation.quizTitle = quiz.title;
    }

    addPlayerCount(playerCount: number) {
        this.historyInformation.playerCount = playerCount;
    }

    addStartTimestamp() {
        this.historyInformation.startTime = this.getCurrentFormattedDate();
    }

    addEndTimestamp() {
        this.historyInformation.endTime = this.getCurrentFormattedDate();
    }

    addBestScore(bestScore: number) {
        this.historyInformation.bestScore = bestScore;
    }

    addToHistory() {
        this.http.post<HistoryInformation>(`${environment.serverUrl}/history`, this.historyInformation).subscribe();
    }

    addInfoToHistory(historyInfo: HistoryInformation) {
        this.http.post<HistoryInformation>(`${environment.serverUrl}/history`, historyInfo).subscribe();
    }

    async getAllHistory() {
        const response = await fetch(`${this.baseUrl}/history`);
        return await response.json();
    }

    async removeDuplicates() {
        const history = await this.getAllHistory();
        const uniqueHistory: HistoryInformation[] = [];
        this.deleteAllHistory();

        const seen: { [key: string]: boolean } = {};

        history.forEach((item: HistoryInformation) => {
            const key = `${item.quizTitle}_${item.playerCount}_${item.bestScore}_${item.startTime}`;
            if (!seen[key]) {
                seen[key] = true;
                uniqueHistory.push(item);
                this.addInfoToHistory(item);
            }
        });
        return uniqueHistory;
    }

    deleteAllHistory() {
        this.http.delete<HistoryInformation>(`${environment.serverUrl}/history`).subscribe();
    }

    private getCurrentFormattedDate() {
        const date = new Date();
        const year = date.getFullYear();
        const month = ('0' + (date.getMonth() + 1)).slice(DATE_SLICE_VALUE);
        const day = ('0' + date.getDate()).slice(DATE_SLICE_VALUE);
        const hours = ('0' + date.getHours()).slice(DATE_SLICE_VALUE);
        const minutes = ('0' + date.getMinutes()).slice(DATE_SLICE_VALUE);
        const seconds = ('0' + date.getSeconds()).slice(DATE_SLICE_VALUE);
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }
}
