import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ID_GENERATION_PARAMS } from '@common/constants';
import { Quiz, QuizVisibility } from '@common/quiz';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root',
})
export class QuizService {
    readonly baseUrl: string = environment.serverUrl;

    constructor(private readonly http: HttpClient) {}
    generateId() {
        return Math.random().toString(ID_GENERATION_PARAMS.base).substring(ID_GENERATION_PARAMS.startIndex, ID_GENERATION_PARAMS.endIndex);
    }

    addQuiz(newQuiz: Quiz): Observable<Quiz> {
        return this.http.post<Quiz>(`${environment.serverUrl}/quizzes`, newQuiz);
    }

    uploadQuizFromJson(file: Quiz | null, isNewQuiz: boolean): Observable<HttpResponse<string>> {
        const payload = {
            isNew: isNewQuiz,
            quiz: file,
        };
        return this.http.post(`${this.baseUrl}/admin/save-quiz`, payload, { observe: 'response', responseType: 'text' });
    }

    getQuiz(id: string): Observable<Quiz> {
        return this.http.get<Quiz>(`${this.baseUrl}/quizzes/${id}`).pipe(catchError(this.handleError<Quiz>('getQuiz')));
    }

    getAllQuiz() {
        return this.http.get<Quiz[]>(`${environment.serverUrl}/quizzes`);
    }

    deleteQuiz(quizId: string) {
        return this.http.delete(`${environment.serverUrl}/quizzes/${quizId}`);
    }

    getQuizVisibility(quizId: string) {
        return this.http.get<boolean>(`${environment.serverUrl}/visibility/${quizId}`);
    }

    changeVisibility(quizId: string, newVisibility: boolean) {
        return this.http.put<QuizVisibility>(`${environment.serverUrl}/visibility/${quizId}`, { visible: newVisibility });
    }

    private handleError<T>(request: string, result?: T): (error: Error) => Observable<T> {
        return () => of(result as T);
    }
}
