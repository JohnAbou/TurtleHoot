import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Question } from '@common/quiz';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root',
})
export class QuestionService {
    private readonly url = `${environment.serverUrl}/questionbank`;
    constructor(private readonly http: HttpClient) {}
    getAllQuestions() {
        return this.http.get<Question[]>(`${this.url}`);
    }

    modifyQuestion(question: Question) {
        return this.http.put<Question>(`${this.url}/${question.id}`, question);
    }

    addQuestion(newQuestion: Question): Observable<Question> {
        return this.http.post<Question>(this.url, newQuestion);
    }

    deleteQuestion(questionId: string): Observable<Question> {
        return this.http.delete<Question>(`${this.url}/${questionId}`);
    }
}
