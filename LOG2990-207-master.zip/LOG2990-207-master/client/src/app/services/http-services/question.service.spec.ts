import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Question, QuestionType } from '@common/quiz';
import { QuestionService } from './question.service';

describe('QuestionService', () => {
    let service: QuestionService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [QuestionService],
        });
        service = TestBed.inject(QuestionService);
        httpMock = TestBed.inject(HttpTestingController);
    });

    afterEach(() => {
        httpMock.verify();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should get all questions', () => {
        const mockQuestions: Question[] = [
            { id: '1', text: 'Question 1', type: QuestionType.QCM, points: 10, choices: [], lastModification: '' },
            { id: '2', text: 'Question 2', type: QuestionType.QCM, points: 10, choices: [], lastModification: '' },
        ];

        service.getAllQuestions().subscribe((questions) => {
            expect(questions.length).toBe(2);
            expect(questions).toEqual(mockQuestions);
        });

        const req = httpMock.expectOne(`${service['url']}`);
        expect(req.request.method).toBe('GET');
        req.flush(mockQuestions);
    });

    it('should modify a question', () => {
        const questionId = '1';
        const modifiedQuestion: Question = {
            id: questionId,
            text: 'Modified Question',
            type: QuestionType.QCM,
            points: 20,
            choices: [],
            lastModification: '',
        };

        service.modifyQuestion(modifiedQuestion).subscribe((question) => {
            expect(question).toEqual(modifiedQuestion);
        });

        const req = httpMock.expectOne(`${service['url']}/${questionId}`);
        expect(req.request.method).toBe('PUT');
        req.flush(modifiedQuestion);
    });

    it('should add a new question', () => {
        const newQuestion: Question = {
            id: '3',
            text: 'New Question',
            type: QuestionType.QCM,
            points: 10,
            choices: [],
            lastModification: '',
        };

        service.addQuestion(newQuestion).subscribe((question) => {
            expect(question).toEqual(newQuestion);
        });

        const req = httpMock.expectOne(`${service['url']}`);
        expect(req.request.method).toBe('POST');
        req.flush(newQuestion);
    });

    it('should delete a question', () => {
        const questionId = '1';

        service.deleteQuestion(questionId).subscribe((question) => {
            expect(question).toBeNull();
        });

        const req = httpMock.expectOne(`${service['url']}/${questionId}`);
        expect(req.request.method).toBe('DELETE');
        req.flush(null);
    });
});
