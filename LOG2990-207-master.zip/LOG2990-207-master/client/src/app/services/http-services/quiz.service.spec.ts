import { HttpResponse, HttpStatusCode } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { MOCK_QUIZ, MOCK_QUIZZES } from '@common/constants';
import { Quiz, QuizVisibility } from '@common/quiz';
import { environment } from 'src/environments/environment';
import { QuizService } from './quiz.service';

describe('QuizService', () => {
    let service: QuizService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [QuizService],
        });

        service = TestBed.inject(QuizService);
        httpMock = TestBed.inject(HttpTestingController);
    });

    afterEach(() => {
        httpMock.verify();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should add a quiz', () => {
        service.addQuiz(MOCK_QUIZ).subscribe((quiz: Quiz) => {
            expect(quiz).toEqual(MOCK_QUIZ);
        });

        const req = httpMock.expectOne(`${environment.serverUrl}/quizzes`);
        expect(req.request.method).toBe('POST');
        req.flush(MOCK_QUIZ);
    });

    it('should upload a quiz', () => {
        const file: Quiz = MOCK_QUIZ;
        const isNewQuiz = true;

        service.uploadQuizFromJson(file, isNewQuiz).subscribe((response: HttpResponse<string>) => {
            expect(response.status).toBe(HttpStatusCode.Ok);
        });

        const req = httpMock.expectOne(`${service.baseUrl}/admin/save-quiz`);
        expect(req.request.method).toBe('POST');
        req.flush('', { status: HttpStatusCode.Ok, statusText: 'OK' });
    });

    it('should get a quiz', () => {
        const id = 'testId';
        const quiz: Quiz = MOCK_QUIZ;

        service.getQuiz(id).subscribe((response: Quiz) => {
            expect(response).toEqual(quiz);
        });

        const req = httpMock.expectOne(`${service.baseUrl}/quizzes/${id}`);
        expect(req.request.method).toBe('GET');
        req.flush(quiz);
    });

    it('should get all quizzes', () => {
        const quizzes: Quiz[] = MOCK_QUIZZES;

        service.getAllQuiz().subscribe((response: Quiz[]) => {
            expect(response).toEqual(quizzes);
        });

        const req = httpMock.expectOne(`${service.baseUrl}/quizzes`);
        expect(req.request.method).toBe('GET');
        req.flush(quizzes);
    });

    it('should delete a quiz', () => {
        const id = 'testId';

        service.deleteQuiz(id).subscribe();

        const req = httpMock.expectOne(`${service.baseUrl}/quizzes/${id}`);
        expect(req.request.method).toBe('DELETE');
        req.flush('', { status: HttpStatusCode.Ok, statusText: 'OK' });
    });

    it('should get quiz visibility', () => {
        const id = 'testId';
        const visibility = true;

        service.getQuizVisibility(id).subscribe((response: boolean) => {
            expect(response).toEqual(visibility);
        });

        const req = httpMock.expectOne(`${service.baseUrl}/visibility/${id}`);
        expect(req.request.method).toBe('GET');
        req.flush(visibility);
    });

    it('should change quiz visibility', () => {
        const id = 'testId';
        const newVisibility = true;
        const visibility: QuizVisibility = {
            quizId: id,
            visible: false,
        };

        service.changeVisibility(id, newVisibility).subscribe((response: QuizVisibility) => {
            expect(response).toEqual(visibility);
        });

        const req = httpMock.expectOne(`${service.baseUrl}/visibility/${id}`);
        expect(req.request.method).toBe('PUT');
        req.flush(visibility);
    });
});
