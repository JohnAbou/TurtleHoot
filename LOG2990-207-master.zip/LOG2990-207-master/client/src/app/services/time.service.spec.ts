import { TestBed, fakeAsync } from '@angular/core/testing';

import { TimeService } from './time.service';

describe('TimeService', () => {
    let service: TimeService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(TimeService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should decrement timer correctly', fakeAsync(() => {
        spyOn(service.timerExpiredEvent, 'next');
        service.setTime(1);
        service.decrement();
        expect(service.time).toEqual(0);
    }));

    it('timerExpiredEvent should emit after the timer has expired', fakeAsync(() => {
        const spy = spyOn(service.timerExpiredEvent, 'next');
        service.setTime(0);
        service.decrement();
        expect(spy).toHaveBeenCalled();
    }));
});
