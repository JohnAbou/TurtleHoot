export const environment = {
    production: true,
    serverUrl: 'http://ec2-3-135-194-107.us-east-2.compute.amazonaws.com:3000/api',
    socketUrl: 'http://ec2-3-135-194-107.us-east-2.compute.amazonaws.com:3000',
};
