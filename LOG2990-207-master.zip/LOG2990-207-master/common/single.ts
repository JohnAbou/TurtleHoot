export interface SingleItem {
    name: string;
    value: number;
}
