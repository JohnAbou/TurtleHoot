import { Player } from './player';
import { Message } from './user-message';

export interface Room {
    id: string;
    accessCode: string;
    players: Player[];
    quizId: string;
    hasStarted: boolean;
    messages: Message[];
    bannedUsernames: string[];
    isLocked: boolean;
    playerQcmAnswers: PlayerAnswerQcm[];
    playerQrlAnswers: PlayerAnswerQrl[];
    selectedAnswers: number[][];
}

export interface PlayerAnswerQcm {
    questionValue: number;
    playerId: string;
    timeLeft: number;
    isCorrect: boolean;
}

export interface PlayerAnswerQrl {
    text: string;
    questionValue: number;
    playerId: string;
    username: string;
}

export interface JoinRoom {
    username: string;
    accessCode: string;
}

export interface KickingPlayer {
    username: string;
    socketId: string;
}

export interface LockingRoom {
    gameId: string;
    isLocked: boolean;
}
