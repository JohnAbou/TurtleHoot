export enum SortOption {
    Username = 'username',
    Points = 'points',
    AnswerState = 'answerState',
}
