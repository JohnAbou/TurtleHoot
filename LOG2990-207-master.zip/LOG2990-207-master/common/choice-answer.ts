import { Grade } from './grade';
import { Question } from './quiz';

export interface ChoiceValide {
    timeLeft: number;
    question: Question;
}
export interface ChoiceValidateQcm extends ChoiceValide {
    buttonsSelected: { [key: string]: boolean };
}

export interface ChoiceValidateQrl extends ChoiceValide {
    answer: string;
}
export interface ChoiceSelected {
    questionIndex: number;
    choiceIndex: number;
    isSelected: boolean;
    choicesLength: number;
}

export interface correctedChoice {
    grades: Grade[];
    questionIndex: number;
    questionValue: number;
}
