import { HistoryInformation } from './history';
import { AnswerState, PlayerState, PlayerWithStatus } from './player';
import { Question, QuestionType, Quiz } from './quiz';
import { PlayerAnswerQcm, PlayerAnswerQrl, Room } from './room';

export const NOT_FOUND = 404;

export const BASE_URL = 'http://localhost:3000';

export const QUESTION_DELAY = 3000;

export const MAX_TEXT_LENGTH_PERCENTAGE = 100;

export const BONUS_MULTIPLIER = 1.2;

export const ID_QUIZ_SIZE = 6;
export const ACCESS_CODE_SIZE = 4;
export const ID_ROOM_SIZE = 10;

export const SELECT_VALUE = 1;
export const UNSELECT_VALUE = -1;
export const INVALID_INDEX = -1;
export const ASC_DIRECTION = 1;
export const DESC_DIRECTION = -1;

export const TIMER_TICK_DELAY = 1000;

export const PANIC_MODE_INTERVAL = 250;
export const PANIC_MODE_QCM = 10;
export const PANIC_MODE_QRL = 20;

export const QRL_DURATION = 60;

export const ORG_HISTOGRAM_DIMENSIONS = {
    width: 900,
    height: 400,
};

export const INTERACTION_COOLDOWN = 5000;

export const RES_HISTOGRAM_DIMENSIONS = {
    width: 500,
    height: 400,
};

export const QUIZ_VALUES = {
    pointMultiple: 10,
    minTimeQuestion: 10,
    maxTimeQuestion: 60,
    minNumberOfChoice: 2,
    maxNumberOfChoice: 4,
};

export const TEST_PARAMETERS = {
    responseDelay: 200,
    testDelay: 2000,
    roomLength: 4,
};

export const ID_GENERATION_PARAMS = {
    base: 36,
    startIndex: 2,
    endIndex: 11,
};

export const MOCK_QUIZZES = [
    {
        id: '1',
        title: 'Quiz 1',
        description: 'Description 1',
        questions: [] as Question[],
        duration: 60,
        lastModification: 'test',
    },
    {
        id: '2',
        title: 'Quiz 2',
        description: 'Description 2',
        questions: [],
        duration: 60,
        lastModification: 'test',
    },
];

export const MOCK_QUIZ: Quiz = {
    id: '1',
    title: 'Quiz 1',
    description: 'Desc 1',
    duration: 30,
    lastModification: '',
    questions: [
        {
            type: QuestionType.QCM,
            text: 'Parmi les mots suivants, lesquels sont des mots clés réservés en JS?',
            points: 40,
            choices: [
                { text: 'var', isCorrect: true },
                { text: 'self', isCorrect: true },
                { text: 'this', isCorrect: false },
                { text: 'int', isCorrect: false },
            ],
            id: '1',
            lastModification: '',
        },
        {
            type: QuestionType.QCM,
            text: "Est-ce qu'on le code suivant lance une erreur : const a = 1/NaN; ? ",
            points: 20,
            choices: [
                { text: 'Non', isCorrect: true },
                { text: 'Oui', isCorrect: false },
                { text: 'reponse tres tres tres tres tres tres tres tres longue', isCorrect: false },
                { text: 'reponse longue', isCorrect: false },
            ],
            id: '2',
            lastModification: '',
        },
        {
            type: QuestionType.QRL,
            text: 'Quelle est la couleur du cheval blanc de Henri IV?',
            points: 40,
            id: '3',
            lastModification: '',
        },
    ],
};

export const MOCK_QUESTIONS: Question[] = [
    {
        id: '1',
        type: QuestionType.QCM,
        text: 'Question 1',
        points: 10,
        choices: [{ text: 'Choice 1', isCorrect: false }],
        lastModification: '2024-02-13',
    },
    {
        id: '2',
        type: QuestionType.QCM,
        text: 'Question 2',
        points: 20,
        choices: [{ text: 'Choice 1', isCorrect: true }],
        lastModification: '2024-02-12',
    },
];

export const MOCK_QUESTION: Question = {
    type: QuestionType.QCM,
    text: 'Some question',
    points: 40,
    choices: [
        { text: 'Choice 1', isCorrect: true },
        { text: 'Choice 2', isCorrect: false },
    ],
    id: '',
    lastModification: '',
};

export const MOCK_ROOM: Room = {
    id: '1234',
    accessCode: '1234',
    players: [{ id: '1234', username: 'bob', role: PlayerState.Player, points: 0, nBonus: 0, answerState: AnswerState.default, isMuted: false }],
    quizId: '1235',
    hasStarted: false,
    messages: [
        { socketId: '123', username: 'user1', text: 'message1', time: 'time1' },
        { socketId: '124', username: 'user2', text: 'message2', time: 'time2' },
    ],
    bannedUsernames: [] as string[],
    playerQcmAnswers: [] as PlayerAnswerQcm[],
    playerQrlAnswers: [] as PlayerAnswerQrl[],
    selectedAnswers: [] as number[][],
    isLocked: false,
};

export const MOCK_PLAYERS: PlayerWithStatus[] = [
    {
        id: '1',
        username: 'Player 1',
        nBonus: 0,
        role: PlayerState.Player,
        points: 0,
        answerState: AnswerState.default,
        isPlaying: true,
        isMuted: false,
    },
    {
        id: '2',
        username: 'Player 2',
        nBonus: 0,
        role: PlayerState.Player,
        points: 0,
        answerState: AnswerState.default,
        isPlaying: true,
        isMuted: false,
    },
];

export const MOCK_PLAYERS_STATUS: PlayerWithStatus[] = [
    { id: '1', username: 'Player 1', nBonus: 0, role: PlayerState.Player, answerState: 0, isMuted: false, points: 0, isPlaying: true },
    { id: '2', username: 'Player 2', nBonus: 0, role: PlayerState.Player, answerState: 0, isMuted: false, points: 0, isPlaying: true },
];

export const MOCK_HISTORY: HistoryInformation[] = [
    { quizTitle: 'A', playerCount: 10, bestScore: 100, startTime: '2024-03-29T10:00:00', endTime: '2024-03-29T12:00:00' },

    { quizTitle: 'B', playerCount: 20, bestScore: 200, startTime: '2023-03-29T10:00:00', endTime: '2023-03-29T12:00:00' },
    { quizTitle: 'C', playerCount: 30, bestScore: 300, startTime: '2022-03-29T10:00:00', endTime: '2022-03-29T12:00:00' },
];

export const MOCK_HISTORY2: HistoryInformation[] = [
    { quizTitle: 'A', playerCount: 10, bestScore: 100, startTime: '2024-03-29T10:00:00', endTime: '2024-03-29T12:00:00' },
    { quizTitle: 'A', playerCount: 10, bestScore: 100, startTime: '2023-03-29T10:00:00', endTime: '2024-03-29T12:00:00' },
];

export const MOCK_HISTORY3: HistoryInformation[] = [
    { quizTitle: 'B', playerCount: 10, bestScore: 100, startTime: '2024-03-29T10:00:00', endTime: '2024-03-29T12:00:00' },
    { quizTitle: 'A', playerCount: 10, bestScore: 100, startTime: '2023-03-29T10:00:00', endTime: '2024-03-29T12:00:00' },
];

export const SORT_RETURN = -1;

export const DATE_SLICE_VALUE = -2;

export const DB_CONSTS = {
    dbDb: 'Turtlehoot',
    dbQuestionBank: 'Questionbank_Adam',
    dbCollectionQuizzes: 'Quizzes_Sebastien',
    dbCollectionQuizVisibility: 'Visibility_Nacim',
    dbCollectionHistory: 'History',
    dbURL: 'mongodb+srv://turtlehoot:turtle123@log2990-207.z9j8mxr.mongodb.net/?retryWrites=true&w=majority',
};

export const NUMBER_OF_QUESTIONS_RANDOM = 5;

export const RANDOM_QUIZ_DURATION = 20;
