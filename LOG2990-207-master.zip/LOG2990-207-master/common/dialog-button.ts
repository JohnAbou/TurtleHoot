export interface DialogButton {
    text: string;
    action?: () => void;
}

export interface DialogData {
    title: string;
    text: string;
    buttons: { text: string }[];
}
