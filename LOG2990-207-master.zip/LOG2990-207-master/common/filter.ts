export enum FilterField {
    All = 'all',
    Qcm = 'qcm',
    Qrl = 'qrl',
}
