export enum TimerEvent {
    START_TIMER = 'startTimer',
    STOP_TIMER = 'stopTimer',
    TIMER_TICK = 'timerTick',
}

export enum ChatEvent {
    ROOM_MESSAGE = 'roomMessage',
    GET_ROOM_MESSAGES = 'getRoomMessages',
    TOOGLE_MUTE_PLAYER = 'toggleMutePlayer',
}

export enum AnswerEvent {
    VALIDATE_ANSWER = 'validateAnswer',
    CHOICE_SELECTED = 'choiceSelected',
    END_QUESTION = 'endQuestion',
    GET_ROOM_ANSWERS = 'getRoomAnswers',
    VALIDATE_QCM_ANSWER = 'validateQcmAnswer',
    VALIDATE_QRL_ANSWER = 'validateQRLAnswer',
    START_EVALUATION = 'startEvaluation',
    PLAYER_INTERACTED = 'playerInteracted',
    PLAYER_AFK = 'playerAFK',
    FINISHED_CORRECTING = 'finishedCorrecting',

    NEW_POINTS = 'newPoints',
    ALL_PLAYERS_ANSWERED = 'allPlayersAnswered',
    QUESTION_ENDED = 'questionEnded',
    EVALUATION_IN_PROGRESS = 'evaluationInProgress',
    EVALUATION_FINISHED = 'evaluationFinished',
    ROOM_ANSWERS = 'roomAnswers',
    PLAYER_QRL_ANSWERS = 'playerQRLAnswers',
    INTEREACTIONS_CHANGED = 'interactionsChanged',
    PLAYER_ANSWER_SATE_CHANGED = 'playerAnswerStateChanged',
}

export enum PanicModeEvent {
    START_PANIC_MODE = 'startPanicMode',
    PANIC_COUNTDOWN_UPDATED = 'panicCountdownUpdated',
}

export enum ConnectionEvent {
    CONNECTION = 'connection',
    CREATE_GAME = 'createGame',
    CREATE_TEST_GAME = 'createTestGame',
    JOIN_ROOM = 'joinRoom',
    LEAVE_ROOM = 'leaveRoom',
    KICK_PLAYER = 'kickPlayer',
    IS_ORGANIZER = 'isOrganizer',
    DISCONNECT = 'disconnect',
    PLAYER_ACCESS = 'playerAccess',

    GAME_CREATED = 'gameCreated',
    TEST_GAME_CREATED = 'testGameCreated',
    PLAYER_JOINED = 'playerJoined',
    OTHER_PLAYER_JOINED = 'otherPlayerJoined',
    KICKED = 'kicked',
    PLAYER_KICKED = 'playerKicked',
    ORGANIZER_LEFT = 'organizerLeft',
    PLAYER_LEFT = 'playerLeft',
}

export enum GameEvent {
    VERIFY_ACCESS_TO_GAME = 'verifyAccessToGame',
    START_GAME = 'startGame',
    GET_QUIZ = 'getQuizId',
    TOOGLE_LOCK = 'toggleLock',
    GET_ROOM_PLAYERS = 'getRoomPlayers',
    GET_USERNAME = 'getUsername',
    CHANGE_TO_PLAYER = 'changeToPlayer',
    NEW_PLAYER_POINTS = 'newPlayerPoints',
    ACCESS_TO_GAME = 'accessToGame',
}

export enum ErrorSocketEvent {
    ERROR_CONNECTIONG_GAME = 'errorConnectingToGame',
    ERROR_FINDING_ROOM = 'errorFindingRoom',
    ERROR_FINDING_PLAYER = 'errorFindingPlayer',
}
