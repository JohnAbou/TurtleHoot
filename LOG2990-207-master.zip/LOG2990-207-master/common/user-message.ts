export interface Message {
    username: string;
    socketId: string;
    text: string;
    time: string;
}
