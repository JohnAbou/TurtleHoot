export interface HistoryInformation {
    quizTitle: string;
    playerCount: number;
    bestScore: number;
    startTime: string;
    endTime: string;
}

export enum SortField {
    QuizTitle = 'quizTitle',
    PlayerCount = 'playerCount',
    BestScore = 'bestScore',
    StartTime = 'startTime',
    EndTime = 'endTime'
}