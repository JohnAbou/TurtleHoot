export interface Grade {
    points: number;
    playerId: string;
}

export const GRADE = {
    decimal_divider: 100,
    half_grade: 50,
    full_grade: 100,
};
