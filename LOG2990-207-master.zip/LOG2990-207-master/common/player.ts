export interface Player {
    username: string;
    id: string;
    role: PlayerState;
    points: number;
    nBonus: number;
    answerState: AnswerState;
    isMuted: boolean;
    qrlAnswer?: string;
}

export enum AnswerState {
    default,
    hasInteracted,
    hasAnswered,
    hasForceAnswered,
}

export enum PlayerState {
    Organizer,
    Player,
}

export interface PlayerWithStatus extends Player {
    isPlaying: boolean;
}
