export interface Joueur {
    nom: string;
    pointage: number;
    bonus: number;
}

export interface Message {
    contenu: string;
}

export interface StatistiquesQCM {
    choix: string;
    selections: number;
    bonChoix: boolean;
}

export interface Question {
    type: string;
    statistiques?: StatistiquesQCM[];
}

export interface Statistique {
    choix: string;
    selections: number;
}
