export interface PopUp {
    width: string;
    data: PopUpData;
}

export interface PopUpData {
    title: string;
    text: string;
    buttons: PopUpButton[];
}

export interface PopUpButton {
    text: string;
    action?: () => void;
}
