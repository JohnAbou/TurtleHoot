export interface Quiz {
    id: string;
    title: string;
    description: string;
    duration: number;
    lastModification: string;
    questions: Question[];
}
export enum QuestionType {
    QCM,
    QRL,
}
export interface Question {
    id: string;
    lastModification: string;
    type: QuestionType;
    text: string;
    points: number;
    choices?: Choice[];
}

export interface Choice {
    text: string;
    isCorrect: boolean;
}

export interface AnswerChoice {
    index: number;
    newChoice: number;
}

export interface QuizVisibility {
    quizId: string;
    visible: boolean;
}
