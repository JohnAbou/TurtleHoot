import { Choice, Question, QuestionType, Quiz } from '@common/quiz';
import { expect } from 'chai';
import { SinonStub, stub } from 'sinon';
import { VerificationQuizService } from './verification.quiz.service';

describe('VerificationQuizService', () => {
    let verificationQuizService: VerificationQuizService;
    beforeEach(() => {
        verificationQuizService = new VerificationQuizService();
    });
    const MOCK_QUIZ: Quiz = {
        id: '1a2b3c',
        title: 'Questionnaire sur le JS',
        description: 'Questions de pratique sur le langage JavaScript',
        duration: 10,
        lastModification: '2018-11-13T20:20:39+00:00',
        questions: [
            {
                type: QuestionType.QCM,
                text: 'Parmi les mots suivants, lesquels sont des mots clés réservés en JS?',
                points: 40,
                choices: [
                    {
                        text: 'var',
                        isCorrect: true,
                    },
                    {
                        text: 'self',
                        isCorrect: false,
                    },
                    {
                        text: 'this',
                        isCorrect: true,
                    },
                    {
                        text: 'int',
                        isCorrect: true,
                    },
                ],
                id: '',
                lastModification: '',
            },
            {
                type: QuestionType.QRL,
                text: "Donnez la différence entre 'let' et 'var' pour la déclaration d'une variable en JS ?",
                points: 60,
                id: '',
                lastModification: '',
            },
        ],
    };

    const MOCK_BAD_CHOICE = [
        {
            text: 'var',
            isCorrect: false,
        },
        {
            text: 'var',
            isCorrect: true,
        },
        {
            text: 'self',
            isCorrect: 'false',
        },
        {
            text: 'this',
            isCorrect: null,
        },
        {
            text: 'int',
            isCorrect: true,
            fakeAttribut: '',
        },
    ] as Choice[];

    const MOCK_BAD_QUESTION = {
        type: QuestionType.QCM,
        fakeAttribut: 'fakeAttribut',
        text: false,
        points: 45,
        choices: MOCK_BAD_CHOICE,
    } as unknown as Question;

    const MOCK_BAD_QUIZ = {
        id: 1234,
        title: 'Questionnaire sur le JS',
        description: 'Questions de pratique sur le langage JavaScript',
        duration: 5,
        fakeAttribut: 'Fake attribut',
        lastModification: '2018-11-13T20:20:39+00:00',
        questions: [MOCK_BAD_QUESTION],
    } as unknown as Quiz;

    describe('filterQuiz', () => {
        it('Should return null if quiz is invalid', () => {
            const isValidQuizStub: SinonStub = stub(verificationQuizService, 'isValidQuiz').returns(false);
            const result = verificationQuizService.filterQuiz(null);
            expect(result).to.equal(null);
            isValidQuizStub.restore();
        });

        it('Should return filtered quiz if valid', () => {
            const isValidQuizStub: SinonStub = stub(verificationQuizService, 'isValidQuiz').returns(true);
            const filterQuestionAttributesStub: SinonStub = stub(verificationQuizService, 'filterQuestionAttributes');
            filterQuestionAttributesStub.callsFake((question) => question);

            const result = verificationQuizService.filterQuiz(MOCK_BAD_QUIZ);

            expect(result.id).to.equal(MOCK_BAD_QUIZ.id);
            expect(result.lastModification).to.equal(MOCK_BAD_QUIZ.lastModification);
            expect(result.title).to.equal(MOCK_BAD_QUIZ.title);
            expect(result.description).to.equal(MOCK_BAD_QUIZ.description);
            expect(result.questions).to.deep.equal(MOCK_BAD_QUIZ.questions);

            isValidQuizStub.restore();
            filterQuestionAttributesStub.restore();
        });
    });

    describe('isValidQuiz', () => {
        let timeDurationValidStub: SinonStub;
        let validQuestionStub: SinonStub;
        beforeEach(() => {
            timeDurationValidStub = stub(verificationQuizService, 'isTimeDurationValid').returns(true);
            validQuestionStub = stub(verificationQuizService, 'isValidQuestion').returns(true);
        });

        after(() => {
            timeDurationValidStub.restore();
            validQuestionStub.restore();
        });

        it('Should return false if newQuiz is null', () => {
            const isValid = verificationQuizService.isValidQuiz(null);
            expect(isValid).to.equals(false);
        });

        it('Should return false if newQuiz has invalid properties - wrong type', () => {
            const isValid = verificationQuizService.isValidQuiz(MOCK_BAD_QUIZ);

            expect(isValid).to.equals(false);
        });

        it('Should return false if newQuiz has invalid properties - no questions', () => {
            const TEMP_MOCK_BAD_QUIZ = structuredClone(MOCK_BAD_QUIZ);
            TEMP_MOCK_BAD_QUIZ.questions = [];
            const isValid = verificationQuizService.isValidQuiz(TEMP_MOCK_BAD_QUIZ);
            expect(isValid).to.equals(false);
        });

        it('Should return true if newQuiz has valid properties', () => {
            const isValid = verificationQuizService.isValidQuiz(MOCK_QUIZ);
            expect(isValid).to.equals(true);
        });
    });

    describe('isTimeDurationValid', () => {
        it('Should return false if duration is less than minTimeQuestion', () => {
            const isValidLowDuration = verificationQuizService.isTimeDurationValid(MOCK_BAD_QUIZ);
            expect(isValidLowDuration).to.equals(false);
            expect(verificationQuizService.textError).to.equals('Temps de duration invalide!');
        });

        it('Should return false if duration is greater than maxTimeQuestion', () => {
            const TEMP_MOCK_BAD_QUIZ = structuredClone(MOCK_BAD_QUIZ);
            TEMP_MOCK_BAD_QUIZ.duration = 65;
            const isValidHighDuration = verificationQuizService.isTimeDurationValid(TEMP_MOCK_BAD_QUIZ);

            expect(isValidHighDuration).to.equals(false);
            expect(verificationQuizService.textError).to.equals('Temps de duration invalide!');
        });

        it('Should return true if duration is within valid range', () => {
            const isValid = verificationQuizService.isTimeDurationValid(MOCK_QUIZ);
            expect(isValid).to.equals(true);
        });
    });

    describe('filterQuestionAttributes', () => {
        let filterChoiceAttributesStub: SinonStub;
        beforeEach(() => {
            filterChoiceAttributesStub = stub(verificationQuizService, 'filterChoiceAttributes');
            filterChoiceAttributesStub.callsFake((choice) => choice);
        });

        after(() => {
            filterChoiceAttributesStub.restore();
        });

        it('Should return filtered question without extra attributs', () => {
            const result = verificationQuizService.filterQuestionAttributes(MOCK_BAD_QUESTION);

            expect(result.type).to.equal(MOCK_BAD_QUESTION.type);
            expect(result.text).to.equal(MOCK_BAD_QUESTION.text);
            expect(result.points).to.equal(MOCK_BAD_QUESTION.points);
            expect(result.choices).to.deep.equal(MOCK_BAD_QUESTION.choices);
        });
    });

    describe('isValidQuestion', () => {
        let isNumberOfChoicesValidStub: SinonStub;
        let hasTrueAndFalseStub: SinonStub;
        let isPointValidStub: SinonStub;
        let isValidChoiceStub: SinonStub;

        beforeEach(() => {
            isNumberOfChoicesValidStub = stub(verificationQuizService, 'isNumberOfChoicesValid').returns(true);
            hasTrueAndFalseStub = stub(verificationQuizService, 'hasTrueAndFalse').returns(true);
            isPointValidStub = stub(verificationQuizService, 'isPointValid').returns(true);
            isValidChoiceStub = stub(verificationQuizService, 'isValidChoice').returns(true);
        });

        afterEach(() => {
            isNumberOfChoicesValidStub.restore();
            isPointValidStub.restore();
            hasTrueAndFalseStub.restore();
            isValidChoiceStub.restore();
        });

        it('Should return false if question is null', () => {
            const isValid = verificationQuizService.isValidQuestion(null);
            expect(isValid).to.equals(false);
        });

        it('Should return false if question has invalid properties - wrong type', () => {
            const isValid = verificationQuizService.isValidQuestion(MOCK_BAD_QUESTION);
            expect(isValid).to.equals(false);
        });

        it('Should return false if question has invalid properties - QCM doesnt have enough choices', () => {
            const TEMP_MOCK_BAD_QUIZ = structuredClone(MOCK_BAD_QUESTION);
            TEMP_MOCK_BAD_QUIZ.points = 50;
            TEMP_MOCK_BAD_QUIZ.choices = [];

            const isValid = verificationQuizService.isValidQuestion(TEMP_MOCK_BAD_QUIZ);
            expect(isValid).to.equals(false);
        });

        it('Should return true if question has valid properties', () => {
            const isQCMValid = verificationQuizService.isValidQuestion(MOCK_QUIZ.questions[0]);
            const isQRLValid = verificationQuizService.isValidQuestion(MOCK_QUIZ.questions[1]);
            expect(isQCMValid).to.equals(true);
            expect(isQRLValid).to.equals(true);
        });
    });

    describe('isPointValid', () => {
        it('Should return false if question`s points is not valid', () => {
            const isValid = verificationQuizService.isPointValid(MOCK_BAD_QUESTION);
            expect(isValid).to.equals(false);
        });

        it('Should return true if question`s points is valid', () => {
            const isValid = verificationQuizService.isPointValid(MOCK_QUIZ.questions[0]);
            expect(isValid).to.equals(true);
        });
    });

    describe('isNumberOfChoicesValid', () => {
        it('Should return false if there are not enough choices', () => {
            const TEMP_MOCK_BAD_QUESTION = structuredClone(MOCK_BAD_QUESTION);
            TEMP_MOCK_BAD_QUESTION.choices = [];

            const isValidNumberChoice = verificationQuizService.isNumberOfChoicesValid(TEMP_MOCK_BAD_QUESTION);
            expect(isValidNumberChoice).to.equals(false);
        });

        it('Should return false if there are too many choices', () => {
            const TEMP_MOCK_BAD_QUESTION = structuredClone(MOCK_BAD_QUESTION);

            const isValidNumberChoice = verificationQuizService.isNumberOfChoicesValid(TEMP_MOCK_BAD_QUESTION);
            expect(isValidNumberChoice).to.equals(false);
        });

        it('Should return true if the number of choices is valid', () => {
            const isValid = verificationQuizService.isNumberOfChoicesValid(MOCK_QUIZ.questions[0]);
            expect(isValid).to.equals(true);
        });
    });

    describe('hasTrueAndFalse', () => {
        it('Should return false if the minimum requirement of true choice is not met', () => {
            const TEMP_MOCK_BAD_QUESTION = structuredClone(MOCK_BAD_QUESTION);
            TEMP_MOCK_BAD_QUESTION.choices = [MOCK_BAD_QUESTION.choices[0]];
            const isValidNumberChoice = verificationQuizService.hasTrueAndFalse(TEMP_MOCK_BAD_QUESTION);
            expect(isValidNumberChoice).to.equals(false);
        });

        it('Should return false if the minimum requirement of false choice is not met', () => {
            const TEMP_MOCK_BAD_QUESTION = structuredClone(MOCK_BAD_QUESTION);
            TEMP_MOCK_BAD_QUESTION.choices = [MOCK_BAD_QUESTION.choices[1]];
            const isValidNumberChoice = verificationQuizService.hasTrueAndFalse(TEMP_MOCK_BAD_QUESTION);
            expect(isValidNumberChoice).to.equals(false);
        });

        it('Should return true if the question has at least one true and false choice option', () => {
            const isValid = verificationQuizService.hasTrueAndFalse(MOCK_QUIZ.questions[0]);
            expect(isValid).to.equals(true);
        });
    });

    describe('filterChoiceAttributes', () => {
        it('Should return a filtered choice without extra attributs', () => {
            const result = verificationQuizService.filterChoiceAttributes(MOCK_BAD_CHOICE[4]);
            expect(result.text).to.equals(MOCK_BAD_CHOICE[4].text);
            expect(result.isCorrect).to.equals(MOCK_BAD_CHOICE[4].isCorrect);
        });
    });

    describe('isValidChoice', () => {
        it('Should return false if the choice has an attribut with the wrong type', () => {
            const isValid = verificationQuizService.isValidChoice(MOCK_BAD_CHOICE[3]);
            expect(isValid).to.equals(false);
        });
        it('Should return true it is a valid choice', () => {
            const isValid = verificationQuizService.isValidChoice(MOCK_QUIZ.questions[0].choices[0]);
            expect(isValid).to.equals(true);
        });
    });
});
