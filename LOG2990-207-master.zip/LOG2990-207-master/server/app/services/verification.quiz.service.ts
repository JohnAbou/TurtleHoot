import { QUIZ_VALUES } from '@common/constants';
import { Choice, Question, QuestionType, Quiz } from '@common/quiz';
import { Service } from 'typedi';

@Service()
export class VerificationQuizService {
    textError: string = 'Mauvais type ou mauvaise valeur donné à un attribut! ';

    filterQuiz(newQuiz: Quiz): Quiz | null {
        if (!this.isValidQuiz(newQuiz)) {
            return null;
        }

        return {
            id: newQuiz.id,
            title: newQuiz.title,
            description: newQuiz.description,
            duration: newQuiz.duration,
            lastModification: newQuiz.lastModification,
            questions: newQuiz.questions.map(this.filterQuestionAttributes.bind(this)),
        };
    }

    isValidQuiz(newQuiz: Quiz): boolean {
        return (
            newQuiz !== undefined &&
            newQuiz !== null &&
            this.isTimeDurationValid(newQuiz) &&
            this.isValidAttributes(newQuiz) &&
            !isNaN(Date.parse(newQuiz.lastModification)) &&
            Array.isArray(newQuiz.questions) &&
            newQuiz.questions.length >= 1 &&
            newQuiz.questions.every(this.isValidQuestion.bind(this))
        );
    }

    isValidAttributes(newQuiz: Quiz): boolean {
        return (
            typeof newQuiz.id === 'string' &&
            typeof newQuiz.title === 'string' &&
            typeof newQuiz.description === 'string' &&
            typeof newQuiz.duration === 'number' &&
            typeof newQuiz.lastModification === 'string'
        );
    }

    isTimeDurationValid(newQuiz: Quiz): boolean {
        const isDurationValid = newQuiz.duration >= QUIZ_VALUES.minTimeQuestion && newQuiz.duration <= QUIZ_VALUES.maxTimeQuestion;
        if (!isDurationValid) {
            this.textError = 'Temps de duration invalide!';
        }
        return isDurationValid;
    }

    filterQuestionAttributes(question: Question): Question {
        return {
            id: question.id,
            lastModification: question.lastModification,
            type: question.type,
            text: question.text,
            points: question.points,
            choices: question.choices?.map(this.filterChoiceAttributes.bind(this)),
        };
    }

    isValidQuestion(data: Question): boolean {
        return (
            data !== undefined &&
            data !== null &&
            typeof data.text === 'string' &&
            typeof data.points === 'number' &&
            this.isPointValid(data) &&
            (data.type === QuestionType.QRL ||
                (data.type === QuestionType.QCM &&
                    Array.isArray(data.choices) &&
                    this.isNumberOfChoicesValid(data) &&
                    this.hasTrueAndFalse(data) &&
                    data.choices.every(this.isValidChoice.bind(this))))
        );
    }

    isPointValid(question: Question): boolean {
        const isPointValid = question.points % QUIZ_VALUES.pointMultiple === 0;
        if (!isPointValid) {
            this.textError = `Attribution des points pour la question "${question.text}" n'est pas valide!`;
        }
        return isPointValid;
    }

    isNumberOfChoicesValid(question: Question): boolean {
        const isNumberOfChoices =
            question.choices.length >= QUIZ_VALUES.minNumberOfChoice && question.choices.length <= QUIZ_VALUES.maxNumberOfChoice;
        if (!isNumberOfChoices) {
            this.textError = `Nombre de choix de réponse pour la question "${question.text}" n'est pas valide!`;
        }
        return isNumberOfChoices;
    }

    hasTrueAndFalse(question: Question): boolean {
        let hasTrue = false;
        let hasFalse = false;

        for (const choice of question.choices) {
            if (choice.isCorrect) {
                hasTrue = true;
            } else {
                hasFalse = true;
            }
        }
        if (!hasTrue) {
            this.textError = `Il faut au moins une réponse vraie pour la question: ${question.text}!`;
        }
        if (!hasFalse) {
            this.textError = `Il faut au moins une réponse fausse pour la question: ${question.text}!`;
        }
        return hasTrue && hasFalse;
    }

    filterChoiceAttributes(choice: Choice): Choice {
        return {
            text: choice.text,
            isCorrect: choice.isCorrect,
        };
    }

    isValidChoice(data: Choice): boolean {
        return data && typeof data.text === 'string' && typeof data.isCorrect === 'boolean';
    }
}
