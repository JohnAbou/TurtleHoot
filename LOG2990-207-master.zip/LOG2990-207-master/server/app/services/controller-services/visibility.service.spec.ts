import { expect } from 'chai';
import { Collection, FindCursor, ObjectId, UpdateResult } from 'mongodb';
import * as sinon from 'sinon';
import { VisibilityService } from './visibility.service';

describe('VisibilityService', () => {
    let visibilityService: VisibilityService;
    let collectionStub: sinon.SinonStubbedInstance<Collection>;
    let dbServiceStub: { db: { collection: sinon.SinonStub } };

    beforeEach(() => {
        collectionStub = sinon.createStubInstance(Collection);
        dbServiceStub = { db: { collection: sinon.stub().returns(collectionStub) } };
        visibilityService = new VisibilityService();
        sinon.stub(visibilityService, 'dbService').get(() => dbServiceStub);
        sinon.stub(visibilityService, 'collection').returns(collectionStub);
    });

    afterEach(() => {
        sinon.restore();
    });

    it('should get all visibility', async () => {
        interface Document {
            id: string;
            visibility: boolean;
        }

        const visibility: Document[] = [
            { id: '1', visibility: true },
            { id: '2', visibility: false },
        ];

        const mockFindCursor: Partial<FindCursor<Document>> = {
            toArray: async () => Promise.resolve(visibility),
        };

        collectionStub.find.returns(mockFindCursor as FindCursor<Document>);

        const result = await visibilityService.getAllVisibility();

        expect(result).to.deep.equal(visibility);
    });

    it('should set visibility', async () => {
        const id = '1';
        const visibility = true;
        const updateResult: UpdateResult = {
            matchedCount: 1,
            modifiedCount: 1,
            acknowledged: false,
            upsertedCount: 0,
            upsertedId: new ObjectId(),
        };
        collectionStub.updateOne.resolves(updateResult);

        const result = await visibilityService.setVisibility(id, visibility);

        expect(result).to.equal(true);
        sinon.assert.calledWith(collectionStub.updateOne, { id }, { $set: { visibility } });
    });

    it('should throw error when set visibility fails', async () => {
        const id = '1';
        const visibility = true;
        collectionStub.updateOne.rejects(new Error('Update failed'));

        try {
            await visibilityService.setVisibility(id, visibility);
            throw new Error('setVisibility did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('Update failed');
        }
    });

    it('should get visibility', async () => {
        const id = '1';
        const visibilityDocument = { id, visibility: true };
        collectionStub.findOne.resolves(visibilityDocument);

        const result = await visibilityService.getVisibility(id);

        expect(result).to.equal(true);
        sinon.assert.calledWith(collectionStub.findOne, { id });
    });

    it('should throw error when quiz not found', async () => {
        const id = '1';
        collectionStub.findOne.resolves(null);

        try {
            await visibilityService.getVisibility(id);
            throw new Error('getVisibility did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('Quiz not found');
        }
    });

    it('should throw error when get visibility fails', async () => {
        const id = '1';
        collectionStub.findOne.rejects(new Error('Find failed'));

        try {
            await visibilityService.getVisibility(id);
            throw new Error('getVisibility did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('Find failed');
        }
    });

    it('should throw error when get all visibility fails', async () => {
        const mockFindCursor: Partial<FindCursor<Document>> = {
            toArray: async () => Promise.reject(new Error('Find failed')),
        };

        collectionStub.find.returns(mockFindCursor as FindCursor<Document>);

        try {
            await visibilityService.getAllVisibility();
            throw new Error('getAllVisibility did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('Find failed');
        }
    });

    it('should add visibility', async () => {
        const id = '1';
        const visibility = true;
        const insertResult = { acknowledged: true, insertedId: new ObjectId() };
        collectionStub.findOne.resolves(null);
        collectionStub.insertOne.resolves(insertResult);

        const result = await visibilityService.addVisibility(id, visibility);

        expect(result).to.be.a('string');
        sinon.assert.calledWith(collectionStub.findOne, { id });
        sinon.assert.calledWith(collectionStub.insertOne, { id, visibility });
    });

    it('should throw error when failed to add visibility due to unacknowledged insert', async () => {
        const id = '1';
        const visibility = true;
        collectionStub.findOne.resolves(null);
        collectionStub.insertOne.resolves({ acknowledged: false, insertedId: null });

        try {
            await visibilityService.addVisibility(id, visibility);
            throw new Error('Expected method to reject');
        } catch (error) {
            expect(error.message).to.equal('Failed to insert visibility data');
        }

        sinon.assert.calledWith(collectionStub.findOne, { id });
        sinon.assert.calledWith(collectionStub.insertOne, { id, visibility });
    });

    it('should throw error when a quiz with same ID exists', async () => {
        const id = '1';
        const visibility = true;
        const existingDoc = { id, visibility };
        collectionStub.findOne.resolves(existingDoc);

        try {
            await visibilityService.addVisibility(id, visibility);
            throw new Error('addVisibility did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('A quiz with this id already exists');
        }
    });

    it('should throw error when add visibility fails', async () => {
        const id = '1';
        const visibility = true;
        collectionStub.findOne.rejects(new Error('Find failed'));

        try {
            await visibilityService.addVisibility(id, visibility);
            throw new Error('addVisibility did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('Find failed');
        }
    });

    it('should throw an error if the quiz is not found or the visibility update fails', async () => {
        const id = 'nonexistent-id';
        const visibility = true;
        collectionStub.updateOne.resolves({ acknowledged: true, upsertedCount: 0, upsertedId: null, matchedCount: 0, modifiedCount: 0 });

        try {
            await visibilityService.setVisibility(id, visibility);
            throw new Error('Expected method to throw');
        } catch (error) {
            expect(error.message).to.equal('Quiz not found or failed to update visibility');
        }
        sinon.assert.calledWith(collectionStub.updateOne, { id }, { $set: { visibility } });
    });

    it('should return the collection', () => {
        const collection = visibilityService.collection;
        expect(collection).to.equal(collectionStub);
    });
});
