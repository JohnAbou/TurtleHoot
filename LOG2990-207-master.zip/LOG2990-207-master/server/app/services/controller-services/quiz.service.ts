import { DatabaseService } from '@app/services/database.service';
import { DB_CONSTS, ID_QUIZ_SIZE } from '@common/constants';
import { Quiz } from '@common/quiz';
import { Collection, InsertOneResult, ObjectId } from 'mongodb';
import { nanoid } from 'nanoid';
import { Service } from 'typedi';
import { VisibilityService } from './visibility.service';
@Service()
export class QuizService {
    private dbService: DatabaseService;
    constructor(
        private readonly databaseService: DatabaseService,
        private visibilityService: VisibilityService,
    ) {
        this.dbService = this.databaseService;
    }
    private get collection(): Collection {
        return this.dbService.db.collection(DB_CONSTS.dbCollectionQuizzes);
    }

    async retrieveAllQuizzes(): Promise<unknown[]> {
        return this.collection.find({}).toArray();
    }

    async getQuizById(id: string): Promise<unknown | null> {
        return this.collection.findOne({ id });
    }

    async modifyQuiz(id: string, updatedQuizData: Quiz): Promise<unknown> {
        updatedQuizData.lastModification = new Date().toDateString();
        await this.collection.updateOne({ id }, { $set: updatedQuizData });
        return this.collection.findOne({ id });
    }

    async addQuestionToQuiz(quizId: string, newQuestionData: unknown): Promise<unknown> {
        await this.collection.updateOne({ id: quizId }, { $push: { questions: newQuestionData } });
        return this.collection.findOne({ id: quizId });
    }

    async deleteQuestionInQuiz(quizId: string, question: string): Promise<unknown> {
        await this.collection.updateOne({ id: quizId }, { $pull: { questions: question } });
        return this.collection.findOne({ id: quizId });
    }

    async deleteQuiz(quizId: string): Promise<void> {
        await this.collection.deleteOne({ id: quizId });
    }

    async addQuiz(newQuizData: Quiz): Promise<Quiz> {
        try {
            const insertResult: InsertOneResult<Quiz> = await this.collection.insertOne(newQuizData);
            const insertedId: ObjectId = insertResult.insertedId;
            const insertedQuiz = await this.collection.findOne({ _id: insertedId });
            return insertedQuiz as unknown as Quiz;
        } catch (error) {
            throw new Error('Failed to add quiz');
        }
    }

    async getQuizByName(title: string): Promise<unknown | null> {
        return this.collection.findOne({ title });
    }

    async saveQuiz(filteredQuiz: Quiz) {
        const date = new Date();
        filteredQuiz.id = nanoid(ID_QUIZ_SIZE);
        filteredQuiz.lastModification = date.toISOString();
        await this.visibilityService.addVisibility(filteredQuiz.id, false);
        if (await this.getQuizByName(filteredQuiz.title)) {
            return false;
        } else {
            this.addQuiz(filteredQuiz);
            return true;
        }
    }
}
