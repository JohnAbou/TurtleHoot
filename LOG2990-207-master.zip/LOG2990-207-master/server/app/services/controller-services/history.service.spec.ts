import { MOCK_HISTORY } from '@common/constants';
import { HistoryInformation } from '@common/history';
import { expect } from 'chai';
import { Collection, FindCursor } from 'mongodb';
import * as sinon from 'sinon';
import { HistoryService } from './history.service';

describe('HistoryService', () => {
    let historyService: HistoryService;
    let collectionStub: sinon.SinonStubbedInstance<Collection>;
    let dbServiceStub: { db: { collection: sinon.SinonStub } };

    beforeEach(() => {
        collectionStub = sinon.createStubInstance(Collection);
        dbServiceStub = { db: { collection: sinon.stub().returns(collectionStub) } };
        historyService = new HistoryService();
        sinon.stub(historyService, 'dbService').get(() => dbServiceStub);
        sinon.stub(historyService, 'collection').returns(collectionStub);
    });

    afterEach(() => {
        sinon.restore();
    });

    it('should get all history', async () => {
        const mockHistory = [
            {
                quizTitle: 'Quiz 1',
                playerCount: 10,
                bestScore: 100,
                startTime: '2024-03-29T10:00:00',
                endTime: '2024-03-29T12:00:00',
            },
            {
                quizTitle: 'Quiz 2',
                playerCount: 10,
                bestScore: 100,
                startTime: '2024-03-29T10:00:00',
                endTime: '2024-03-29T12:00:00',
            },
        ];

        const mockFindCursor: Partial<FindCursor<unknown>> = {
            toArray: sinon.stub().resolves(mockHistory),
        };

        collectionStub.find.returns(mockFindCursor as FindCursor<unknown>);

        const result = await historyService.getAllHistory();

        expect(result).to.deep.equal(mockHistory);
    });

    it('should get all history', async () => {
        const mockFindCursor: Partial<FindCursor<HistoryInformation>> = {
            toArray: async () => Promise.resolve(MOCK_HISTORY),
        };

        collectionStub.find.returns(mockFindCursor as FindCursor<HistoryInformation>);

        const result = await historyService.getAllHistory();

        expect(result).to.deep.equal(MOCK_HISTORY);
    });

    it('should add history information', async () => {
        await historyService.addHistoryInformation(MOCK_HISTORY[0]);

        sinon.assert.calledWith(collectionStub.insertOne, MOCK_HISTORY[0]);
    });

    it('should delete all history', async () => {
        await historyService.deleteAllHistory();

        sinon.assert.calledOnce(collectionStub.deleteMany);
    });

    it('should throw error when get all history fails', async () => {
        const errorMessage = 'Find failed';
        collectionStub.find.rejects(new Error(errorMessage));

        try {
            await historyService.getAllHistory();
            throw new Error('Expected method to throw');
        } catch (error) {
            expect(error).to.be.an.instanceOf(Error);
        }
    });

    it('should throw error when adding history information fails', async () => {
        const errorMessage = 'Failed to add information to history';
        const newHistoryInformation = {
            quizTitle: 'Quiz 1',
            playerCount: 10,
            bestScore: 100,
            startTime: '2024-03-29T10:00:00',
            endTime: '2024-03-29T12:00:00',
        };
        collectionStub.insertOne.rejects(new Error(errorMessage));

        try {
            await historyService.addHistoryInformation(newHistoryInformation);
            throw new Error('Expected method to throw');
        } catch (error) {
            expect(error.message).to.equal(errorMessage);
        }
    });

    it('should throw error when delete all history fails', async () => {
        const errorMessage = 'Failed to delete history';
        collectionStub.deleteMany.rejects(new Error(errorMessage));

        try {
            await historyService.deleteAllHistory();
            throw new Error('Expected method to throw');
        } catch (error) {
            expect(error.message).to.equal(errorMessage);
        }
    });

    it('should return the collection', () => {
        const collection = historyService.collection;
        expect(collection).to.equal(collectionStub);
    });
});
