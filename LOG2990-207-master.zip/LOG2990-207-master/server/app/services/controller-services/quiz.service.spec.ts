import { DatabaseService } from '@app/services/database.service';
import { Question, QuestionType, Quiz } from '@common/quiz';
import { expect } from 'chai';
import 'chai-as-promised';
import { SinonStub, SinonStubbedInstance, createStubInstance, match, stub } from 'sinon';
import { QuizService } from './quiz.service';
import { VisibilityService } from './visibility.service';

describe('QuizService', () => {
    let quizService: QuizService;
    let collectionStub: SinonStub;
    let dbService: DatabaseService;
    let visibilityService: SinonStubbedInstance<VisibilityService>;

    beforeEach(() => {
        collectionStub = stub();
        dbService = { db: { collection: collectionStub } } as unknown as DatabaseService;
        visibilityService = createStubInstance(VisibilityService);
        quizService = new QuizService(dbService, visibilityService);
    });

    afterEach(() => {
        if (collectionStub.reset) {
            collectionStub.reset();
        }
    });

    it('devrait récupérer tous les quizzes', async () => {
        const fakeQuizzes = [
            { id: '1', title: 'Quiz 1' },
            { id: '2', title: 'Quiz 2' },
        ];
        collectionStub.returns({ find: () => ({ toArray: () => fakeQuizzes }) });

        const quizzes = await quizService.retrieveAllQuizzes();

        expect(quizzes).to.deep.equal(fakeQuizzes);
    });

    describe('getQuizById', () => {
        it('should return a quiz by ID', async () => {
            const fakeQuiz = { id: '1', title: 'Quiz 1' };
            collectionStub.returns({ findOne: () => fakeQuiz });

            const quiz = await quizService.getQuizById('1');

            expect(quiz).to.deep.equal(fakeQuiz);
        });

        it('should return null if no quiz is found', async () => {
            collectionStub.returns({ findOne: (): null => null });

            const quiz = await quizService.getQuizById('1');

            expect(quiz).to.equal(null);
        });
    });

    describe('modifyQuiz', () => {
        it('should modify a quiz and return the updated quiz', async () => {
            const updatedQuizData = {
                id: '1',
                title: 'Updated Quiz',
                description: 'Updated Desc',
                duration: 45,
                lastModification: new Date().toLocaleDateString(),
                questions: [] as Question[],
            };
            const mockUpdatedQuiz: Quiz = {
                id: '1',
                title: 'Updated Quiz',
                description: 'Updated Desc',
                duration: 45,
                lastModification: new Date().toLocaleDateString(),
                questions: [],
            };

            collectionStub.returns({
                updateOne: async () => ({ matchedCount: 1, modifiedCount: 1 }),
                findOne: async () => mockUpdatedQuiz,
            });

            const quiz = await quizService.modifyQuiz('1', updatedQuizData);
            expect(quiz).to.deep.equal(mockUpdatedQuiz);
        });
    });

    describe('addQuestionToQuiz', () => {
        it('should add a question to a quiz and return it', async () => {
            const newQuestionData = { text: 'New Question', type: QuestionType.QCM, points: 5 };
            const mockQuiz: Quiz = {
                id: '1',
                title: 'Quiz 1',
                description: 'Desc 1',
                duration: 30,
                lastModification: new Date().toLocaleString(),
                questions: [newQuestionData as Question],
            };

            collectionStub.withArgs(match.any).returns({
                updateOne: async () => ({}),
                findOne: async () => mockQuiz,
            });

            const quiz = await quizService.addQuestionToQuiz('1', newQuestionData);
            expect(quiz).to.deep.equal(mockQuiz);
        });
    });

    describe('deleteQuestionInQuiz', () => {
        it('should delete a question in a quiz and return the updated quiz', async () => {
            const questionToDelete = 'New Question';
            const mockQuizAfterDeletion: Quiz = {
                id: '1',
                title: 'Quiz 1',
                description: 'Desc 1',
                duration: 30,
                lastModification: new Date().toLocaleString(),
                questions: [],
            };

            collectionStub.withArgs(match.any).returns({
                updateOne: async () => ({}),
                findOne: async () => mockQuizAfterDeletion,
            });

            const quiz = await quizService.deleteQuestionInQuiz('1', questionToDelete);
            expect(quiz).to.deep.equal(mockQuizAfterDeletion);
        });
    });

    describe('deleteQuiz', () => {
        it('should delete a quiz', async () => {
            collectionStub.withArgs(match.any).returns({
                deleteOne: async () => ({ deletedCount: 1 }),
            });

            await quizService.deleteQuiz('1');
        });
    });

    describe('addQuiz', () => {
        it('should add a new quiz and return it', async () => {
            const mockInsertedQuiz: Quiz = {
                id: '1',
                title: 'New Quiz',
                description: 'New Desc',
                duration: 30,
                lastModification: new Date().toLocaleString(),
                questions: [],
            };

            const newQuizData: Quiz = {
                id: '1',
                title: 'New Quiz',
                description: 'New Desc',
                duration: 30,
                lastModification: new Date().toLocaleString(),
                questions: [],
            };
            collectionStub.returns({
                insertOne: async () => ({ insertedId: '1' }),
                findOne: async () => mockInsertedQuiz,
            });

            const quiz = await quizService.addQuiz(newQuizData);
            expect(quiz).to.deep.equal(mockInsertedQuiz);
        });

        it('should throw an error if adding a quiz fails', async () => {
            collectionStub.withArgs(match.any).rejects(new Error('Failed to add quiz'));

            try {
                const invalidQuizData: Quiz = {
                    id: '1',
                    title: 'Invalid Quiz',
                    description: 'Invalid Desc',
                    duration: 30,
                    lastModification: new Date().toLocaleString(),
                    questions: [],
                };
                await quizService.addQuiz(invalidQuizData);
                throw new Error('Expected error');
            } catch (error) {
                expect(error.message).to.equal('Failed to add quiz');
            }
        });

        it('should get a quiz by name', async () => {
            const fakeQuiz = { id: '1', title: 'Quiz 1' };
            collectionStub.returns({ findOne: () => fakeQuiz });

            const quiz = await quizService.getQuizByName('Quiz 1');

            expect(quiz).to.deep.equal(fakeQuiz);
        });

        it('should not save a quiz', async () => {
            const filteredQuiz: Quiz = {
                id: '1',
                title: 'Quiz 1',
                description: 'Desc 1',
                duration: 30,
                lastModification: new Date().toLocaleString(),
                questions: [],
            };
            collectionStub.returns({ findOne: () => filteredQuiz });

            const saved = await quizService.saveQuiz(filteredQuiz);
            expect(saved).to.equal(false);
        });

        it('should save a quiz', async () => {
            const filteredQuiz: Quiz = {
                id: '1',
                title: 'Quiz 1',
                description: 'Desc 1',
                duration: 30,
                lastModification: new Date().toLocaleString(),
                questions: [],
            };
            collectionStub.returns({ findOne: (): Quiz | null => null });

            const saved = await quizService.saveQuiz(filteredQuiz);
            expect(saved).to.equal(true);
        });
    });
});
