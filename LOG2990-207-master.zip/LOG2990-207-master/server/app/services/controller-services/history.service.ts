import { dbService } from '@app/services/database.service';
import { DB_CONSTS } from '@common/constants';
import { HistoryInformation } from '@common/history';
import { Collection } from 'mongodb';
import { Service } from 'typedi';
@Service()
export class HistoryService {
    dbService = dbService;

    get collection(): Collection {
        return this.dbService.db.collection(DB_CONSTS.dbCollectionHistory);
    }

    async getAllHistory(): Promise<HistoryInformation[]> {
        try {
            return this.collection.find({}).toArray() as unknown as HistoryInformation[];
        } catch (error) {
            throw new Error(error.message);
        }
    }
    async addHistoryInformation(historyInfo: HistoryInformation): Promise<void> {
        try {
            await this.collection.insertOne(historyInfo);
        } catch (error) {
            throw new Error('Failed to add information to history');
        }
    }

    async deleteAllHistory(): Promise<void> {
        try {
            await this.collection.deleteMany({});
        } catch (error) {
            throw new Error(error.message);
        }
    }
}
