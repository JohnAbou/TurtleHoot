import { dbService } from '@app/services/database.service';
import { DB_CONSTS } from '@common/constants';
import { QuizVisibility } from '@common/quiz';
import { Collection } from 'mongodb';
import { Service } from 'typedi';
@Service()
export class VisibilityService {
    dbService = dbService;

    get collection(): Collection {
        return this.dbService.db.collection(DB_CONSTS.dbCollectionQuizVisibility);
    }

    async setVisibility(id: string, visibility: boolean): Promise<boolean> {
        try {
            const result = await this.collection.updateOne({ id }, { $set: { visibility } });
            if (!result.matchedCount || !result.modifiedCount) {
                throw new Error('Quiz not found or failed to update visibility');
            } else {
                return true;
            }
        } catch (error) {
            throw new Error(error.message);
        }
    }

    async getVisibility(id: string): Promise<boolean | null> {
        try {
            const visibilityDocument = await this.collection.findOne({ id });
            if (visibilityDocument) {
                return visibilityDocument.visibility;
            } else {
                throw new Error('Quiz not found');
            }
        } catch (error) {
            throw new Error(error.message);
        }
    }

    async getAllVisibility(): Promise<QuizVisibility[]> {
        try {
            return this.collection.find({}).toArray() as unknown as QuizVisibility[];
        } catch (error) {
            throw new Error(error.message);
        }
    }

    async addVisibility(id: string, visibility: boolean): Promise<string | null> {
        try {
            const existingDoc = await this.collection.findOne({ id });

            if (existingDoc) {
                throw new Error('A quiz with this id already exists');
            } else {
                const insertResult = await this.collection.insertOne({ id, visibility });
                if (insertResult.acknowledged) {
                    return insertResult.insertedId.toHexString();
                } else {
                    throw new Error('Failed to insert visibility data');
                }
            }
        } catch (error) {
            throw new Error(error.message);
        }
    }
}
