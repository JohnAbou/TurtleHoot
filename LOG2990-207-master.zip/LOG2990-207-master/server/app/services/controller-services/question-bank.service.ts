import { DatabaseService } from '@app/services/database.service';
import { VerificationQuizService } from '@app/services/verification.quiz.service';
import { DB_CONSTS } from '@common/constants';
import { Question } from '@common/quiz';
import { Collection, InsertOneResult } from 'mongodb';
import { Service } from 'typedi';
@Service()
export class QuestionBank {
    private dbService: DatabaseService;

    constructor(
        private readonly databaseService: DatabaseService,
        private readonly verificationQuizService: VerificationQuizService,
    ) {
        this.dbService = this.databaseService;
    }
    private get collection(): Collection {
        if (!this.dbService) {
            throw new Error('Database connection not initialized');
        }
        if (!this.dbService.db) {
            throw new Error('Database not initialized');
        }
        return this.dbService.db.collection(DB_CONSTS.dbQuestionBank);
    }

    async retrieveAllQuestions(): Promise<Question[]> {
        const questions = (await this.collection.find({}).toArray()) as unknown[];
        return questions as Question[];
    }

    async getQuestionById(id: string): Promise<Question | null> {
        const question = (await this.collection.findOne({ id })) as unknown;
        return question as Question | null;
    }

    async modifyQuestion(id: string, updatedQuizData: Question): Promise<Question> {
        const question = this.verificationQuizService.filterQuestionAttributes(updatedQuizData);

        await this.collection.updateOne({ id }, { $set: question });
        return this.collection.findOne({ id }) as unknown as Question;
    }

    async deleteQuestion(quizId: string): Promise<void> {
        await this.collection.deleteOne({ id: quizId });
    }

    async addQuestion(newQuestionData: Question): Promise<Question> {
        try {
            const insertResult: InsertOneResult<unknown> = await this.collection.insertOne(newQuestionData);
            const insertedId: unknown = insertResult.insertedId;
            return this.collection.findOne({ _id: insertedId }) as unknown as Question;
        } catch (error) {
            throw new Error('Failed to add question');
        }
    }
}
