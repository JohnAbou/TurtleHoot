import { DatabaseService } from '@app/services/database.service';
import { VerificationQuizService } from '@app/services/verification.quiz.service';
import { MOCK_QUESTION } from '@common/constants';
import { Question, QuestionType } from '@common/quiz';
import { expect } from 'chai';
import { Collection, Db, InsertOneResult, ObjectId } from 'mongodb';
import * as sinon from 'sinon';
import { QuestionBank } from './question-bank.service';

describe('QuestionBank', () => {
    let questionBank: QuestionBank;
    let databaseServiceStub: sinon.SinonStubbedInstance<DatabaseService>;
    let collectionStub: sinon.SinonStubbedInstance<Collection>;
    let verificationQuizService: sinon.SinonStubbedInstance<VerificationQuizService>;
    beforeEach(() => {
        collectionStub = sinon.createStubInstance(Collection);
        verificationQuizService = sinon.createStubInstance(VerificationQuizService);
        databaseServiceStub = sinon.createStubInstance(DatabaseService);
        databaseServiceStub.db = {
            collection: sinon.stub().returns(collectionStub),
        } as unknown as Db;
        questionBank = new QuestionBank(databaseServiceStub, verificationQuizService);
    });

    it('should get question by ID', async () => {
        const questionId = '1';
        const expectedQuestion = { id: questionId, text: 'Question 1' };
        collectionStub.findOne.resolves(expectedQuestion);

        const question = await questionBank.getQuestionById(questionId);

        expect(question).to.deep.equal(expectedQuestion);
    });

    it('should modify question', async () => {
        const questionId = '1';
        const updatedData = {
            text: 'Updated question text',
            type: QuestionType.QCM,
            points: 40,
            choices: [
                {
                    text: 'var',
                    isCorrect: true,
                },
                {
                    text: 'self',
                    isCorrect: false,
                },
            ],
            id: '',
            lastModification: '',
        } as Question;

        const expectedModifiedQuestion = { id: questionId, text: 'Updated question text' };
        collectionStub.updateOne.resolves();
        collectionStub.findOne.resolves(expectedModifiedQuestion);

        const modifiedQuestion = await questionBank.modifyQuestion(questionId, updatedData);

        expect(modifiedQuestion).to.deep.equal(expectedModifiedQuestion);
    });

    it('should delete question', async () => {
        const questionId = '1';
        collectionStub.deleteOne.resolves();

        await questionBank.deleteQuestion(questionId);

        sinon.assert.calledWith(collectionStub.deleteOne, { id: questionId });
    });

    it('should throw error if add question fails', async () => {
        collectionStub.insertOne.rejects(new Error('Insert failed'));

        try {
            await questionBank.addQuestion(MOCK_QUESTION);
            throw new Error('addQuestion did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('Failed to add question');
        }
    });

    it('should throw error if database connection is not initialized', async () => {
        questionBank = new QuestionBank(undefined, undefined);

        try {
            await questionBank.retrieveAllQuestions();
            throw new Error('retrieveAllQuestions did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('Database connection not initialized');
        }
    });

    it('should throw error if database is not initialized', async () => {
        databaseServiceStub.db = undefined;

        try {
            await questionBank.retrieveAllQuestions();
            throw new Error('retrieveAllQuestions did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('Database not initialized');
        }
    });

    it('should add a new question and retrieve it by ID', async () => {
        const newQuestionData = MOCK_QUESTION;
        const insertedId = '60df1906288a442d1c4a8d32';
        const objectId = new ObjectId(insertedId);

        const expectedInsertedQuestion = { _id: insertedId, ...newQuestionData };
        const insertResult: InsertOneResult<unknown> = {
            insertedId: objectId,
            acknowledged: true,
        };
        collectionStub.insertOne.resolves(insertResult);
        collectionStub.findOne.withArgs({ _id: objectId }).resolves(expectedInsertedQuestion);

        const insertedQuestion = await questionBank.addQuestion(newQuestionData);

        expect(insertedQuestion).to.deep.equal(expectedInsertedQuestion);
        sinon.assert.calledWith(collectionStub.insertOne, newQuestionData);
        sinon.assert.calledWith(collectionStub.findOne, { _id: objectId });
    });

    it('should throw an error if insertOne fails', async () => {
        const newQuestionData = MOCK_QUESTION;
        const errorMessage = 'Insert failed';
        collectionStub.insertOne.rejects(new Error(errorMessage));

        try {
            await questionBank.addQuestion(newQuestionData);
            throw new Error('addQuestion did not throw expected error');
        } catch (error) {
            expect(error.message).to.equal('Failed to add question');
        }
    });
});
