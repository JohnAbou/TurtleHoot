import { DB_CONSTS } from '@common/constants';
import { expect } from 'chai';
import { Db, MongoClient } from 'mongodb';
import { SinonStub, restore, stub } from 'sinon';
import { DatabaseService } from './database.service';
describe('DatabaseService', () => {
    let dbService: DatabaseService;
    let mongoClientStub: SinonStub;

    beforeEach(() => {
        dbService = new DatabaseService();
        mongoClientStub = stub(MongoClient.prototype, 'connect');
        const dbStub: Partial<Db> = {
            collection: stub().returns({} as unknown),
        };

        stub(MongoClient.prototype, 'db').returns(dbStub as Db);
    });

    afterEach(() => {
        restore();
    });

    it('should connect to the MongoDB server successfully', async () => {
        mongoClientStub.resolves();

        await dbService.connectToServer(DB_CONSTS.dbURL);

        expect(mongoClientStub.calledOnce).to.equal(true);
        expect(dbService.db).to.not.equal(undefined);
    });

    it('should handle errors during connection to the MongoDB server', async () => {
        const errorMessage = 'Failed to connect to MongoDB.';
        mongoClientStub.rejects(new Error(errorMessage));

        try {
            await dbService.connectToServer(DB_CONSTS.dbURL);
            expect.fail('Expected error was not thrown');
        } catch (err) {
            expect(err).to.be.an.instanceOf(Error);
        }
        expect(dbService.db).to.equal(undefined);
        expect(mongoClientStub.calledOnce).to.equal(true);
    });
});
