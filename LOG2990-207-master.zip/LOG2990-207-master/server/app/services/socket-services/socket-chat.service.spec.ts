import { BASE_URL, MOCK_ROOM, TEST_PARAMETERS } from '@common/constants';
import { ChatEvent, ConnectionEvent, ErrorSocketEvent } from '@common/event-name';
import { PlayerState } from '@common/player';
import { Room } from '@common/room';
import { Message } from '@common/user-message';
import { Server } from 'app/server';
import { assert, expect } from 'chai';
import * as sinon from 'sinon';
import { Socket, io as ioClient } from 'socket.io-client';
import { Container } from 'typedi';
import { SocketChatManager } from './socket-chat.service';

describe('SocketChatManager service tests', () => {
    let service: SocketChatManager;
    let server: Server;
    let clientSocket: Socket;
    let mockRoom: Room;

    beforeEach(async () => {
        server = Container.get(Server);
        server.init();
        await new Promise((resolve) => setTimeout(resolve, TEST_PARAMETERS.testDelay));
        service = server['socketChatManager'];
        clientSocket = ioClient(BASE_URL);
        service['roomStorage'].listRooms = [];
        mockRoom = JSON.parse(JSON.stringify(MOCK_ROOM));
    });

    afterEach(async () => {
        await new Promise<void>((resolve) => {
            clientSocket.close();
            service['sio'].close(() => {
                resolve();
            });
        });
        sinon.restore();
    });

    it('should emit room messages to client when receiving getRoomMessages event', (done) => {
        const testRoomMessages: Message[] = [
            { socketId: '123', username: 'user1', text: 'message1', time: 'time1' },
            { socketId: '124', username: 'user2', text: 'message2', time: 'time2' },
        ];

        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(ChatEvent.GET_ROOM_MESSAGES);

            clientSocket.on(ChatEvent.GET_ROOM_MESSAGES, (receivedRoomMessages: Message[]) => {
                expect(receivedRoomMessages).to.deep.equal(testRoomMessages);
                done();
            });
        });
    });

    it('should emit errorFindingRoom when player is not in a room', (done) => {
        clientSocket.emit(ChatEvent.GET_ROOM_MESSAGES);

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should not broadcast message to room if origin socket is not in room', (done) => {
        const testMessage = 'Hello World';
        const spy = sinon.spy(service['sio'], 'to');
        clientSocket.emit(ChatEvent.ROOM_MESSAGE, testMessage);

        setTimeout(() => {
            assert(spy.notCalled);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });

    it('should broadcast message to room if origin socket is in room', (done) => {
        const testMessage = 'Hello World';
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        mockRoom.isLocked = false;
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(ChatEvent.ROOM_MESSAGE, testMessage);

            clientSocket.on(ChatEvent.ROOM_MESSAGE, (message: Message) => {
                expect(message.text).to.equal(testMessage);
                done();
            });
        });
    });

    it('should mute a player on toggleMutePlayer', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        const playerSocket = ioClient(BASE_URL);
        const MOCK_CLIENT = { accessCode: '1234', username: 'newPlayer', role: PlayerState.Player };

        clientSocket.emit(ConnectionEvent.JOIN_ROOM, { accessCode: '1234', username: 'albert', role: PlayerState.Player });
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            playerSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
            playerSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
                clientSocket.emit(ChatEvent.TOOGLE_MUTE_PLAYER, playerSocket.id);
                playerSocket.on(ChatEvent.TOOGLE_MUTE_PLAYER, () => {
                    expect(service['roomStorage'].listRooms[0].players[0].isMuted).to.equal(false);
                    expect(service['roomStorage'].listRooms[0].players[1].isMuted).to.equal(false);
                    expect(service['roomStorage'].listRooms[0].players[2].isMuted).to.equal(true);
                    done();
                });
            });
        });
    });

    it('should emit errorFindingRoom when player is not in a room', (done) => {
        clientSocket.emit(ChatEvent.TOOGLE_MUTE_PLAYER, 'nonExistingPlayerId');

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });
});
