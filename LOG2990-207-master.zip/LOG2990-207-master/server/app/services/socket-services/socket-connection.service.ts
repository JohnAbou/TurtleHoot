import { RoomStorage } from '@app/classes/room-storage';
import { QuizService } from '@app/services/controller-services/quiz.service';
import { ACCESS_CODE_SIZE, ID_ROOM_SIZE } from '@common/constants';
import { ChatEvent, ConnectionEvent, ErrorSocketEvent } from '@common/event-name';
import { AnswerState, Player, PlayerState } from '@common/player';
import { JoinRoom, KickingPlayer, PlayerAnswerQcm, PlayerAnswerQrl, Room } from '@common/room';
import { Message } from '@common/user-message';
import { customAlphabet } from 'nanoid';
import * as io from 'socket.io';
import { Socket } from 'socket.io';
import { SocketAnswerManager } from './socket-answer.service';

export class SocketConnectionManager {
    private roomStorage: RoomStorage;

    constructor(
        private readonly sio: io.Server,
        private socketAnswerManager: SocketAnswerManager,
        private quizService: QuizService,
    ) {
        this.roomStorage = RoomStorage.getInstance();
    }

    handleSockets(): void {
        this.sio.on(ConnectionEvent.CONNECTION, (socket) => {
            socket.on(ConnectionEvent.CREATE_GAME, (quizId: string) => {
                const room = {
                    id: this.generateId(ID_ROOM_SIZE),
                    accessCode: this.generateId(ACCESS_CODE_SIZE),
                    players: [] as Player[],
                    quizId,
                    hasStarted: false,
                    messages: [] as Message[],
                    bannedUsernames: [] as string[],
                    isLocked: false,
                    playerQcmAnswers: [] as PlayerAnswerQcm[],
                    playerQrlAnswers: [] as PlayerAnswerQrl[],
                    selectedAnswers: [] as number[][],
                };
                this.roomStorage.listRooms.push(room);
                socket.emit(ConnectionEvent.GAME_CREATED, room.accessCode);
            });

            socket.on(ConnectionEvent.CREATE_TEST_GAME, (quizId: string) => {
                const room = {
                    id: socket.id,
                    accessCode: socket.id,
                    players: [] as Player[],
                    quizId,
                    hasStarted: false,
                    messages: [] as Message[],
                    bannedUsernames: [] as string[],
                    isLocked: false,
                    playerQcmAnswers: [] as PlayerAnswerQcm[],
                    playerQrlAnswers: [] as PlayerAnswerQrl[],
                    selectedAnswers: [] as number[][],
                };
                this.roomStorage.listRooms.push(room);
                const newPlayer = {
                    id: socket.id,
                    username: 'Testeur',
                    role: PlayerState.Player,
                    points: 0,
                    nBonus: 0,
                    answerState: AnswerState.default,
                    isMuted: false,
                };
                room.players.push(newPlayer);
                socket.join(room.id);
                socket.emit(ConnectionEvent.TEST_GAME_CREATED);
            });

            socket.on(ConnectionEvent.JOIN_ROOM, (client: JoinRoom) => {
                const clientRoom = this.roomStorage.listRooms.find((room) => room.accessCode === client.accessCode);
                if (clientRoom && clientRoom.accessCode === client.accessCode) {
                    if (clientRoom.hasStarted) {
                        socket.emit(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, 'La partie a déjà commencé! Impossible de rejoindre la salle de jeu.');
                    } else if (clientRoom.isLocked) {
                        socket.emit(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, 'Cette salle de jeu est vérouillée.');
                    } else if (
                        client.username.toLowerCase() === 'organisateur' ||
                        clientRoom.players.some((player) => player.username.toLowerCase() === client.username.toLowerCase())
                    ) {
                        socket.emit(
                            ErrorSocketEvent.ERROR_CONNECTIONG_GAME,
                            "Le nom d'utilisateur est déjà utilisé dans cette salle de jeu. Veuillez en choisir un autre.",
                        );
                    } else if (clientRoom.bannedUsernames.includes(client.username.toLowerCase())) {
                        socket.emit(
                            ErrorSocketEvent.ERROR_CONNECTIONG_GAME,
                            "Le nom d'utilisateur n'est pas permis dans cette salle de jeu. Veuillez en choisir un autre.",
                        );
                    } else {
                        const newPlayer = {
                            id: socket.id,
                            username: client.username,
                            role: PlayerState.Player,
                            points: 0,
                            nBonus: 0,
                            answerState: AnswerState.default,
                            isMuted: false,
                        };
                        clientRoom.players.push(newPlayer);
                        socket.join(clientRoom.id);
                        socket.emit(ConnectionEvent.PLAYER_JOINED);
                        socket.to(clientRoom.id).emit(ConnectionEvent.OTHER_PLAYER_JOINED, newPlayer);
                    }
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, "La salle de jeu n'existe pas. Veuillez vérifier le code d'accès.");
                }
            });
            socket.on(ConnectionEvent.LEAVE_ROOM, () => {
                this.leaveRoom(socket);
            });

            socket.on(ConnectionEvent.IS_ORGANIZER, (gameId: string) => {
                let isOrganizer = false;
                const clientRoom = this.roomStorage.listRooms.find((room) => room.accessCode === gameId);
                if (clientRoom) {
                    if (clientRoom.players.length === 0) {
                        clientRoom.players.push({
                            id: socket.id,
                            username: 'Organisateur',
                            role: PlayerState.Organizer,
                            points: 0,
                            nBonus: 0,
                            answerState: AnswerState.hasAnswered,
                            isMuted: false,
                        });

                        socket.join(clientRoom.id);
                        isOrganizer = true;
                        socket.emit(ConnectionEvent.PLAYER_ACCESS, isOrganizer);
                    }
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(ConnectionEvent.KICK_PLAYER, (kickedPlayer: KickingPlayer) => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === kickedPlayer.socketId));
                if (!playerRoom) {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                    return;
                }
                const isPlayerInRoom = playerRoom.players.some((player) => player.id === kickedPlayer.socketId);
                if (playerRoom && isPlayerInRoom) {
                    playerRoom.players = playerRoom.players.filter((player) => player.id !== kickedPlayer.socketId);
                    const playerSocket = this.sio.sockets.sockets.get(kickedPlayer.socketId);

                    if (playerSocket) {
                        playerSocket.emit(ConnectionEvent.KICKED);
                        playerSocket.leave(playerRoom.id);
                    }
                    this.sio.to(playerRoom.id).emit(ConnectionEvent.PLAYER_KICKED, kickedPlayer.socketId);
                    playerRoom.bannedUsernames.push(kickedPlayer.username.toLowerCase());
                }
            });

            socket.on(ConnectionEvent.DISCONNECT, () => {
                this.leaveRoom(socket);
            });
        });
    }

    private generateId(size: number) {
        let isUnique = false;
        let uniqueAccessCode = '';
        while (!isUnique) {
            const nanoid = customAlphabet('0123456789', size);
            uniqueAccessCode = nanoid();
            const existingRoom = this.roomStorage.listRooms.find((room) => room.accessCode === uniqueAccessCode);
            if (!existingRoom) {
                isUnique = true;
            }
        }
        return uniqueAccessCode;
    }

    private leaveRoom(socket: Socket) {
        const clientRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
        if (clientRoom) {
            const leavingPlayer = clientRoom.players.find((player) => player.id === socket.id);
            clientRoom.players = clientRoom.players.filter((player) => player.id !== socket.id);
            socket.leave(clientRoom.id);
            if (leavingPlayer.role === PlayerState.Organizer) {
                this.handleOrganizerLeft(clientRoom);
            } else {
                this.handlePlayerLeft(clientRoom, socket, leavingPlayer);
            }
            if (clientRoom.players.length === 0) {
                this.handleEmptyRoom(clientRoom);
            }
        }
    }

    private handleOrganizerLeft(clientRoom: Room) {
        this.sio.to(clientRoom.id).emit(ConnectionEvent.ORGANIZER_LEFT);
    }

    private handlePlayerLeft(clientRoom: Room, socket: Socket, leavingPlayer: Player) {
        const message: Message = {
            socketId: 'server',
            username: leavingPlayer.username,
            text: ' a quitté la partie',
            time: new Date().toLocaleTimeString(),
        };
        clientRoom.messages.push(message);
        this.sio.to(clientRoom.id).emit(ConnectionEvent.PLAYER_LEFT, leavingPlayer.id);
        this.sio.to(clientRoom.id).emit(ChatEvent.ROOM_MESSAGE, message);
        if (clientRoom.players.length > 1) {
            this.socketAnswerManager.removeAnswer(clientRoom, socket.id);
            this.socketAnswerManager.handleAnswers(clientRoom);
        }
    }

    private handleEmptyRoom(clientRoom: Room) {
        if (typeof clientRoom.quizId === 'string' && clientRoom.quizId.includes('-random')) {
            this.quizService.deleteQuiz(clientRoom.quizId);
        }
        this.roomStorage.listRooms = this.roomStorage.listRooms.filter((room) => room.accessCode !== clientRoom.accessCode);
        this.roomStorage.roomTimers.delete(clientRoom.id);
    }
}
