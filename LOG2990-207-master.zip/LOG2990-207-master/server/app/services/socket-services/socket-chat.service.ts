import { RoomStorage } from '@app/classes/room-storage';
import { ChatEvent, ConnectionEvent, ErrorSocketEvent } from '@common/event-name';
import { Message } from '@common/user-message';
import * as io from 'socket.io';

export class SocketChatManager {
    private roomStorage: RoomStorage;
    constructor(private readonly sio: io.Server) {
        this.roomStorage = RoomStorage.getInstance();
    }

    handleSockets(): void {
        this.sio.on(ConnectionEvent.CONNECTION, (socket) => {
            socket.on(ChatEvent.ROOM_MESSAGE, (messageContent: string) => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (playerRoom) {
                    const sender = playerRoom.players.find((player) => player.id === socket.id);
                    const data: Message = {
                        socketId: socket.id,
                        username: sender.username,
                        text: messageContent,
                        time: new Date().toLocaleTimeString(),
                    };
                    playerRoom.messages.push(data);
                    this.sio.to(playerRoom.id).emit(ChatEvent.ROOM_MESSAGE, data);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(ChatEvent.GET_ROOM_MESSAGES, () => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (playerRoom) {
                    socket.emit(ChatEvent.GET_ROOM_MESSAGES, playerRoom.messages);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(ChatEvent.TOOGLE_MUTE_PLAYER, (playerId: string) => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (playerRoom) {
                    const player = playerRoom.players.find((p) => p.id === playerId);
                    player.isMuted = !player.isMuted;
                    const playerSocket = this.sio.sockets.sockets.get(player.id);
                    playerSocket.emit(ChatEvent.TOOGLE_MUTE_PLAYER, player.isMuted);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });
        });
    }
}
