import { BASE_URL, MOCK_ROOM, TEST_PARAMETERS } from '@common/constants';
import { ConnectionEvent, ErrorSocketEvent, GameEvent } from '@common/event-name';
import { AnswerState, Player, PlayerState } from '@common/player';
import { Room } from '@common/room';
import { Server } from 'app/server';
import { expect } from 'chai';
import * as sinon from 'sinon';
import { Socket, io as ioClient } from 'socket.io-client';
import { Container } from 'typedi';
import { SocketGameManager } from './socket-game.service';

describe('SocketGameManager service tests', () => {
    let service: SocketGameManager;
    let server: Server;
    let clientSocket: Socket;
    let mockRoom: Room;

    beforeEach(async () => {
        server = Container.get(Server);
        server.init();
        await new Promise((resolve) => setTimeout(resolve, TEST_PARAMETERS.testDelay));
        service = server['socketGameManager'];
        clientSocket = ioClient(BASE_URL);
        service['roomStorage'].listRooms = [];
        mockRoom = JSON.parse(JSON.stringify(MOCK_ROOM));
    });

    afterEach(async () => {
        await new Promise<void>((resolve) => {
            clientSocket.close();
            service['sio'].close(() => {
                resolve();
            });
        });
        sinon.restore();
    });

    it('should emit accessToGame as true when player has access to the game', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'a' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(GameEvent.VERIFY_ACCESS_TO_GAME, mockRoom.accessCode);

            clientSocket.on(GameEvent.ACCESS_TO_GAME, (hasAccess: boolean) => {
                expect(hasAccess).to.equal(true);
                done();
            });
        });
    });

    it('should emit accessToGame as false when player is not in room', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(GameEvent.VERIFY_ACCESS_TO_GAME, mockRoom.accessCode);

        clientSocket.on(GameEvent.ACCESS_TO_GAME, (hasAccess: boolean) => {
            expect(hasAccess).to.equal(false);
            done();
        });
    });

    it('should emit accessToGame as false when room does not exist', (done) => {
        clientSocket.emit(GameEvent.VERIFY_ACCESS_TO_GAME, 'nonExistingGameId');

        clientSocket.on(GameEvent.ACCESS_TO_GAME, (hasAccess: boolean) => {
            expect(hasAccess).to.equal(false);
            done();
        });
    });

    it('should emit username to client when receiving getUsername event', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'a' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(GameEvent.GET_USERNAME);

            clientSocket.on(GameEvent.GET_USERNAME, (receivedUsername: string) => {
                expect(receivedUsername).to.equal(MOCK_CLIENT.username);
                done();
            });
        });
    });

    it('should emit errorFindingPlayer when player does not exist on getUsername', (done) => {
        clientSocket.emit(GameEvent.GET_USERNAME);

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_PLAYER, () => {
            done();
        });
    });

    it('should emit quizId to client when receiving getQuizId event', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(GameEvent.GET_QUIZ, mockRoom.accessCode);

        clientSocket.on(GameEvent.GET_QUIZ, (receivedQuizId: string) => {
            expect(receivedQuizId).to.equal(mockRoom.quizId);
            done();
        });
    });

    it('should emit errorFindingRoom when room does not exist on getQuizId', (done) => {
        clientSocket.emit(GameEvent.GET_QUIZ, 'nonExistingGameId');

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should toggle isLocked of a room', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(GameEvent.TOOGLE_LOCK, { gameId: mockRoom.accessCode, isLocked: true });

        setTimeout(() => {
            expect(mockRoom.isLocked).to.equal(true);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });

    it('should emit errorFindingRoom when room does not exist on toggleLock', (done) => {
        clientSocket.emit(GameEvent.TOOGLE_LOCK, 'nonExistingGameId');

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should emit room players to client when receiving getRoomPlayers event', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(GameEvent.GET_ROOM_PLAYERS, mockRoom.accessCode);

        clientSocket.on(GameEvent.GET_ROOM_PLAYERS, (players: Player[]) => {
            expect(players).to.deep.equal(mockRoom.players);
            done();
        });
    });

    it('should emit errorFindingRoom when room does not exist on getRoomPlayers', (done) => {
        clientSocket.emit(GameEvent.GET_ROOM_PLAYERS, 'nonExistingGameId');

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should emit gameStart to client when receiving startGame event', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'a' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(GameEvent.START_GAME, mockRoom.accessCode);

            clientSocket.on(GameEvent.START_GAME, () => {
                done();
            });
        });
    });

    it('should emit errorFindingRoom to client when receiving startGame event with invalid game Id', (done) => {
        clientSocket.emit(GameEvent.START_GAME, 'nonExistingGameId');

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should change organizer to player when receiving changeToPlayer event', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'a' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(GameEvent.CHANGE_TO_PLAYER);

            setTimeout(() => {
                expect(service['roomStorage'].listRooms[0].players[0].role).to.equal(PlayerState.Player);
                expect(service['roomStorage'].listRooms[0].players[0].answerState).to.equal(AnswerState.default);
                done();
            }, TEST_PARAMETERS.responseDelay);
        });
    });

    it('should emit errorFindingPlayer to client when receiving changeToPlayer event when not in a room', (done) => {
        clientSocket.emit(GameEvent.CHANGE_TO_PLAYER);

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_PLAYER, () => {
            done();
        });
    });
});
