import { BASE_URL, MOCK_ROOM, TEST_PARAMETERS } from '@common/constants';
import { ConnectionEvent, PanicModeEvent } from '@common/event-name';
import { Room } from '@common/room';
import { Server } from 'app/server';
import { expect } from 'chai';
import * as sinon from 'sinon';
import { Socket, io as ioClient } from 'socket.io-client';
import { Container } from 'typedi';
import { SocketPanicModeManager } from './socket-panic-mode.service';

describe('SocketPanicModeManager service tests', () => {
    let service: SocketPanicModeManager;
    let server: Server;
    let clientSocket: Socket;
    let mockRoom: Room;

    beforeEach(async () => {
        server = Container.get(Server);
        server.init();
        await new Promise((resolve) => setTimeout(resolve, TEST_PARAMETERS.testDelay));
        service = server['socketPanicModeManager'];
        clientSocket = ioClient(BASE_URL);
        service['roomStorage'].listRooms = [];
        service['roomStorage'].roomTimers = new Map<string, { intervalId: number }>();
        mockRoom = JSON.parse(JSON.stringify(MOCK_ROOM));
    });

    afterEach(async () => {
        await new Promise<void>((resolve) => {
            clientSocket.close();
            service['sio'].close(() => {
                resolve();
            });
        });
        sinon.restore();
    });

    it('should start panic mode when receiving startPanicMode event', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(PanicModeEvent.START_PANIC_MODE, mockRoom.accessCode);

        setTimeout(() => {
            expect(service['roomStorage'].roomTimers.has(mockRoom.id)).to.equal(true);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });

    it('should not start panic mode if clientRoom is not found', (done) => {
        const nonExistingAccessCode = 'nonExistingAccessCode';
        clientSocket.emit(PanicModeEvent.START_PANIC_MODE, nonExistingAccessCode);

        setTimeout(() => {
            expect(service['roomStorage'].roomTimers.has(nonExistingAccessCode)).to.equal(false);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });

    it('should emit panicCountdownUpdated to client room when panic countdown updates', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'a' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(PanicModeEvent.START_PANIC_MODE, mockRoom.accessCode);

            clientSocket.on(PanicModeEvent.PANIC_COUNTDOWN_UPDATED, () => {
                done();
            });
        });
    });
});
