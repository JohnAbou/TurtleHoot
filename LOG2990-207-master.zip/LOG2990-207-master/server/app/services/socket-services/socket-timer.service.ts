import { RoomStorage } from '@app/classes/room-storage';
import { TIMER_TICK_DELAY } from '@common/constants';
import { ConnectionEvent, TimerEvent } from '@common/event-name';
import * as io from 'socket.io';

export class SocketTimerManager {
    private roomStorage: RoomStorage;
    constructor(private readonly sio: io.Server) {
        this.roomStorage = RoomStorage.getInstance();
    }

    handleSockets(): void {
        this.sio.on(ConnectionEvent.CONNECTION, (socket) => {
            socket.on(TimerEvent.START_TIMER, (accessCode: string) => {
                const clientRoom = this.roomStorage.listRooms.find((room) => room.accessCode === accessCode);
                if (clientRoom) {
                    const roomTimer = this.roomStorage.roomTimers.get(clientRoom.id);
                    if (roomTimer) {
                        clearInterval(roomTimer.intervalId);
                    }
                    const newIntervalId = setInterval(() => {
                        if (!this.roomStorage.roomTimers.has(clientRoom.id)) {
                            clearInterval(newIntervalId);
                            return;
                        }

                        this.sio.to(clientRoom.id).emit(TimerEvent.TIMER_TICK);
                    }, TIMER_TICK_DELAY);
                    this.roomStorage.roomTimers.set(clientRoom.id, { intervalId: newIntervalId as unknown as number });
                }
            });

            socket.on(TimerEvent.STOP_TIMER, (accessCode: string) => {
                const clientRoom = this.roomStorage.listRooms.find((room) => room.accessCode === accessCode);
                if (clientRoom) {
                    const roomTimer = this.roomStorage.roomTimers.get(clientRoom.id);
                    if (roomTimer) {
                        clearInterval(roomTimer.intervalId);
                        this.roomStorage.roomTimers.delete(clientRoom.id);
                    }
                }
            });
        });
    }
}
