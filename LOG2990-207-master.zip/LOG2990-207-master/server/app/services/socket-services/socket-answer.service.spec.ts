import { BASE_URL, BONUS_MULTIPLIER, MOCK_QUESTION, MOCK_QUIZ, MOCK_ROOM, SELECT_VALUE, TEST_PARAMETERS } from '@common/constants';
import { AnswerEvent, ConnectionEvent, ErrorSocketEvent } from '@common/event-name';
import { GRADE, Grade } from '@common/grade';
import { AnswerState, Player, PlayerState } from '@common/player';
import { AnswerChoice } from '@common/quiz';
import { Room } from '@common/room';
import { Server } from 'app/server';
import { expect } from 'chai';
import * as sinon from 'sinon';
import { Socket, io as ioClient } from 'socket.io-client';
import { Container } from 'typedi';
import { SocketAnswerManager } from './socket-answer.service';
describe('SocketAnswerManager service tests', () => {
    let service: SocketAnswerManager;
    let server: Server;
    let clientSocket: Socket;
    let mockRoom: Room;

    beforeEach(async () => {
        server = Container.get(Server);
        server.init();
        await new Promise((resolve) => setTimeout(resolve, TEST_PARAMETERS.testDelay));
        service = server['socketAnswerManager'];
        clientSocket = ioClient(BASE_URL);
        service['roomStorage'].listRooms = [];
        mockRoom = JSON.parse(JSON.stringify(MOCK_ROOM));
        mockRoom.players = [];
    });

    afterEach(async () => {
        await new Promise<void>((resolve) => {
            clientSocket.close();
            service['sio'].close(() => {
                resolve();
            });
        });
        sinon.restore();
    });

    it('should update player points when all players answered', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        const playerSocket = ioClient(BASE_URL);
        playerSocket.emit(ConnectionEvent.JOIN_ROOM, { accessCode: '1234', username: 'a' });
        playerSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            const playerSocket2 = ioClient(BASE_URL);
            playerSocket2.emit(ConnectionEvent.JOIN_ROOM, { accessCode: '1234', username: 'b' });
            playerSocket2.on(ConnectionEvent.PLAYER_JOINED, () => {
                clientSocket.emit(ConnectionEvent.JOIN_ROOM, { accessCode: '1234', username: 'albert' });
                clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
                    service['roomStorage'].listRooms[0].players.push({
                        id: '1234',
                        username: 'Organisateur',
                        role: PlayerState.Organizer,
                        points: 0,
                        nBonus: 0,
                        answerState: AnswerState.hasAnswered,
                        isMuted: false,
                    });
                    playerSocket.emit(AnswerEvent.VALIDATE_QCM_ANSWER, {
                        timeLeft: 0,
                        question: MOCK_QUESTION,
                        // L'index des boutons sélectionnés est l'index des choix dans la question
                        // eslint-disable-next-line @typescript-eslint/naming-convention
                        buttonsSelected: { 0: null, 1: false },
                    });
                    playerSocket2.emit(AnswerEvent.VALIDATE_QCM_ANSWER, {
                        timeLeft: 40,
                        question: MOCK_QUESTION,
                        // eslint-disable-next-line @typescript-eslint/naming-convention
                        buttonsSelected: { 0: true, 1: false },
                    });

                    clientSocket.emit(AnswerEvent.VALIDATE_QCM_ANSWER, {
                        timeLeft: 50,
                        question: MOCK_QUESTION,
                        // eslint-disable-next-line @typescript-eslint/naming-convention
                        buttonsSelected: { 0: true, 1: false },
                    });

                    clientSocket.on(AnswerEvent.ALL_PLAYERS_ANSWERED, () => {
                        expect(service['roomStorage'].listRooms[0].players[0].points).to.deep.equal(0);
                        expect(service['roomStorage'].listRooms[0].players[1].points).to.deep.equal(MOCK_QUESTION.points);
                        expect(service['roomStorage'].listRooms[0].players[2].points).to.deep.equal(MOCK_QUESTION.points * BONUS_MULTIPLIER);
                        done();
                    });
                });
            });
        });
    });

    it('should not update player points when all players answered', (done) => {
        const timeLeft = 50;
        // L'index des boutons sélectionnés est l'index des choix dans la question
        // eslint-disable-next-line @typescript-eslint/naming-convention
        const buttonsSelected = { 0: false, 1: false };
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(AnswerEvent.VALIDATE_QCM_ANSWER, { timeLeft, question: MOCK_QUESTION, buttonsSelected });

            clientSocket.on(AnswerEvent.ALL_PLAYERS_ANSWERED, () => {
                expect(service['roomStorage'].listRooms[0].players[0].points).to.deep.equal(0);
                done();
            });
        });
    });

    it('should emit errorFindingRoom if user not in room', (done) => {
        clientSocket.emit(AnswerEvent.VALIDATE_QCM_ANSWER, { timeLeft: 50, question: MOCK_QUESTION, buttonsSelected: {} });
        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should emit questionEnded event and reset playerAnswers when endQuestion event is received', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        service['roomStorage'].listRooms.push(mockRoom);

        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(AnswerEvent.END_QUESTION);

            clientSocket.on(AnswerEvent.QUESTION_ENDED, () => {
                done();
            });
        });
    });

    it('should emit errorFindingRoom event when room does not exist', (done) => {
        clientSocket.emit(AnswerEvent.END_QUESTION);

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should emit roomAnswers event when getRoomAnswers event is received', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        mockRoom.selectedAnswers = [
            [1, 0, 0],
            [0, 1, 0],
            [0, 0, 1],
        ];
        service['roomStorage'].listRooms.push(mockRoom);

        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(AnswerEvent.GET_ROOM_ANSWERS);

            clientSocket.on(AnswerEvent.ROOM_ANSWERS, (roomAnswers: number[][]) => {
                expect(roomAnswers).to.deep.equal(mockRoom.selectedAnswers);
                done();
            });
        });
    });

    it('should emit errorFindingRoom event when room does not exist', (done) => {
        clientSocket.emit(AnswerEvent.GET_ROOM_ANSWERS);

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should update selectedAnswers when choiceSelected event is emitted', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            const organizerId = 'organizerSocketId';
            const questionIndex = 0;
            const choiceIndex = 1;
            const isSelected = true;
            const choicesLength = 3;
            const findStub = sinon.stub(mockRoom.players, 'find');
            findStub.returns({
                id: organizerId,
                username: 'Organisateur',
                role: PlayerState.Organizer,
                points: 0,
                nBonus: 0,
                answerState: AnswerState.hasAnswered,
                isMuted: false,
            });
            clientSocket.emit(AnswerEvent.CHOICE_SELECTED, { questionIndex, choiceIndex, isSelected, choicesLength });

            setTimeout(() => {
                expect(service['roomStorage'].listRooms[0].selectedAnswers[questionIndex][choiceIndex]).to.equal(SELECT_VALUE);
                done();
            }, TEST_PARAMETERS.responseDelay);
        });
    });

    it('should emit errorFindingRoom if user not in room when choiceSelected event is emitted', (done) => {
        clientSocket.emit(AnswerEvent.CHOICE_SELECTED, { questionIndex: 0, choiceIndex: 1, isSelected: true, choicesLength: 3 });

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should emit evaluationInProgress and playerQrlAnswers to the room when startEvaluation is received', (done) => {
        const playerSocket = ioClient(BASE_URL);
        const organizerSocket = ioClient(BASE_URL);
        service['roomStorage'].listRooms.push(mockRoom);

        playerSocket.emit(ConnectionEvent.JOIN_ROOM, { accessCode: '1234', username: 'player' });

        playerSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            organizerSocket.emit(ConnectionEvent.JOIN_ROOM, { accessCode: '1234', username: 'organizer' });
            organizerSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
                organizerSocket.emit(AnswerEvent.START_EVALUATION);
                playerSocket.on(AnswerEvent.EVALUATION_IN_PROGRESS, () => {
                    playerSocket.on(AnswerEvent.PLAYER_QRL_ANSWERS, (playerQrlAnswers: unknown) => {
                        expect(playerQrlAnswers).to.deep.equal(service['roomStorage'].listRooms[0].playerQrlAnswers);
                        done();
                    });
                });
            });
        });
    });

    it('should emit errorFindingRoom event when room does not exist', (done) => {
        clientSocket.emit(AnswerEvent.START_EVALUATION);

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should update player answer state, selected answers, and emit events on player interaction', (done) => {
        const playerSocket = ioClient(BASE_URL);
        service['roomStorage'].listRooms.push(mockRoom);

        playerSocket.emit(ConnectionEvent.JOIN_ROOM, { accessCode: '1234', username: 'player' });
        playerSocket.emit(AnswerEvent.PLAYER_INTERACTED, 0);

        playerSocket.on(AnswerEvent.PLAYER_ANSWER_SATE_CHANGED, (players: Player[]) => {
            const player = players.find((p: Player) => p.id === playerSocket.id);
            expect(player.answerState).to.equal(AnswerState.hasInteracted);

            playerSocket.on(AnswerEvent.INTEREACTIONS_CHANGED, (data: AnswerChoice) => {
                if (data.index === 0) {
                    expect(data.newChoice).to.equal(1);
                } else if (data.index === 1) {
                    expect(data.newChoice).to.equal(mockRoom.players.length - 2);
                    done();
                }
            });
        });
    });
    it('should emit errorFindingRoom event when room does not exist', (done) => {
        clientSocket.emit(AnswerEvent.PLAYER_INTERACTED);

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });
    it('should update selected answers, decrement chosen answer, and emit interaction changes on player afk', (done) => {
        const playerSocket = ioClient(BASE_URL);
        service['roomStorage'].listRooms.push(mockRoom);

        playerSocket.emit(ConnectionEvent.JOIN_ROOM, { accessCode: '1234', username: 'player' });

        playerSocket.emit(AnswerEvent.PLAYER_AFK, 0);
        playerSocket.on(AnswerEvent.INTEREACTIONS_CHANGED, (data: AnswerChoice) => {
            if (data.index === 0) {
                expect(data.newChoice).to.equal(mockRoom.players.length - 2);
            } else if (data.index === 1) {
                expect(data.newChoice).to.equal(1);
                done();
            }
        });
    });
    it('should emit errorFindingRoom event when room does not exist', (done) => {
        clientSocket.emit(AnswerEvent.PLAYER_AFK);

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });
    it('should update player points when finishedCorrecting event is received', (done) => {
        const questionIndex = 0;
        const questionValue = 10;
        service['roomStorage'].listRooms.push(mockRoom);
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            const grades: Grade[] = [
                { playerId: service['roomStorage'].listRooms[0].players[0].id, points: GRADE.half_grade },
                { playerId: service['roomStorage'].listRooms[0].players[0].id, points: GRADE.full_grade },
                { playerId: service['roomStorage'].listRooms[0].players[0].id, points: 0 },
            ];
            clientSocket.emit(AnswerEvent.FINISHED_CORRECTING, { grades, questionIndex, questionValue });

            clientSocket.on(AnswerEvent.EVALUATION_FINISHED, () => {
                expect(service['roomStorage'].listRooms[0].players[0].points).to.equal(
                    (GRADE.half_grade * questionValue) / GRADE.decimal_divider + questionValue,
                );
                done();
            });
        });
    });
    it('should not update player points when finishedCorrecting event is received if player does not exist', (done) => {
        const questionIndex = 0;
        const questionValue = 10;
        service['roomStorage'].listRooms.push(mockRoom);
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            const grades: Grade[] = [{ playerId: 'noExistingId', points: GRADE.half_grade }];
            clientSocket.emit(AnswerEvent.FINISHED_CORRECTING, { grades, questionIndex, questionValue });

            clientSocket.on(AnswerEvent.EVALUATION_FINISHED, () => {
                expect(service['roomStorage'].listRooms[0].players[0].points).to.not.equal(
                    (GRADE.half_grade * questionValue) / GRADE.decimal_divider + questionValue,
                );
                done();
            });
        });
    });
    it('should emit errorFindingRoom event when room does not exist', (done) => {
        clientSocket.emit(AnswerEvent.FINISHED_CORRECTING);

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });
    it('should validate QRL answer correctly', (done) => {
        const timeLeft = 10;
        const answer = '';
        service['roomStorage'].listRooms.push(mockRoom);
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(AnswerEvent.VALIDATE_QRL_ANSWER, { timeLeft, question: MOCK_QUIZ.questions[2], answer });

            setTimeout(() => {
                expect(service['roomStorage'].listRooms[0].playerQrlAnswers[0]).to.deep.equal({
                    text: answer,
                    questionValue: MOCK_QUIZ.questions[2].points,
                    playerId: service['roomStorage'].listRooms[0].players[0].id,
                    username: MOCK_CLIENT.username,
                });
                done();
            }, TEST_PARAMETERS.responseDelay);
        });
    });
});
