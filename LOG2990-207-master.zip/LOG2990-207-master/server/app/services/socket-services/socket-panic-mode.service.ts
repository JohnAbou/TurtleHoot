import { RoomStorage } from '@app/classes/room-storage';
import { PANIC_MODE_INTERVAL } from '@common/constants';
import { ConnectionEvent, PanicModeEvent } from '@common/event-name';
import * as io from 'socket.io';
export class SocketPanicModeManager {
    private roomStorage: RoomStorage;
    constructor(private readonly sio: io.Server) {
        this.roomStorage = RoomStorage.getInstance();
    }

    handleSockets(): void {
        this.sio.on(ConnectionEvent.CONNECTION, (socket) => {
            socket.on(PanicModeEvent.START_PANIC_MODE, (accessCode: string) => {
                const clientRoom = this.roomStorage.listRooms.find((room) => room.accessCode === accessCode);
                if (clientRoom) {
                    const roomTimer = this.roomStorage.roomTimers.get(clientRoom.id);
                    if (roomTimer) {
                        clearInterval(roomTimer.intervalId);
                    }
                    const newIntervalId = setInterval(() => {
                        if (!this.roomStorage.roomTimers.has(clientRoom.id)) {
                            clearInterval(newIntervalId);
                            return;
                        }
                        this.sio.to(clientRoom.id).emit(PanicModeEvent.PANIC_COUNTDOWN_UPDATED);
                    }, PANIC_MODE_INTERVAL);
                    this.roomStorage.roomTimers.set(clientRoom.id, { intervalId: newIntervalId as unknown as number });
                }
            });
        });
    }
}
