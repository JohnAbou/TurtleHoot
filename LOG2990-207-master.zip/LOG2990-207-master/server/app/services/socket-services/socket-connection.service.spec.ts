import { BASE_URL, MOCK_ROOM, TEST_PARAMETERS } from '@common/constants';
import { ConnectionEvent, ErrorSocketEvent } from '@common/event-name';
import { AnswerState, PlayerState } from '@common/player';
import { Quiz } from '@common/quiz';
import { Room } from '@common/room';
import { Server } from 'app/server';
import { expect } from 'chai';
import * as sinon from 'sinon';
import { Socket, io as ioClient } from 'socket.io-client';
import { Container } from 'typedi';
import { SocketConnectionManager } from './socket-connection.service';

describe('SocketConnectionManager service tests', () => {
    let service: SocketConnectionManager;
    let server: Server;
    let clientSocket: Socket;
    let mockRoom: Room;

    beforeEach(async () => {
        server = Container.get(Server);
        server.init();
        await new Promise((resolve) => setTimeout(resolve, TEST_PARAMETERS.testDelay));

        service = server['socketConnectionManager'];

        service['socketAnswerManager'] = {
            removeAnswer: () => {
                return;
            },
            handleAnswers: () => {
                return;
            },
            // On veut mock ces methodes sans devoir mock toutes les methodes de la classe
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
        } as any;
        clientSocket = ioClient(BASE_URL);
        service['roomStorage'].listRooms = [];
        mockRoom = JSON.parse(JSON.stringify(MOCK_ROOM));
    });

    afterEach(async () => {
        await new Promise<void>((resolve) => {
            clientSocket.close();
            service['sio'].close(() => {
                resolve();
            });
        });
        sinon.restore();
    });

    it('should create a game room and emit gameCreated with access code', (done) => {
        const MOCK_QUIZ = {
            id: '1234',
            title: 'Questionnaire sur le JS',
            description: 'Questions de pratique sur le langage JavaScript',
            duration: 10,
            lastModification: '2018-11-13T20:20:39+00:00',
            questions: [],
        } as Quiz;

        clientSocket.emit(ConnectionEvent.CREATE_GAME, MOCK_QUIZ);

        clientSocket.on(ConnectionEvent.GAME_CREATED, (result: string) => {
            expect(result).to.equal(service['roomStorage'].listRooms[0].accessCode);
            expect(result).to.have.lengthOf(TEST_PARAMETERS.roomLength);
            done();
        });
    });

    it('should create a test game room and emit testGameCreated with access code', (done) => {
        const MOCK_QUIZ = {
            id: '1234',
            title: 'Questionnaire sur le JS',
            description: 'Questions de pratique sur le langage JavaScript',
            duration: 10,
            lastModification: '2018-11-13T20:20:39+00:00',
            questions: [],
        } as Quiz;

        clientSocket.emit(ConnectionEvent.CREATE_TEST_GAME, MOCK_QUIZ);

        clientSocket.on(ConnectionEvent.TEST_GAME_CREATED, () => {
            expect(service['roomStorage'].listRooms).to.have.lengthOf(1);
            expect(service['roomStorage'].listRooms[0].players).to.have.lengthOf(1);
            done();
        });
    });

    it('Should not allow player to join none existing room', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'bob' };
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);

        clientSocket.on(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, (result: string) => {
            expect(result).to.equal("La salle de jeu n'existe pas. Veuillez vérifier le code d'accès.");
            done();
        });
    });

    it('Should not allow player to join room where the game already started', (done) => {
        mockRoom.hasStarted = true;
        const MOCK_CLIENT = { accessCode: '1234', username: 'bob' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);

        clientSocket.on(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, (result: string) => {
            expect(result).to.equal('La partie a déjà commencé! Impossible de rejoindre la salle de jeu.');
            done();
        });
    });

    it('Should not allow player to join room that is locked', (done) => {
        mockRoom.isLocked = true;
        const MOCK_CLIENT = { accessCode: '1234', username: 'bob' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);

        clientSocket.on(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, (result: string) => {
            expect(result).to.equal('Cette salle de jeu est vérouillée.');
            done();
        });
    });

    it('Should not allow player to join a room with already used username', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'bob' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);

        clientSocket.on(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, (result: string) => {
            expect(result).to.equal("Le nom d'utilisateur est déjà utilisé dans cette salle de jeu. Veuillez en choisir un autre.");
            done();
        });
    });

    it('Should not allow player to join a room with already used username', (done) => {
        const username = 'banned';
        mockRoom.bannedUsernames.push(username);
        const MOCK_CLIENT = { accessCode: '1234', username };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);

        clientSocket.on(ErrorSocketEvent.ERROR_CONNECTIONG_GAME, (result: string) => {
            expect(result).to.equal("Le nom d'utilisateur n'est pas permis dans cette salle de jeu. Veuillez en choisir un autre.");
            done();
        });
    });

    it('Should allow player to join a room', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);

        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            expect(service['roomStorage'].listRooms[0].players).to.have.lengthOf(2);
            done();
        });
    });

    it('Should deny player access to lobby if they are not in the room', (done) => {
        let called = false;
        clientSocket.emit(ConnectionEvent.IS_ORGANIZER, mockRoom.accessCode);

        clientSocket.on(ConnectionEvent.PLAYER_ACCESS, () => {
            called = true;
        });

        setTimeout(() => {
            expect(called).to.equal(false);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });

    it('Should remove player from list of players when leaving', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        mockRoom.isLocked = false;
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);

        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(ConnectionEvent.LEAVE_ROOM, mockRoom.accessCode);

            setTimeout(() => {
                expect(service['roomStorage'].listRooms[0].players).to.have.lengthOf(1);
                expect(service['roomStorage'].listRooms).to.have.lengthOf(1);
                done();
            }, TEST_PARAMETERS.responseDelay);
        });
    });

    it('Should handle answers when a player leaves', (done) => {
        const removeAnswerSpy = sinon.spy(service['socketAnswerManager'], 'removeAnswer');
        const handleAnswersSpy = sinon.spy(service['socketAnswerManager'], 'handleAnswers');
        const MOCK_CLIENT = { accessCode: '1234', username: 'albert' };
        const mockPlayer1 = {
            id: '1',
            username: 'a',
            role: PlayerState.Player,
            points: 0,
            nBonus: 0,
            answerState: AnswerState.default,
            isMuted: false,
        };
        const mockPlayer2 = {
            id: '2',
            username: 'b',
            role: PlayerState.Player,
            points: 0,
            nBonus: 0,
            answerState: AnswerState.default,
            isMuted: false,
        };
        mockRoom.isLocked = false;
        service['roomStorage'].listRooms.push(mockRoom);
        service['roomStorage'].listRooms[0].players.push(mockPlayer1);
        service['roomStorage'].listRooms[0].players.push(mockPlayer2);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);

        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(ConnectionEvent.LEAVE_ROOM, mockRoom.accessCode);

            setTimeout(() => {
                expect(removeAnswerSpy.calledOnce).to.equal(true);
                expect(handleAnswersSpy.calledOnce).to.equal(true);
                done();
            }, TEST_PARAMETERS.responseDelay);
        });
    });

    it('should remove all players and delete room when organizer leaves', (done) => {
        mockRoom.isLocked = false;
        service['roomStorage'].listRooms.push(mockRoom);
        service['roomStorage'].listRooms[0].players = [];

        clientSocket.emit(ConnectionEvent.IS_ORGANIZER, mockRoom.accessCode);
        const playerSocket = ioClient(BASE_URL);
        const MOCK_CLIENT = { accessCode: '1234', username: 'player', role: PlayerState.Player };

        clientSocket.on(ConnectionEvent.PLAYER_ACCESS, () => {
            playerSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
            playerSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
                clientSocket.emit(ConnectionEvent.LEAVE_ROOM, mockRoom.accessCode);
                playerSocket.on(ConnectionEvent.ORGANIZER_LEFT, () => {
                    playerSocket.emit(ConnectionEvent.LEAVE_ROOM, mockRoom.accessCode);
                    setTimeout(() => {
                        expect(service['roomStorage'].listRooms).to.have.lengthOf(0);
                        done();
                    }, TEST_PARAMETERS.responseDelay);
                });
            });
        });
    });

    it('Should allow access to lobby and give Organizer role if room.players has length of 0', (done) => {
        let called = false;
        service['roomStorage'].listRooms.push(mockRoom);
        service['roomStorage'].listRooms[0].players = [];

        clientSocket.emit(ConnectionEvent.IS_ORGANIZER, mockRoom.accessCode);

        clientSocket.on(ConnectionEvent.PLAYER_ACCESS, () => {
            called = true;
        });

        setTimeout(() => {
            expect(called).to.equal(true);
            expect(service['roomStorage'].listRooms[0].players[0].role).to.equal(PlayerState.Organizer);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });
    it('should emit errorFindingRoom when player is not in room on kickPlayer', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'bob' };
        clientSocket.emit(ConnectionEvent.KICK_PLAYER, { username: MOCK_CLIENT.username, socketId: clientSocket.id });

        clientSocket.on(ErrorSocketEvent.ERROR_FINDING_ROOM, () => {
            done();
        });
    });

    it('should kick a player from the room and add their name to the banned list', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'bannedname' };
        mockRoom.isLocked = false;
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);

        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(ConnectionEvent.KICK_PLAYER, { username: MOCK_CLIENT.username, socketId: clientSocket.id });

            setTimeout(() => {
                expect(service['roomStorage'].listRooms[0].players).to.have.lengthOf(1);
                expect(service['roomStorage'].listRooms[0].bannedUsernames).to.include(MOCK_CLIENT.username);
                done();
            }, TEST_PARAMETERS.responseDelay);
        });
    });
});
