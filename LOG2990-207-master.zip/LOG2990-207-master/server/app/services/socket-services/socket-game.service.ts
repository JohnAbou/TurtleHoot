import { RoomStorage } from '@app/classes/room-storage';
import { ConnectionEvent, ErrorSocketEvent, GameEvent } from '@common/event-name';
import { AnswerState, PlayerState } from '@common/player';
import { LockingRoom } from '@common/room';
import * as io from 'socket.io';

export class SocketGameManager {
    private roomStorage: RoomStorage;
    constructor(private readonly sio: io.Server) {
        this.roomStorage = RoomStorage.getInstance();
    }

    handleSockets(): void {
        this.sio.on(ConnectionEvent.CONNECTION, (socket) => {
            socket.on(GameEvent.VERIFY_ACCESS_TO_GAME, (gameId: string) => {
                const clientRoom = this.roomStorage.listRooms.find((room) => room.accessCode === gameId);
                if (clientRoom && clientRoom.players.some((player) => player.id === socket.id)) {
                    socket.emit(GameEvent.ACCESS_TO_GAME, true);
                } else {
                    socket.emit(GameEvent.ACCESS_TO_GAME, false);
                }
            });
            socket.on(GameEvent.GET_ROOM_PLAYERS, (gameId: string) => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.accessCode === gameId);
                if (playerRoom) {
                    socket.emit(GameEvent.GET_ROOM_PLAYERS, playerRoom.players);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(GameEvent.GET_USERNAME, () => {
                const user = this.roomStorage.listRooms.flatMap((room) => room.players).find((player) => player.id === socket.id);
                if (user) {
                    socket.emit(GameEvent.GET_USERNAME, user.username);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_PLAYER);
                }
            });

            socket.on(GameEvent.GET_QUIZ, (gameId: string) => {
                const clientRoom = this.roomStorage.listRooms.find((room) => room.accessCode === gameId);
                if (clientRoom) {
                    socket.emit(GameEvent.GET_QUIZ, clientRoom.quizId);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(GameEvent.TOOGLE_LOCK, (data: LockingRoom) => {
                const clientRoom = this.roomStorage.listRooms.find((room) => room.accessCode === data.gameId);
                if (clientRoom) {
                    clientRoom.isLocked = data.isLocked;
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(GameEvent.START_GAME, (gameId: string) => {
                const clientRoom = this.roomStorage.listRooms.find((room) => room.accessCode === gameId);
                if (clientRoom) {
                    clientRoom.hasStarted = true;
                    this.sio.to(clientRoom.id).emit(GameEvent.START_GAME);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(GameEvent.CHANGE_TO_PLAYER, () => {
                const user = this.roomStorage.listRooms.flatMap((room) => room.players).find((player) => player.id === socket.id);
                if (user) {
                    user.role = PlayerState.Player;
                    user.answerState = AnswerState.default;
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_PLAYER);
                }
            });
        });
    }
}
