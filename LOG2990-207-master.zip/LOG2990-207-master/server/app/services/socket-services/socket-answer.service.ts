import { RoomStorage } from '@app/classes/room-storage';
import { ChoiceSelected, ChoiceValidateQcm, ChoiceValidateQrl, correctedChoice } from '@common/choice-answer';
import { BONUS_MULTIPLIER, SELECT_VALUE, UNSELECT_VALUE } from '@common/constants';
import { AnswerEvent, ConnectionEvent, ErrorSocketEvent, GameEvent } from '@common/event-name';
import { GRADE, Grade } from '@common/grade';
import { AnswerState, Player, PlayerState } from '@common/player';
import { AnswerChoice, Question, QuestionType } from '@common/quiz';
import { Room } from '@common/room';
import * as io from 'socket.io';
import { Socket } from 'socket.io';
export class SocketAnswerManager {
    private roomStorage: RoomStorage;
    constructor(private readonly sio: io.Server) {
        this.roomStorage = RoomStorage.getInstance();
    }

    handleSockets(): void {
        this.sio.on(ConnectionEvent.CONNECTION, (socket) => {
            socket.on(AnswerEvent.VALIDATE_QCM_ANSWER, (data: ChoiceValidateQcm) => {
                this.validateAnswer(socket, { timeLeft: data.timeLeft, question: data.question, answer: data.buttonsSelected });
            });

            socket.on(AnswerEvent.CHOICE_SELECTED, (data: ChoiceSelected) => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (playerRoom) {
                    playerRoom.players.find((player) => player.id === socket.id).answerState = AnswerState.hasInteracted;
                    if (!playerRoom.selectedAnswers[data.questionIndex]) {
                        playerRoom.selectedAnswers[data.questionIndex] = new Array(data.choicesLength).fill(0);
                    }
                    playerRoom.selectedAnswers[data.questionIndex][data.choiceIndex] += data.isSelected ? SELECT_VALUE : UNSELECT_VALUE;
                    this.sio.to(playerRoom.id).emit(AnswerEvent.PLAYER_ANSWER_SATE_CHANGED, playerRoom.players);
                    const dataChoice: AnswerChoice = {
                        index: data.choiceIndex,
                        newChoice: playerRoom.selectedAnswers[data.questionIndex][data.choiceIndex],
                    };
                    this.sio.to(playerRoom.id).emit(AnswerEvent.INTEREACTIONS_CHANGED, dataChoice);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(AnswerEvent.END_QUESTION, () => {
                const adminRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (adminRoom) {
                    this.sio.to(adminRoom.id).emit(AnswerEvent.QUESTION_ENDED);
                    adminRoom.playerQcmAnswers = [];
                    adminRoom.playerQrlAnswers = [];
                    adminRoom.players.forEach((player) => {
                        if (player.role !== PlayerState.Organizer) {
                            player.answerState = AnswerState.default;
                        }
                    });
                    this.sio.to(adminRoom.id).emit(AnswerEvent.PLAYER_ANSWER_SATE_CHANGED, adminRoom.players);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(AnswerEvent.GET_ROOM_ANSWERS, () => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (playerRoom) {
                    socket.emit(AnswerEvent.ROOM_ANSWERS, playerRoom.selectedAnswers);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(AnswerEvent.VALIDATE_QRL_ANSWER, (data: ChoiceValidateQrl) => {
                const dataAnswer: ChoiceValidateQrl = data;
                this.validateAnswer(socket, dataAnswer);
            });

            socket.on(AnswerEvent.START_EVALUATION, () => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (playerRoom) {
                    this.sio.to(playerRoom.id).emit(AnswerEvent.EVALUATION_IN_PROGRESS);
                    this.sio.to(playerRoom.id).emit(AnswerEvent.PLAYER_QRL_ANSWERS, playerRoom.playerQrlAnswers);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(AnswerEvent.PLAYER_INTERACTED, (questionIndex: number) => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (playerRoom) {
                    if (!playerRoom.selectedAnswers[questionIndex]) {
                        playerRoom.selectedAnswers[questionIndex] = [0, playerRoom.players.length - 1];
                    }
                    playerRoom.selectedAnswers[questionIndex][1]--;
                    playerRoom.players.find((player) => player.id === socket.id).answerState = AnswerState.hasInteracted;
                    playerRoom.selectedAnswers[questionIndex][0]++;
                    this.sio.to(playerRoom.id).emit(AnswerEvent.PLAYER_ANSWER_SATE_CHANGED, playerRoom.players);
                    const dataQuestion0: AnswerChoice = { index: 0, newChoice: playerRoom.selectedAnswers[questionIndex][0] };
                    const dataQuestion1: AnswerChoice = { index: 1, newChoice: playerRoom.selectedAnswers[questionIndex][1] };

                    this.sio.to(playerRoom.id).emit(AnswerEvent.INTEREACTIONS_CHANGED, dataQuestion0);
                    this.sio.to(playerRoom.id).emit(AnswerEvent.INTEREACTIONS_CHANGED, dataQuestion1);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(AnswerEvent.PLAYER_AFK, (questionIndex: number) => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (playerRoom) {
                    if (!playerRoom.selectedAnswers[questionIndex]) {
                        playerRoom.selectedAnswers[questionIndex] = [0, playerRoom.players.length - 1];
                    }
                    playerRoom.selectedAnswers[questionIndex][0]--;
                    playerRoom.selectedAnswers[questionIndex][1]++;
                    const dataQuestion0: AnswerChoice = { index: 0, newChoice: playerRoom.selectedAnswers[questionIndex][0] };
                    const dataQuestion1: AnswerChoice = { index: 1, newChoice: playerRoom.selectedAnswers[questionIndex][1] };

                    this.sio.to(playerRoom.id).emit(AnswerEvent.INTEREACTIONS_CHANGED, dataQuestion0);
                    this.sio.to(playerRoom.id).emit(AnswerEvent.INTEREACTIONS_CHANGED, dataQuestion1);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });

            socket.on(AnswerEvent.FINISHED_CORRECTING, (data: correctedChoice) => {
                const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
                if (playerRoom) {
                    playerRoom.selectedAnswers[data.questionIndex] = [0, 0, 0];
                    data.grades.forEach((grade) => {
                        this.handlePlayerGrade(playerRoom, grade, { questionValue: data.questionValue, questionIndex: data.questionIndex });
                    });
                    this.sio.to(playerRoom.id).emit(GameEvent.NEW_PLAYER_POINTS, playerRoom.players);
                    this.sio.to(playerRoom.id).emit(AnswerEvent.EVALUATION_FINISHED);
                } else {
                    socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
                }
            });
        });
    }

    removeAnswer(clientRoom: Room, socketId: string) {
        clientRoom.playerQcmAnswers = clientRoom.playerQcmAnswers.filter((answer) => answer.playerId !== socketId);
        clientRoom.playerQrlAnswers = clientRoom.playerQrlAnswers.filter((answer) => answer.playerId !== socketId);
    }

    handleAnswers(playerRoom: Room) {
        if (this.checkAllAnswered(playerRoom)) {
            this.sio.to(playerRoom.id).emit(AnswerEvent.ALL_PLAYERS_ANSWERED);
            if (playerRoom.playerQcmAnswers.length > 0) {
                this.updateUsersPoints(playerRoom);
                this.sio.to(playerRoom.id).emit(GameEvent.NEW_PLAYER_POINTS, playerRoom.players);
            }
        }
    }

    private validateAnswer(socket: Socket, data: { timeLeft: number; question: Question; answer?: { [key: string]: boolean } | string }) {
        const playerRoom = this.roomStorage.listRooms.find((room) => room.players.some((player) => player.id === socket.id));
        if (playerRoom) {
            const player = playerRoom.players.find((p) => p.id === socket.id && p.role === PlayerState.Player);
            this.handlePlayerState(playerRoom, player, data.timeLeft);
            if (data.question.type === QuestionType.QCM) {
                this.saveQcmAnswer(playerRoom, socket.id, {
                    timeLeft: data.timeLeft,
                    question: data.question,
                    answer: data.answer as { [key: string]: boolean },
                });
            } else {
                player.qrlAnswer = data.answer as string;
                this.saveQrlAnswer(playerRoom, player, data.question);
            }
            this.handleAnswers(playerRoom);
        } else {
            socket.emit(ErrorSocketEvent.ERROR_FINDING_ROOM);
        }
    }

    private handlePlayerState(playerRoom: Room, player: Player, timeLeft: number) {
        player.answerState = AnswerState.hasAnswered;
        if (timeLeft !== 0) {
            player.answerState = AnswerState.hasAnswered;
        } else {
            player.answerState = AnswerState.hasForceAnswered;
        }
        this.sio.to(playerRoom.id).emit(AnswerEvent.PLAYER_ANSWER_SATE_CHANGED, playerRoom.players);
    }

    private saveQcmAnswer(playerRoom: Room, socketId: string, data: { timeLeft: number; question: Question; answer: { [key: string]: boolean } }) {
        const allCorrect = this.checkAllAnswersCorrect(data.question, data.answer as { [key: string]: boolean });
        playerRoom.playerQcmAnswers.push({
            questionValue: data.question.points,
            playerId: socketId,
            timeLeft: data.timeLeft,
            isCorrect: allCorrect,
        });
    }

    private saveQrlAnswer(playerRoom: Room, player: Player, question: Question) {
        playerRoom.playerQrlAnswers.push({
            text: player.qrlAnswer,
            questionValue: question.points,
            playerId: player.id,
            username: player.username,
        });
    }

    private checkAllAnswered(playerRoom: Room): boolean {
        const players = playerRoom.players.filter((player) => player.role !== PlayerState.Organizer);
        return players.every((player) => player.answerState === AnswerState.hasAnswered || player.answerState === AnswerState.hasForceAnswered);
    }

    private checkAllAnswersCorrect(question: Question, buttonsSelected: { [key: string]: boolean }): boolean {
        for (let i = 0; i < question.choices.length; i++) {
            const choice = question.choices[i];
            const isCorrect = choice.isCorrect;
            const isSelected = buttonsSelected[i.toString()] ?? false;
            if (isCorrect !== isSelected) {
                return false;
            }
        }
        return true;
    }

    private updateUsersPoints(adminRoom: Room): void {
        const correctAnswers = adminRoom.playerQcmAnswers.filter((answer) => answer.isCorrect);

        const maxTimeLeft = Math.max(...correctAnswers.map((answer) => answer.timeLeft));

        const playersWithMaxTimeLeft = correctAnswers.filter((answer) => answer.timeLeft === maxTimeLeft).length;

        adminRoom.players.forEach((player) => {
            if (player.role !== PlayerState.Organizer) {
                const playerAnswer = adminRoom.playerQcmAnswers.find((answer) => answer.playerId === player.id);
                let points = 0;
                if (playerAnswer.isCorrect) {
                    points += playerAnswer.questionValue;
                    if (playerAnswer.timeLeft === maxTimeLeft && playersWithMaxTimeLeft === 1) {
                        points *= BONUS_MULTIPLIER;
                        player.nBonus++;
                    }
                }
                player.points += points;
            }
            this.sendNewPoints(player);
        });
    }

    private handlePlayerGrade(playerRoom: Room, grade: Grade, data: { questionValue: number; questionIndex: number }) {
        const player = playerRoom.players.find((p) => p.id === grade.playerId);
        if (player) {
            player.points += (grade.points * data.questionValue) / GRADE.decimal_divider;
            switch (grade.points) {
                case GRADE.half_grade: {
                    playerRoom.selectedAnswers[data.questionIndex][1]++;
                    break;
                }
                case GRADE.full_grade: {
                    playerRoom.selectedAnswers[data.questionIndex][2]++;
                    break;
                }
                default: {
                    playerRoom.selectedAnswers[data.questionIndex][0]++;
                    break;
                }
            }
            this.sendNewPoints(player);
        }
    }

    private sendNewPoints(player: Player) {
        const playerSocket = this.sio.sockets.sockets.get(player.id);
        if (playerSocket) {
            playerSocket.emit(AnswerEvent.NEW_POINTS, player.points);
        }
    }
}
