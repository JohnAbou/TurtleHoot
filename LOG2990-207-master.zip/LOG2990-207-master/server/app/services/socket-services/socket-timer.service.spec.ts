import { BASE_URL, MOCK_ROOM, TEST_PARAMETERS } from '@common/constants';
import { ConnectionEvent, TimerEvent } from '@common/event-name';
import { Room } from '@common/room';
import { Server } from 'app/server';
import { expect } from 'chai';
import * as sinon from 'sinon';
import { Socket, io as ioClient } from 'socket.io-client';
import { Container } from 'typedi';
import { SocketTimerManager } from './socket-timer.service';

describe('SocketTimerManager service tests', () => {
    let service: SocketTimerManager;
    let server: Server;
    let clientSocket: Socket;
    let mockRoom: Room;

    beforeEach(async () => {
        server = Container.get(Server);
        server.init();
        await new Promise((resolve) => setTimeout(resolve, TEST_PARAMETERS.testDelay));
        service = server['socketTimerManager'];
        clientSocket = ioClient(BASE_URL);
        service['roomStorage'].listRooms = [];
        service['roomStorage'].roomTimers = new Map<string, { intervalId: number }>();
        mockRoom = JSON.parse(JSON.stringify(MOCK_ROOM));
    });

    afterEach(async () => {
        await new Promise<void>((resolve) => {
            clientSocket.close();
            service['sio'].close(() => {
                resolve();
            });
        });
        sinon.restore();
    });

    it('should start timer when receiving startTimer event', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(TimerEvent.START_TIMER, mockRoom.accessCode);

        setTimeout(() => {
            expect(service['roomStorage'].roomTimers.has(mockRoom.id)).to.equal(true);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });

    it('should emit timerTick to client room when timer ticks', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'a' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(TimerEvent.START_TIMER, mockRoom.accessCode);

            clientSocket.on(TimerEvent.TIMER_TICK, () => {
                done();
            });
        });
    });

    it('should emit timerTick to client room when timer ticks', (done) => {
        const MOCK_CLIENT = { accessCode: '1234', username: 'a' };
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(ConnectionEvent.JOIN_ROOM, MOCK_CLIENT);
        clientSocket.on(ConnectionEvent.PLAYER_JOINED, () => {
            clientSocket.emit(TimerEvent.START_TIMER, mockRoom.accessCode);

            setTimeout(() => {
                clientSocket.emit(TimerEvent.START_TIMER, mockRoom.accessCode);
                setTimeout(() => {
                    done();
                }, TEST_PARAMETERS.responseDelay);
            }, TEST_PARAMETERS.responseDelay);
        });
    });

    it('should not start timer when clientRoom is not found', (done) => {
        const nonExistingAccessCode = 'nonExistingAccessCode';
        clientSocket.emit(TimerEvent.START_TIMER, nonExistingAccessCode);

        setTimeout(() => {
            expect(service['roomStorage'].roomTimers.has(nonExistingAccessCode)).to.equal(false);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });

    it('should stop timer when receiving stopTimer event', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);
        clientSocket.emit(TimerEvent.START_TIMER, mockRoom.accessCode);

        setTimeout(() => {
            clientSocket.emit(TimerEvent.STOP_TIMER, mockRoom.accessCode);
            setTimeout(() => {
                expect(service['roomStorage'].roomTimers.has(mockRoom.id)).to.equal(false);
                done();
            }, TEST_PARAMETERS.responseDelay);
        }, TEST_PARAMETERS.responseDelay);
    });

    it('should not stop timer when clientRoom is not found', (done) => {
        const nonExistingAccessCode = 'nonExistingAccessCode';
        clientSocket.emit(TimerEvent.STOP_TIMER, nonExistingAccessCode);

        setTimeout(() => {
            expect(service['roomStorage'].roomTimers.has(nonExistingAccessCode)).to.equal(false);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });

    it('should not stop timer when roomTimer is not found', (done) => {
        service['roomStorage'].listRooms.push(mockRoom);

        clientSocket.emit(TimerEvent.STOP_TIMER, mockRoom.accessCode);

        setTimeout(() => {
            expect(service['roomStorage'].roomTimers.has(mockRoom.accessCode)).to.equal(false);
            done();
        }, TEST_PARAMETERS.responseDelay);
    });
});
