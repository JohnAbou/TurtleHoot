import { DB_CONSTS } from '@common/constants';
import { Db, MongoClient, ServerApiVersion } from 'mongodb';
import { Service } from 'typedi';
@Service()
export class DatabaseService {
    db: Db | undefined;
    private client: MongoClient | undefined;

    async connectToServer(uri: string) {
        try {
            this.client = new MongoClient(uri, {
                serverApi: {
                    version: ServerApiVersion.v1,
                    strict: true,
                    deprecationErrors: true,
                },
            });
            await this.client.connect();
            this.db = this.client.db(DB_CONSTS.dbDb);
        } catch (err) {
            throw new Error('Error connecting to MongoDB: ' + err);
        }
    }
}

const dbService = new DatabaseService();
dbService.connectToServer(DB_CONSTS.dbURL);
export { dbService };
