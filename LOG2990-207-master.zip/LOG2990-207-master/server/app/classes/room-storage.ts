import { Room } from '@common/room';

interface RoomTimer {
    intervalId: number;
}

export class RoomStorage {
    private static instance: RoomStorage;
    listRooms: Room[] = [];
    roomTimers: Map<string, RoomTimer> = new Map<string, RoomTimer>();

    static getInstance(): RoomStorage {
        if (!RoomStorage.instance) {
            RoomStorage.instance = new RoomStorage();
        }
        return RoomStorage.instance;
    }
}
