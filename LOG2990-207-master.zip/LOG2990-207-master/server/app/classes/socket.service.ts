import { Server } from 'socket.io';

export class SocketService {
    private static instance: SocketService;
    sio: Server;

    static getInstance(): SocketService {
        if (!SocketService.instance) {
            SocketService.instance = new SocketService();
        }
        return SocketService.instance;
    }
}
