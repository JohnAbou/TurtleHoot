import { VisibilityService } from '@app/services/controller-services/visibility.service';
import * as bodyParser from 'body-parser';
import { expect } from 'chai';
import * as express from 'express';
import { StatusCodes } from 'http-status-codes';
import { describe, it } from 'mocha';
import { SinonStubbedInstance, createStubInstance } from 'sinon';
import * as supertest from 'supertest';
import { VisibilityController } from './visibility.controller';

describe('VisibilityController', () => {
    let app: express.Application;
    let visibilityService: SinonStubbedInstance<VisibilityService>;

    beforeEach(() => {
        visibilityService = createStubInstance(VisibilityService);
        const quizController = new VisibilityController(visibilityService);
        app = express();
        app.use(bodyParser.json());
        app.use('/', quizController.router);
    });

    describe('getVisibilities', () => {
        it('should fetch all quiz visibilities', async () => {
            const mockVisibilities = [
                { quizId: '1', visible: true },
                { quizId: '2', visible: false },
            ];
            visibilityService.getAllVisibility.resolves(mockVisibilities);

            await supertest(app)
                .get('/')
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(mockVisibilities);
                });
        });

        it('should handle error fetching all quiz visibilities', async () => {
            const errorMessage = 'Failed to fetch visibilities';
            visibilityService.getAllVisibility.rejects(new Error(errorMessage));

            await supertest(app)
                .get('/')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('getVisibilityById', () => {
        it('should fetch visibility', async () => {
            const mockVisibility = { quizId: '1', visible: true };
            visibilityService.getVisibility.resolves(mockVisibility.visible);
            await supertest(app)
                .get('/1')
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(mockVisibility.visible);
                });
        });

        it('should handle error fetching quiz visibility', async () => {
            const errorMessage = 'Failed to fetch visibility';
            visibilityService.getVisibility.rejects(new Error(errorMessage));

            await supertest(app)
                .get('/1')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('setVisibilityById', () => {
        it('should set visibility', async () => {
            visibilityService.setVisibility.resolves();

            await supertest(app)
                .put('/1')
                .send({ visible: 'true' })
                .then((response) => {
                    expect(response.status).to.deep.equal(StatusCodes.NO_CONTENT);
                });
        });

        it('should handle error setting quiz visibility', async () => {
            const errorMessage = 'Failed to set visibility';
            visibilityService.setVisibility.rejects(new Error(errorMessage));

            await supertest(app)
                .put('/1')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('addVisibility', () => {
        it('should add visibility', async () => {
            visibilityService.addVisibility.resolves();

            await supertest(app)
                .post('/1')
                .then((response) => {
                    expect(response.status).to.deep.equal(StatusCodes.NO_CONTENT);
                });
        });

        it('should handle error setting quiz visibility', async () => {
            const errorMessage = 'Failed to add visibility';
            visibilityService.addVisibility.rejects(new Error(errorMessage));

            await supertest(app)
                .post('/1')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });
});
