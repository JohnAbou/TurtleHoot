import { QuizService } from '@app/services/controller-services/quiz.service';
import { VerificationQuizService } from '@app/services/verification.quiz.service';
import { Quiz } from '@common/quiz';
import { Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Service } from 'typedi';

@Service()
export class AdminController {
    router: Router;

    constructor(
        private readonly verificationQuizService: VerificationQuizService,
        private readonly quizService: QuizService,
    ) {
        this.configureRouter();
    }

    private filterQuiz(newQuiz: Quiz, res: Response): Quiz | null {
        const filteredQuiz: Quiz | null = this.verificationQuizService.filterQuiz(newQuiz);
        if (!filteredQuiz) {
            res.status(StatusCodes.BAD_REQUEST).send(` Quiz invalide: ${this.verificationQuizService.textError}`);
        }
        return filteredQuiz;
    }

    private async modifyQuiz(newQuiz: Quiz, filteredQuiz: Quiz, res: Response): Promise<void> {
        try {
            if (await this.quizService.getQuizById(newQuiz.id)) {
                await this.quizService.modifyQuiz(newQuiz.id, filteredQuiz);
                res.status(StatusCodes.OK).send('Quiz modifié avec succès!');
            }
        } catch (error) {
            res.status(StatusCodes.INTERNAL_SERVER_ERROR).send('Une erreur est survenue lors de la modification du quiz.');
        }
    }

    private async saveQuiz(filteredQuiz: Quiz, res: Response): Promise<void> {
        try {
            if (await this.quizService.saveQuiz(filteredQuiz)) {
                res.status(StatusCodes.CREATED).send('Quiz créé avec succès!');
            } else {
                res.status(StatusCodes.FORBIDDEN).send(`Un quiz possède déjà le titre ${filteredQuiz.title}, choisissez un titre différent!`);
            }
        } catch (error) {
            res.status(StatusCodes.INTERNAL_SERVER_ERROR).send("Une erreur est survenue lors de l'enregistrement du quiz.");
        }
    }

    private configureRouter(): void {
        this.router = Router();

        this.router.post('/connect', (req: Request, res: Response) => {
            const password: string = req.body.password;
            if (password === 'log2990-207') {
                res.status(StatusCodes.OK).send();
            } else {
                res.status(StatusCodes.UNAUTHORIZED).send();
            }
        });

        this.router.post('/save-quiz', async (req: Request, res: Response) => {
            const newQuiz: Quiz = req.body.quiz;
            if (!newQuiz || typeof newQuiz !== 'object') {
                res.status(StatusCodes.BAD_REQUEST).json({ error: 'Format de JSON invalide' });
                return;
            }

            const isNew = req.body.isNew;

            const filteredQuiz: Quiz | null = this.filterQuiz(newQuiz, res);
            if (!filteredQuiz) {
                return;
            }

            if (!isNew) {
                await this.modifyQuiz(newQuiz, filteredQuiz, res);
            } else {
                await this.saveQuiz(filteredQuiz, res);
            }
        });
    }
}
