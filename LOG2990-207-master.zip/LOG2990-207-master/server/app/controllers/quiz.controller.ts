import { QuizService } from '@app/services/controller-services/quiz.service';
import { VerificationQuizService } from '@app/services/verification.quiz.service';
import { Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Service } from 'typedi';

@Service()
export class QuizController {
    router: Router;

    constructor(
        private readonly quizService: QuizService,
        private readonly verificationQuizService: VerificationQuizService,
    ) {
        this.configureRouter();
    }

    private configureRouter(): void {
        this.router = Router();

        this.router.get('/', async (req: Request, res: Response) => {
            try {
                const quizzes = await this.quizService.retrieveAllQuizzes();
                res.json(quizzes);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.get('/:id', async (req: Request, res: Response) => {
            const quizId = req.params.id;
            try {
                const quiz = await this.quizService.getQuizById(quizId);
                if (quiz) {
                    res.json(quiz);
                } else {
                    res.status(StatusCodes.NOT_FOUND).json({
                        title: 'Error',
                        body: 'Quiz not found',
                    });
                }
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.put('/:id', async (req: Request, res: Response) => {
            const quizId = req.params.id;
            try {
                const updatedQuizData = this.verificationQuizService.filterQuiz(req.body);
                const updatedQuiz = await this.quizService.modifyQuiz(quizId, updatedQuizData);
                res.json(updatedQuiz);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.post('/:id/questions', async (req: Request, res: Response) => {
            const quizId = req.params.id;
            const newQuestionData = req.body;
            try {
                const updatedQuiz = await this.quizService.addQuestionToQuiz(quizId, newQuestionData);
                res.json(updatedQuiz);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.delete('/:quizId/questions', async (req: Request, res: Response) => {
            const quizId = req.params.quizId;
            const question = req.body;
            try {
                const updatedQuiz = await this.quizService.deleteQuestionInQuiz(quizId, question);

                res.json(updatedQuiz);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.delete('/:id', async (req: Request, res: Response) => {
            const quizId = req.params.id;
            try {
                await this.quizService.deleteQuiz(quizId);
                res.status(StatusCodes.NO_CONTENT).send();
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.post('/', async (req: Request, res: Response) => {
            try {
                const quizData = this.verificationQuizService.filterQuiz(req.body);
                const quiz = await this.quizService.addQuiz(quizData);
                res.json(quiz);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });
    }
}
