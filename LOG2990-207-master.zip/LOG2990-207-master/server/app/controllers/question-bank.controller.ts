import { QuestionBank } from '@app/services/controller-services/question-bank.service';
import { Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Service } from 'typedi';

@Service()
export class QuestionBankController {
    router: Router;

    constructor(private readonly questionBankService: QuestionBank) {
        this.configureRouter();
    }

    private configureRouter(): void {
        this.router = Router();

        this.router.get('/', async (req: Request, res: Response) => {
            try {
                const questions = await this.questionBankService.retrieveAllQuestions();
                res.json(questions);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.get('/:id', async (req: Request, res: Response) => {
            const questionId = req.params.id;
            try {
                const question = await this.questionBankService.getQuestionById(questionId);
                if (question) {
                    res.json(question);
                } else {
                    res.status(StatusCodes.NOT_FOUND).json({
                        title: 'Error',
                        body: 'Question not found',
                    });
                }
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.put('/:id', async (req: Request, res: Response) => {
            const questionId = req.params.id;
            const updatedQuestionData = req.body;
            try {
                await this.questionBankService.modifyQuestion(questionId, updatedQuestionData);
                res.status(StatusCodes.NO_CONTENT).send();
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.post('/', async (req: Request, res: Response) => {
            const newQuestionData = req.body;
            try {
                const updatedQuestion = await this.questionBankService.addQuestion(newQuestionData);
                res.json(updatedQuestion);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.delete('/:id', async (req: Request, res: Response) => {
            const questionId = req.params.id;
            try {
                await this.questionBankService.deleteQuestion(questionId);
                res.status(StatusCodes.NO_CONTENT).send();
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });
    }
}
