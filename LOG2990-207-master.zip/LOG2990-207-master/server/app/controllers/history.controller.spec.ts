import { HistoryService } from '@app/services/controller-services/history.service';
import * as bodyParser from 'body-parser';
import { expect } from 'chai';
import * as express from 'express';
import { StatusCodes } from 'http-status-codes';
import { describe, it } from 'mocha';
import { SinonStubbedInstance, createStubInstance } from 'sinon';
import * as supertest from 'supertest';
import { HistoryController } from './history.controller';

describe('HistoryController', () => {
    let app: express.Application;
    let historyService: SinonStubbedInstance<HistoryService>;

    beforeEach(() => {
        historyService = createStubInstance(HistoryService);
        const historyController = new HistoryController(historyService);
        app = express();
        app.use(bodyParser.json());
        app.use('/', historyController.router);
    });

    describe('getAllHistory', () => {
        it('should fetch all history entries', async () => {
            const mockHistory = [
                {
                    quizTitle: 'Quiz 1',
                    playerCount: 10,
                    bestScore: 100,
                    startTime: '2024-03-29T10:00:00',
                    endTime: '2024-03-29T12:00:00',
                },
                {
                    quizTitle: 'Quiz 2',
                    playerCount: 10,
                    bestScore: 100,
                    startTime: '2024-03-29T10:00:00',
                    endTime: '2024-03-29T12:00:00',
                },
            ];
            historyService.getAllHistory.resolves(mockHistory);

            await supertest(app)
                .get('/')
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(mockHistory);
                });
        });

        it('should handle error fetching all history entries', async () => {
            const errorMessage = 'Failed to fetch history';
            historyService.getAllHistory.rejects(new Error(errorMessage));

            await supertest(app)
                .get('/')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('addHistoryInformation', () => {
        it('should add history information', async () => {
            const newHistoryInformation = { id: '3', event: 'New Event' };
            historyService.addHistoryInformation.resolves();

            await supertest(app).post('/').send(newHistoryInformation).expect(StatusCodes.NO_CONTENT);
        });

        it('should handle error adding history information', async () => {
            const errorMessage = 'Failed to add history information';
            historyService.addHistoryInformation.rejects(new Error(errorMessage));

            await supertest(app)
                .post('/')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('deleteAllHistory', () => {
        it('should delete all history entries', async () => {
            historyService.deleteAllHistory.resolves();

            await supertest(app).delete('/').expect(StatusCodes.NO_CONTENT);
        });

        it('should handle error deleting all history entries', async () => {
            const errorMessage = 'Failed to delete history';
            historyService.deleteAllHistory.rejects(new Error(errorMessage));

            await supertest(app)
                .delete('/')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });
});
