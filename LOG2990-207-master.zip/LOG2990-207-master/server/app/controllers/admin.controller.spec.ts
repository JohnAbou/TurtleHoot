import { Application } from '@app/app';
import { QuizService } from '@app/services/controller-services/quiz.service';
import { VerificationQuizService } from '@app/services/verification.quiz.service';
import { Quiz } from '@common/quiz';
import { StatusCodes } from 'http-status-codes';
import { createStubInstance, SinonStubbedInstance } from 'sinon';
import * as supertest from 'supertest';
import { Container } from 'typedi';

describe('POST /connect', () => {
    let expressApp: Express.Application;
    beforeEach(() => {
        const app = Container.get(Application);
        expressApp = app.app;
    });
    it('should return 200 OK if correct password is provided', async () => {
        const credential = { password: 'log2990-207' };
        return await supertest(expressApp).post('/api/admin/connect').send(credential).set('Accept', 'application/json').expect(StatusCodes.OK);
    });

    it('should return 401 Unauthorized if incorrect password is provided', async () => {
        const badCredential = { password: '1234569' };
        return await supertest(expressApp)
            .post('/api/admin/connect')
            .send(badCredential)
            .set('Accept', 'application/json')
            .expect(StatusCodes.UNAUTHORIZED);
    });

    it('should return 400 Bad Request if password is missing', async () => {
        return await supertest(expressApp).post('/api/admin/connect').send().set('Accept', 'application/json').expect(StatusCodes.UNAUTHORIZED);
    });
});

describe('AdminController - save quiz', () => {
    const MOCK_QUIZ = {
        id: '1234',
        title: 'Questionnaire sur le JS',
        description: 'Questions de pratique sur le langage JavaScript',
        duration: 5,
        lastModification: '2018-11-13T20:20:39+00:00',
        questions: [],
    } as Quiz;

    let verificationQuizService: SinonStubbedInstance<VerificationQuizService>;
    let quizService: SinonStubbedInstance<QuizService>;
    let expressApp: Express.Application;

    beforeEach(async () => {
        verificationQuizService = createStubInstance(VerificationQuizService);
        quizService = createStubInstance(QuizService);

        const app = Container.get(Application);
        Object.defineProperty(app['adminController'], 'verificationQuizService', { value: verificationQuizService });
        Object.defineProperty(app['adminController'], 'quizService', { value: quizService });

        expressApp = app.app;
    });

    it('Should return Quiz from admin service on valid post request to /save-quiz', async () => {
        verificationQuizService.filterQuiz.returns(MOCK_QUIZ);
        quizService.saveQuiz.resolves(true);
        const payload = { quiz: MOCK_QUIZ, isNew: true };
        return await supertest(expressApp).post('/api/admin/save-quiz').send(payload).set('Accept', 'application/json').expect(StatusCodes.CREATED);
    });

    it('Should return Bad_Request from admin service on invalid post request to /save-quiz', async () => {
        verificationQuizService.filterQuiz.returns(null);
        quizService.getQuizByName.resolves(true);
        const payload = { quiz: MOCK_QUIZ, isNew: true };
        return await supertest(expressApp)
            .post('/api/admin/save-quiz')
            .send(payload)
            .set('Accept', 'application/json')
            .expect(StatusCodes.BAD_REQUEST);
    });

    it('Should return Bad_Request from admin service on invalid post request to /save-quiz', async () => {
        verificationQuizService.filterQuiz.returns(null);
        quizService.getQuizByName.resolves(true);
        const payload = { quiz: 'MOCK_QUIZ', isNew: true };
        return await supertest(expressApp)
            .post('/api/admin/save-quiz')
            .send(payload)
            .set('Accept', 'application/json')
            .expect(StatusCodes.BAD_REQUEST);
    });

    it('Should return FORBIDDEN from admin service on valid post request, but already used quiz name to /save-quiz', async () => {
        verificationQuizService.filterQuiz.returns(MOCK_QUIZ);
        quizService.getQuizByName.resolves(true);
        const payload = { quiz: MOCK_QUIZ, isNew: true };
        return await supertest(expressApp).post('/api/admin/save-quiz').send(payload).set('Accept', 'application/json').expect(StatusCodes.FORBIDDEN);
    });

    it('Should return Quiz from admin service on valid post request to modify a quiz to /save-quiz', async () => {
        verificationQuizService.filterQuiz.returns(MOCK_QUIZ);
        quizService.getQuizById.resolves(true);
        quizService.modifyQuiz.resolves(true);
        const payload = { quiz: MOCK_QUIZ, isNew: false };
        return await supertest(expressApp).post('/api/admin/save-quiz').send(payload).set('Accept', 'application/json').expect(StatusCodes.OK);
    });
});
