import { VisibilityService } from '@app/services/controller-services/visibility.service';
import { Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Service } from 'typedi';

@Service()
export class VisibilityController {
    router: Router;

    constructor(private readonly visibilityService: VisibilityService) {
        this.configureRouter();
    }

    private configureRouter(): void {
        this.router = Router();

        this.router.get('/', async (req: Request, res: Response) => {
            try {
                const visibility = await this.visibilityService.getAllVisibility();
                res.json(visibility);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.get('/:id', async (req: Request, res: Response) => {
            const quizId = req.params.id;
            try {
                const visibility = await this.visibilityService.getVisibility(quizId);
                res.json(visibility);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.put('/:id', async (req: Request, res: Response) => {
            const quizId = req.params.id;

            const visible = req.body.visible;
            try {
                await this.visibilityService.setVisibility(quizId, visible);

                res.status(StatusCodes.NO_CONTENT).send();
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.post('/:id', async (req: Request, res: Response) => {
            const quizId = req.params.id;
            try {
                await this.visibilityService.addVisibility(quizId, false);
                res.status(StatusCodes.NO_CONTENT).send();
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });
    }
}
