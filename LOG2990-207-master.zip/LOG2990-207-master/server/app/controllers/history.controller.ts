import { HistoryService } from '@app/services/controller-services/history.service';
import { Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Service } from 'typedi';
@Service()
export class HistoryController {
    router: Router;

    constructor(private readonly historyService: HistoryService) {
        this.configureRouter();
    }

    private configureRouter(): void {
        this.router = Router();

        this.router.get('/', async (req: Request, res: Response) => {
            try {
                const visibility = await this.historyService.getAllHistory();
                res.json(visibility);
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.post('/', async (req: Request, res: Response) => {
            const newHistoryInformation = req.body;

            try {
                await this.historyService.addHistoryInformation(newHistoryInformation);
                res.status(StatusCodes.NO_CONTENT).send();
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });

        this.router.delete('/', async (req: Request, res: Response) => {
            try {
                await this.historyService.deleteAllHistory();
                res.status(StatusCodes.NO_CONTENT).send();
            } catch (error) {
                const errorMessage = {
                    title: 'Error',
                    body: error.message,
                };
                res.status(StatusCodes.INTERNAL_SERVER_ERROR).json(errorMessage);
            }
        });
    }
}
