import { QuizService } from '@app/services/controller-services/quiz.service';
import { VerificationQuizService } from '@app/services/verification.quiz.service';
import { MOCK_QUIZ } from '@common/constants';
import * as bodyParser from 'body-parser';
import { expect } from 'chai';
import * as express from 'express';
import { StatusCodes } from 'http-status-codes';
import { describe, it } from 'mocha';
import { SinonStubbedInstance, createStubInstance } from 'sinon';
import * as supertest from 'supertest';
import { QuizController } from './quiz.controller';

describe('QuizController', () => {
    let app: express.Application;
    let quizService: SinonStubbedInstance<QuizService>;
    let verificationQuizService: SinonStubbedInstance<VerificationQuizService>;

    beforeEach(() => {
        quizService = createStubInstance(QuizService);
        verificationQuizService = createStubInstance(VerificationQuizService);
        const quizController = new QuizController(quizService, verificationQuizService);
        app = express();
        app.use(bodyParser.json());
        app.use('/', quizController.router);
    });

    describe('getQuizzes', () => {
        it('should retrieve all quizzes', async () => {
            const mockQuizzes = [
                { id: '1', title: 'Quiz 1' },
                { id: '2', title: 'Quiz 2' },
            ];
            quizService.retrieveAllQuizzes.resolves(mockQuizzes);

            await supertest(app)
                .get('/')
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(mockQuizzes);
                });
        });

        it('should handle error while fetching quizzes', async () => {
            const errorMessage = 'Failed to fetch quizzes';
            quizService.retrieveAllQuizzes.rejects(new Error(errorMessage));

            await supertest(app)
                .get('/')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('getQuizById', () => {
        it('should retrieve quiz by id', async () => {
            quizService.getQuizById.resolves(MOCK_QUIZ);

            await supertest(app)
                .get('/0')
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(MOCK_QUIZ);
                });
        });

        it('should handle error when quiz not found', async () => {
            quizService.getQuizById.resolves(null);

            await supertest(app)
                .get('/0')
                .expect(StatusCodes.NOT_FOUND)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: 'Quiz not found',
                    });
                });
        });

        it('should handle error while fetching quiz by id', async () => {
            const errorMessage = 'Failed to fetch quiz';
            quizService.getQuizById.rejects(new Error(errorMessage));

            await supertest(app)
                .get('/0')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('modifyQuiz', () => {
        it('should modify a quiz', async () => {
            quizService.modifyQuiz.resolves(MOCK_QUIZ);

            await supertest(app)
                .put('/0')
                .send(MOCK_QUIZ)
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(MOCK_QUIZ);
                });
        });

        it('should handle errors during quiz modification', async () => {
            const errorMessage = 'Failed to modify quiz';
            quizService.modifyQuiz.rejects(new Error(errorMessage));

            await supertest(app)
                .put('/0')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('addQuestionToQuiz', () => {
        it('should add a question to a quiz', async () => {
            quizService.addQuestionToQuiz.resolves(MOCK_QUIZ);

            await supertest(app)
                .post('/0/questions')
                .send(MOCK_QUIZ)
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(MOCK_QUIZ);
                });
        });

        it('should handle errors during question addition', async () => {
            const errorMessage = 'Failed to add question';
            quizService.addQuestionToQuiz.rejects(new Error(errorMessage));

            await supertest(app)
                .post('/0/questions')
                .send(MOCK_QUIZ)
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('deleteQuestionInQuiz', () => {
        it('should delete a question in a quiz', async () => {
            quizService.deleteQuestionInQuiz.resolves(MOCK_QUIZ);

            await supertest(app)
                .delete('/0/questions')
                .send(MOCK_QUIZ)
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(MOCK_QUIZ);
                });
        });

        it('should handle errors during question deletion', async () => {
            const errorMessage = 'Failed to delete question';
            quizService.deleteQuestionInQuiz.rejects(new Error(errorMessage));

            await supertest(app)
                .delete('/0/questions')
                .send(MOCK_QUIZ)
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('deleteQuiz', () => {
        it('should delete a quiz', async () => {
            quizService.deleteQuiz.resolves();

            await supertest(app)
                .delete('/0')
                .send(MOCK_QUIZ)
                .then((response) => {
                    expect(response.status).to.deep.equal(StatusCodes.NO_CONTENT);
                });
        });

        it('should handle errors during quiz deletion', async () => {
            const errorMessage = 'Failed to delete quiz';
            quizService.deleteQuiz.rejects(new Error(errorMessage));

            await supertest(app)
                .delete('/0')
                .send(MOCK_QUIZ)
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('addQuiz', () => {
        it('should add a new quiz', async () => {
            quizService.addQuiz.resolves(MOCK_QUIZ);

            await supertest(app)
                .post('/')
                .send(MOCK_QUIZ)
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(MOCK_QUIZ);
                });
        });

        it('should handle errors during quiz addition', async () => {
            const errorMessage = 'Failed to add quiz';
            quizService.addQuiz.rejects(new Error(errorMessage));

            await supertest(app)
                .post('/')
                .send(MOCK_QUIZ)
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });
});
