import { QuestionBank } from '@app/services/controller-services/question-bank.service';
import { MOCK_QUIZ } from '@common/constants';
import * as bodyParser from 'body-parser';
import { expect } from 'chai';
import * as express from 'express';
import { StatusCodes } from 'http-status-codes';
import { describe, it } from 'mocha';
import { SinonStubbedInstance, createStubInstance } from 'sinon';
import * as supertest from 'supertest';
import { QuestionBankController } from './question-bank.controller';

const MOCK_QUESTIONS = MOCK_QUIZ.questions;

describe('QuestionBankController', () => {
    let app: express.Application;
    let questionBankService: SinonStubbedInstance<QuestionBank>;

    beforeEach(() => {
        questionBankService = createStubInstance(QuestionBank);
        const quizController = new QuestionBankController(questionBankService);
        app = express();
        app.use(bodyParser.json());
        app.use('/', quizController.router);
    });

    describe('getQuestions', () => {
        it('should retrieve all questions', async () => {
            questionBankService.retrieveAllQuestions.resolves(MOCK_QUESTIONS);

            await supertest(app)
                .get('/')
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(MOCK_QUESTIONS);
                });
        });

        it('should handle error while fetching questions', async () => {
            const errorMessage = 'Failed to fetch questions';
            questionBankService.retrieveAllQuestions.rejects(new Error(errorMessage));

            await supertest(app)
                .get('/')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('getQuestionById', () => {
        it('should retrieve question by Id', async () => {
            questionBankService.getQuestionById.resolves(MOCK_QUESTIONS[0]);

            await supertest(app)
                .get('/1')
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(MOCK_QUESTIONS[0]);
                });
        });

        it('should handle question not found', async () => {
            questionBankService.getQuestionById.resolves(null);

            await supertest(app)
                .get('/1')
                .expect(StatusCodes.NOT_FOUND)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: 'Question not found',
                    });
                });
        });

        it('should handle error while fetching question by id', async () => {
            const errorMessage = 'Failed to fetch question';
            questionBankService.getQuestionById.rejects(new Error(errorMessage));

            await supertest(app)
                .get('/1')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('modifyQuestionById', () => {
        it('should modify question by Id', async () => {
            questionBankService.modifyQuestion.resolves();

            await supertest(app)
                .put('/1')
                .send(MOCK_QUESTIONS[0])
                .then((response) => {
                    expect(response.status).to.deep.equal(StatusCodes.NO_CONTENT);
                });
        });

        it('should handle error while modifying question', async () => {
            const errorMessage = 'Failed to modify question';
            questionBankService.modifyQuestion.rejects(new Error(errorMessage));

            await supertest(app)
                .put('/1')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('addQuestion', () => {
        it('should add question', async () => {
            questionBankService.addQuestion.resolves(MOCK_QUESTIONS[0]);

            await supertest(app)
                .post('/')
                .send(MOCK_QUESTIONS[0])
                .expect(StatusCodes.OK)
                .then((response) => {
                    expect(response.body).to.deep.equal(MOCK_QUESTIONS[0]);
                });
        });

        it('should handle error while adding question', async () => {
            const errorMessage = 'Failed to add question';
            questionBankService.addQuestion.rejects(new Error(errorMessage));

            await supertest(app)
                .post('/')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });

    describe('deleteQuestionById', () => {
        it('should delete question by Id', async () => {
            questionBankService.deleteQuestion.resolves();

            await supertest(app)
                .delete('/1')
                .then((response) => {
                    expect(response.status).to.deep.equal(StatusCodes.NO_CONTENT);
                });
        });

        it('should handle error while deleting question', async () => {
            const errorMessage = 'Failed to delete question';
            questionBankService.deleteQuestion.rejects(new Error(errorMessage));

            await supertest(app)
                .delete('/1')
                .expect(StatusCodes.INTERNAL_SERVER_ERROR)
                .then((response) => {
                    expect(response.body).to.deep.equal({
                        title: 'Error',
                        body: errorMessage,
                    });
                });
        });
    });
});
