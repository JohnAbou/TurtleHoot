import { Application } from '@app/app';
import { DatabaseService } from '@app/services/database.service';
import { DB_CONSTS } from '@common/constants';
import * as http from 'http';
import * as io from 'socket.io';
import { Service } from 'typedi';
import { SocketService } from './classes/socket.service';
import { QuizService } from './services/controller-services/quiz.service';
import { SocketAnswerManager } from './services/socket-services/socket-answer.service';
import { SocketChatManager } from './services/socket-services/socket-chat.service';
import { SocketConnectionManager } from './services/socket-services/socket-connection.service';
import { SocketGameManager } from './services/socket-services/socket-game.service';
import { SocketPanicModeManager } from './services/socket-services/socket-panic-mode.service';
import { SocketTimerManager } from './services/socket-services/socket-timer.service';

@Service()
export class Server {
    private static readonly appPort: string | number | boolean = Server.normalizePort(process.env.PORT || '3000');
    private static readonly baseDix: number = 10;
    private socketConnectionManager: SocketConnectionManager;
    private socketChatManager: SocketChatManager;
    private socketGameManager: SocketGameManager;
    private socketAnswerManager: SocketAnswerManager;
    private socketTimerManager: SocketTimerManager;
    private socketPanicModeManager: SocketPanicModeManager;
    private server: http.Server;

    constructor(
        private readonly application: Application,
        private readonly dbService: DatabaseService,
        private readonly quizService: QuizService,
    ) {}

    private static normalizePort(val: number | string): number | string | boolean {
        const port: number = typeof val === 'string' ? parseInt(val, this.baseDix) : val;
        return isNaN(port) ? val : port >= 0 ? port : false;
    }
    init(): void {
        this.dbService.connectToServer(DB_CONSTS.dbURL).then(() => {
            this.application.app.set('port', Server.appPort);
            this.server = http.createServer(this.application.app);
            this.server.on('error', (error: NodeJS.ErrnoException) => this.onError(error));

            const socketService = SocketService.getInstance();
            socketService.sio = new io.Server(this.server, { cors: { origin: '*', methods: ['GET', 'POST'] } });

            this.socketGameManager = new SocketGameManager(socketService.sio);
            this.socketGameManager.handleSockets();

            this.socketAnswerManager = new SocketAnswerManager(socketService.sio);
            this.socketAnswerManager.handleSockets();

            this.socketConnectionManager = new SocketConnectionManager(socketService.sio, this.socketAnswerManager, this.quizService);
            this.socketConnectionManager.handleSockets();

            this.socketChatManager = new SocketChatManager(socketService.sio);
            this.socketChatManager.handleSockets();

            this.socketTimerManager = new SocketTimerManager(socketService.sio);
            this.socketTimerManager.handleSockets();

            this.socketPanicModeManager = new SocketPanicModeManager(socketService.sio);
            this.socketPanicModeManager.handleSockets();

            this.server.listen(Server.appPort);
        });
    }

    private onError(error: NodeJS.ErrnoException): void {
        if (error.syscall !== 'listen') {
            throw error;
        }
        const bind: string = typeof Server.appPort === 'string' ? 'Pipe ' + Server.appPort : 'Port ' + Server.appPort;
        switch (error.code) {
            case 'EACCES':
                throw new Error(`${bind} requires elevated privileges`);
            case 'EADDRINUSE':
                throw new Error(`${bind} is already in use`);
            default:
                throw error;
        }
    }
}
